console.log("Пикчи » Халявные стикеры и Голоса");


// Подключаем модули
const { VK, Keyboard } = require("vk-io");
const { HearManager } = require("@vk-io/hear");
const CronJob = require("cron").CronJob;
const fs = require("fs");


// Подключаем настройки бота
let config = require("./config.json");


// Подключаем базу данных игроков
let users = require("./base/users.json");


// Подключаем базу данных заданий бонус за участие
let bonuses_participation = require("./base/bonuses_participation.json");


// Подключаем базу данных заданий
let tasks = require("./base/tasks.json");


// Подключаем базу данных игры Камень-Ножницы-Бумага
let games_knb = require("./base/games_knb.json");


// Подключаем базу данных выводов
let sends = require("./base/sends.json");


// Подключаем базу данных чатов
let chats = require("./base/chats.json");


// Подключаем базу данных команд которые добавил админ
let commands = require("./base/commands.json");


// Подключаем базу данных промокодов
let promocodes = require("./base/promocodes.json");


// Запускаем бота
const vk = new VK({ token: config[0].group.token, pollingGroupId: config[0].group.id, apiLimit: 20 });
const admin_vk = new VK({ token: config[0].admin.token });
const cmd = new HearManager();
vk.updates.start();


// Записи для лайка/репоста
let posts = [];


// Подключаем утилиты
let utils = {
    save: (path, data) => {
        fs.writeFileSync(path, JSON.stringify(data, null, `\t`));
    },
    info_balance: (user_id) => {
        user = users.find(user => user.id == Number(user_id));
        return `${utils.amount(user.balance[0])} ${config[0].currency[0]} ${utils.amount(user.balance[1])} ${config[0].currency[1]}`;
    },
    balance: (user_id) => {
        user = users.find(user => user.id == Number(user_id));
        return `💰 Твой баланс: ${utils.info_balance(user.id)}`;
    },
    amount: (int) => {
        return (int < 0 ? `-` : ``) + Math.floor(int).toString().split('').reverse().join('').match(/[0-9]{1,3}/g).join(' ').split('').reverse().join('');
    },
    get_noun: (number, one, two, five) => {
        let n = Math.abs(number);
        n %= 100;
        if (n >= 5 && n <= 20 || n === 0) { return five }
        n %= 10;
        if (n === 1) { return one }
        if (n >= 2 && n <= 4) { return two }

        return five;
    },
    display_time: (seconds) => {
        var ticks = seconds;

        var day = Math.floor((ticks / 3600) / 24)
        var hh = Math.floor((ticks / 3600) % 24)
        var mm = Math.floor((ticks % 3600) / 60)
        var ss = Math.floor(ticks % 60);

        let time_day = `${day > 0 ? `${day} ${utils.get_noun(day, 'день ', 'дня ', 'дней ')}` : ``}`
        let time_hh = `${hh > 0 ? `${hh} ${utils.get_noun(hh, 'час ', 'часа ', 'часов ')}` : ``}`
        let time_mm = `${mm > 0 ? `${mm} ${utils.get_noun(mm, 'минуту ', 'минуты ', 'минут ')}` : ``}`
        let time_ss = `${ss > 0 ? `${ss} ${utils.get_noun(ss, 'секунду ', 'секунды ', 'секунд ')}` : ``}`

        let time = time_day + time_hh + time_mm + time_ss;

        return time;
    },
    word_sex: (value, word_1, word_2) => {
        return value == 1 ? word_1 : word_2;
    },
    fullname_user: (user_id) => {
        user = users.find(user => user.id == Number(user_id));
        return `[id${user.id}|${user.first_name} ${user.last_name}]`
    },
    validate_number: (num) => {
        return Number.isInteger(num) && num > 0;
    },
    games_knb_play_win: (type, creator, amount, heart, user_id) => {

        user = users.find(user => user.id == user_id);

        if (type == `win`) {

            let win_sum = amount * 0.9;

            if (creator == true) {

                if (heart == 0) { user.balance[0] += amount; user.balance[0] += win_sum }
                else if (heart == 1) { user.balance[1] += amount; user.balance[1] += win_sum };

            } else {

                if (heart == 0) { user.balance[0] += win_sum }
                else if (heart == 1) { user.balance[1] += win_sum };

            }
        } else if (type == `lose`) {

            if (creator == true) {

                if (heart == 0) { }
                else if (heart == 1) { };

            } else {

                if (heart == 0) { user.balance[0] -= amount }
                else if (heart == 1) { user.balance[1] -= amount };

            }
        } else if (type == `draw`) {

            if (creator == true) {

                if (heart == 0) { user.balance[0] += amount }
                else if (heart == 1) { user.balance[1] += amount };

            } else {

                if (heart == 0) { }
                else if (heart == 1) { };

            }
        }
    },
    get_user_exchange: (user_id, amount, sum, heart, amount_buy) => {
        
        user = users.find(user => user.id == user_id);

        let balance = heart == config[0].currency[0] ? user.balance[0] : heart == config[0].currency[1] ? user.balance[1] : 0;

        if (amount_buy == undefined) { amount_buy = 1 };

        let msg = ``;
        let status = `success`;

        if (user.exchange_amount >= 2) { msg = `⛔ [id${user.id}|${user.first_name}], у тебя уже есть ${utils.amount(user.exchange_amount)} ${utils.get_noun(user.exchange_amount, 'заявка', 'заявки', 'заявок')} на вывод, ожидайте ${utils.get_noun(user.exchange_amount, 'её', 'их', 'их')} обработки после этого ты сможешь сново выводить.` }
        else if (amount == 0) { msg = `❌ К сожалению, сейчас этого товара нет в наличии.` }
        else if (amount < amount_buy) { msg = `❌ К сожалению, столько товара нет в наличии.`}
        else if (balance < sum * amount_buy) { msg = `⛔ На твоём балансе недостаточно ${utils.amount(sum * amount_buy - balance)} ${heart}` };

        if (msg !== ``) { status = `error` };

        return {
            status: status,
            msg: msg
        };
    },
    sms_send_request: async (message, user_id) => {
        vk.api.messages.send({
            user_ids: user_id,
            message: message,
            keyboard: Keyboard.keyboard([
            [Keyboard.urlButton({ label: 'Отзывы', url: config[0].links.reviews })]
            ]).inline(true).oneTime(false),
            random_id: 0
        })
        .then((response) => {})
        .catch((error) => { })
    },
    chat_game_check_active: () => {
        return chats.filter(chat => chat.automatically_run_games == true).filter(chat => chat.games.guess_number.active == false).filter(chat => chat.games.guess_word.active == false).filter(chat => chat.games.word_reversed.active == false).filter(chat => chat.games.count_hearts.active == false).filter(chat => chat.games.guess_promocode.active == false).filter(chat => chat.games.guess_where_gift_hidden.active == false);
    },
    random: (x, y) => {
        return y ? Math.round(Math.random() * (y - x)) + x : Math.round(Math.random() * x);
    },
    reverse_word: (str) => {
        var new_string = ``;     
        
        for (let i = str.length - 1; i >= 0; i--) { new_string += str[i] }

        return new_string;
    },
    games_onn_chat: async (type, chat_id) => {

        let chat = chats.find(chat => chat.id == chat_id);

        if (type == "guess_word") {

            let word = config[0].games.guess_word.words[(utils.random(1, config[0].games.guess_word.words.length) - 1)];

            chat.games.guess_word.active = true;

            chat.games.guess_word.word = word;

            if (word.length < 6) { word = word.replace(word[1], `*`)  }
            else if (word.length >= 6) { word = word.replace(word[2], `*`).replace(word[4], `*`) };

            let msg = await vk.api.messages.send({ peer_ids: chat.id, message: `♨ Внимание! Начинается игра "Отгадай слово"\n\n🏆 Награда за угаданное слово - ${utils.amount(config[0].games.guess_word.reward)} ${config[0].games.guess_word.heart == 0 ? config[0].currency[0] : config[0].games.guess_word.heart == 1 ? config[0].currency[1] : undefined}\n\n📋 Слово - ${word}`, random_id: 0 }).catch((error) => {});

            vk.api.call(`messages.unpin`, { peer_id: chat.id }).catch((error) => { });

            vk.api.call(`messages.pin`, { peer_id: chat.id, conversation_message_id: msg[0].conversation_message_id }).catch((error) => { });

        } else if (type == "guess_number") {

            chat.games.guess_number.active = true;

            chat.games.guess_number.number = utils.random(config[0].games.guess_number.random[0], config[0].games.guess_number.random[1]);

            let msg = await vk.api.messages.send({ peer_ids: chat.id, message: `♨ Внимание! Начинается игра "Отгадай число"\n\n🏆 Награда за угаданное число - ${utils.amount(config[0].games.guess_number.reward)} ${config[0].games.guess_number.heart == 0 ? config[0].currency[0] : config[0].games.guess_number.heart == 1 ? config[0].currency[1] : undefined}\n\n🔢 Число от ${config[0].games.guess_number.random[0]} до ${config[0].games.guess_number.random[1]}`, random_id: 0 }).catch((error) => {});

            vk.api.call(`messages.unpin`, { peer_id: chat.id }).catch((error) => { });

            vk.api.call(`messages.pin`, { peer_id: chat.id, conversation_message_id: msg[0].conversation_message_id }).catch((error) => { });

        } else if (type == "word_reversed") {

            let word = config[0].games.word_reversed.words[(utils.random(1, config[0].games.word_reversed.words.length) - 1)];

            chat.games.word_reversed.active = true

            chat.games.word_reversed.word = utils.reverse_word(word);

            let msg = await vk.api.messages.send({ peer_ids: chat.id, message: `♨ Внимание! Начинается игра "Слово наоборот"\n\n🏆 Награда за угаданное слово - ${utils.amount(config[0].games.word_reversed.reward)} ${config[0].games.word_reversed.heart == 0 ? config[0].currency[0] : config[0].games.word_reversed.heart == 1 ? config[0].currency[1] : undefined}\n\n📋 Слово - ${word}`, random_id: 0 }).catch((error) => {});

            vk.api.call(`messages.unpin`, { peer_id: chat.id }).catch((error) => { });

            vk.api.call(`messages.pin`, { peer_id: chat.id, conversation_message_id: msg[0].conversation_message_id }).catch((error) => { });

        } else if (type == "count_hearts") {

            let symbol_1_amount = utils.random(5, 10);
            let symbol_2_amount = utils.random(5, 10);

            let heart_1_amount = utils.random(5, 10);
            let heart_2_amount = utils.random(5, 10);

            let amount = symbol_1_amount + symbol_2_amount + heart_1_amount + heart_2_amount;

            let hearts_amount = 0;

            let game = ``;

            for (let i = 0; i < amount; i++) {

                let random = utils.random(1, 3);

                if (random == 1) { game += "✅" }
                else if (random == 2) { game += "❌" }
                else if (random == 3) {
                    let random_heart = utils.random(1, 2);
                    if (random_heart == 1) { game += config[0].currency[0] }
                    else if (random_heart == 2) { game += config[0].currency[1] };
                    hearts_amount += Number(1);
                };
            };

            chat.games.count_hearts.active = true;

            chat.games.count_hearts.amount = hearts_amount;

            let msg = await vk.api.messages.send({ peer_ids: chat.id, message: `♨ Внимание! Начинается игра "Посчитай сердца"\n\n🏆 Награда за угаданное количество - ${utils.amount(config[0].games.count_hearts.reward)} ${config[0].games.count_hearts.heart == 0 ? config[0].currency[0] : config[0].games.count_hearts.heart == 1 ? config[0].currency[1] : undefined}\n\n${game}`, random_id: 0 }).catch((error) => {});

            vk.api.call(`messages.unpin`, { peer_id: chat.id }).catch((error) => { });

            vk.api.call(`messages.pin`, { peer_id: chat.id, conversation_message_id: msg[0].conversation_message_id }).catch((error) => { });

        } else if (type == "guess_promocode") {

            let promocode = null;

            for (let i = 0; i < 1; i++) { 
                promocode = utils.generatePromoCode();
                if (promocodes.find(z => z.name == promocode.original)) { i -= 1 }
                else {
                    promocodes.push({
                        uid: promocodes.length + 1,
                        active: true,
                        heart: config[0].games.guess_promocode.heart,
                        name: promocode.original,
                        amount: 1,
                        reward: config[0].games.guess_promocode.reward,
                        users: []
                    });
                };
            }


            chat.games.guess_promocode.active = true;
            chat.games.guess_promocode.promo = promocode.original

            let game = `🆎 Промокод - ${promocode.hiddenDigit}`;

            let msg = await vk.api.messages.send({ peer_ids: chat.id, message: `♨ Внимание! Начинается игра "Отгадай промокод"\n\n🏆 Награда за угаданный промокод - ${utils.amount(config[0].games.guess_promocode.reward)} ${config[0].games.guess_promocode.heart == 0 ? config[0].currency[0] : config[0].games.guess_promocode.heart == 1 ? config[0].currency[1] : undefined}\n\n${game}`, random_id: 0 }).catch((error) => {});

            vk.api.call(`messages.unpin`, { peer_id: chat.id }).catch((error) => { });

            vk.api.call(`messages.pin`, { peer_id: chat.id, conversation_message_id: msg[0].conversation_message_id }).catch((error) => { });

        } else if (type == "guess_where_gift_hidden") {

            chat.games.guess_where_gift_hidden.active = true;
            chat.games.guess_where_gift_hidden.cell = utils.random(1, 9);

            let keyboard1 = [Keyboard.callbackButton({ label: '⬜', color: 'primary', payload: ["guess_where_gift_hidden", 1, chat.games.guess_where_gift_hidden.cell == 1 ? true : undefined] }), Keyboard.callbackButton({ label: '⬜', color: 'primary', payload: ["guess_where_gift_hidden", 2, chat.games.guess_where_gift_hidden.cell == 2 ? true : undefined] }), Keyboard.callbackButton({ label: '⬜', color: 'primary', payload: ["guess_where_gift_hidden", 3, chat.games.guess_where_gift_hidden.cell == 3 ? true : undefined] })];
            let keyboard2 = [Keyboard.callbackButton({ label: '⬜', color: 'primary', payload: ["guess_where_gift_hidden", 4, chat.games.guess_where_gift_hidden.cell == 4 ? true : undefined] }), Keyboard.callbackButton({ label: '⬜', color: 'primary', payload: ["guess_where_gift_hidden", 5, chat.games.guess_where_gift_hidden.cell == 5 ? true : undefined] }), Keyboard.callbackButton({ label: '⬜', color: 'primary', payload: ["guess_where_gift_hidden", 6, chat.games.guess_where_gift_hidden.cell == 6 ? true : undefined] })];
            let keyboard3 = [Keyboard.callbackButton({ label: '⬜', color: 'primary', payload: ["guess_where_gift_hidden", 7, chat.games.guess_where_gift_hidden.cell == 7 ? true : undefined] }), Keyboard.callbackButton({ label: '⬜', color: 'primary', payload: ["guess_where_gift_hidden", 8, chat.games.guess_where_gift_hidden.cell == 8 ? true : undefined] }), Keyboard.callbackButton({ label: '⬜', color: 'primary', payload: ["guess_where_gift_hidden", 9, chat.games.guess_where_gift_hidden.cell == 9 ? true : undefined] })];

            let keyboards = [keyboard1, keyboard2, keyboard3];

            let msg = await vk.api.messages.send({
                peer_ids: chat.id,
                message: `♨ Внимание! Начинается игра "Отгадай где спрятан подарок"\n\n🏆 Награда за угаданный подарок - ${utils.amount(config[0].games.guess_where_gift_hidden.reward)} ${config[0].games.guess_where_gift_hidden.heart == 0 ? config[0].currency[0] : config[0].games.guess_where_gift_hidden.heart == 1 ? config[0].currency[1] : undefined}`,
                keyboard:  Keyboard.keyboard(keyboards).inline(true).oneTime(false),
                random_id: 0
            }).catch((error) => {});

            vk.api.call(`messages.unpin`, { peer_id: chat.id }).catch((error) => { });

            vk.api.call(`messages.pin`, { peer_id: chat.id, conversation_message_id: msg[0].conversation_message_id }).catch((error) => {});
        };
    },
    check_run_games_chat: (chat_id) => {

        let chat = chats.find(chat => chat.id == chat_id);

        let game_onn = null;

        if (chat.games.guess_word.active == true) { game_onn = "guess_word" }
        else if (chat.games.guess_number.active == true) { game_onn = "guess_number" }
        else if (chat.games.word_reversed.active == true) { game_onn = "word_reversed" }
        else if (chat.games.count_hearts.active == true) { game_onn = "count_hearts" }
        else if (chat.games.guess_promocode.active == true) { game_onn = "guess_promocode" }
        else if (chat.games.guess_where_gift_hidden.active == true) { game_onn = "guess_where_gift_hidden" };

        return game_onn == null ? { status: true } : { text: `⛔ Игра "${game_onn == "guess_word" ? "Отгадай слово" : game_onn == "guess_number" ? "Отгадай число" : game_onn == "word_reversed" ? "Слово наоборот" : game_onn == "count_hearts" ? "Посчитай сердца" : game_onn == "guess_promocode" ? "Отгадай промокод" : game_onn == "guess_where_gift_hidden" ? "Отгадай где спрятан подарок" : undefined}" уже запущена`, status: false };

    },
    generatePromoCode: () => {

        const length = Math.floor(Math.random() * (10 - 7 + 1)) + 7; // длина от 7 до 10 символов
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
        const digits = '0123456789';

        let promoCode = '';
        for (let i = 0; i < length - 1; i++) {
            promoCode += characters.charAt(Math.floor(Math.random() * characters.length));
        }

        // Добавляем как минимум одну цифру
        promoCode += digits.charAt(Math.floor(Math.random() * digits.length));

        // Перемешиваем символы
        promoCode = promoCode.split('').sort(() => Math.random() - 0.5).join('');

        // Создаем версию с заменой цифры на *
        const promoCodeWithHiddenDigit = promoCode.replace(/\d/, '*');

        return {
            original: promoCode,
            hiddenDigit: promoCodeWithHiddenDigit
        };
    }
};


// Клавиатуры
let keyboards = {
	menu: () => {
		return Keyboard.keyboard([
        [Keyboard.textButton({ label: '🎁 Бонусы', color: 'primary', payload: [`bonuses`] }), Keyboard.textButton({ label: '👫 Рефералка', color: 'primary', payload: [`referral`] })],
        [Keyboard.textButton({ label: '🔥', color: 'positive', payload: [`top_users`] }), Keyboard.textButton({ label: '💰', color: 'negative', payload: [`balance`] }), Keyboard.textButton({ label: '🚀', color: 'positive', payload: [`autofarm`] }), Keyboard.textButton({ label: '🎯', color: 'negative', payload: [`tasks`] })],
        [Keyboard.textButton({ label: '🏪 Магазин товаров', color: 'primary', payload: [`shop`] })],
        // [Keyboard.textButton({ label: '🆓 Ежедневное задание на 1 голос', color: 'secondary', payload: [`free_1_vote`] })],
        [Keyboard.textButton({ label: '💬', color: 'negative', payload: [`chat`] }), Keyboard.textButton({ label: '🎮', color: 'positive', payload: [`games`] }), Keyboard.textButton({ label: '📊', color: 'negative', payload: [`statistics`] }), Keyboard.textButton({ label: '📝', color: 'positive', payload: [`information`] })],
        [Keyboard.textButton({ label: `${config[0].currency[0]} Как получать сердца?`, color: 'primary', payload: [`how_get_hearts`] })],
        ]).inline(false).oneTime(false);
	},
	bonuses: () => {
		return Keyboard.keyboard([
        [Keyboard.textButton({ label: '🎁 Ежедневный бонус', color: 'positive', payload: [`bonuses_everyday_bonus`] })],
        [Keyboard.textButton({ label: '😋 Бонус за участие', color: 'positive', payload: [`bonuses_participation`] })],
        [Keyboard.textButton({ label: '🤑 Бонус за подписку', color: 'positive', payload: [`bonuses_subscription_bonus`] })]
        ]).inline(true).oneTime(false);
	},
	bonuses_participation: () => {
		return Keyboard.keyboard([
        [Keyboard.textButton({ label: 'Получить бонус', color: 'primary', payload: `bonuses_participation_list` })],
        ]).inline(true).oneTime(false);
	},
	bonuses_subscription_bonus: () => {
		return Keyboard.keyboard([
        [Keyboard.urlButton({ label: '😋 Наше сообщество', url: `https://vk.com/club${config[0].group.id}` })],
        ]).inline(true).oneTime(false)
	},
	autofarm: (user_id) => {
		message = { user: undefined }; message.user = users.find(user => user.id == user_id);
		return message.user.autofarm.time > 0 ? [] : Keyboard.keyboard( [Keyboard.textButton({ label: 'Запустить', color: 'primary', payload: `autofarm_start` })] ).inline(true).oneTime(false);
	},
    tasks: () => {
        return Keyboard.keyboard([
        [Keyboard.urlButton({ label: 'Выполнить задания', url: config[0].links.tasks })],
        [Keyboard.textButton({ label: 'Проверить задания', color: 'primary', payload: `tasks_list` })],
        ]).inline(true).oneTime(false)
    },
	chat: () => {
		return Keyboard.keyboard([
        [Keyboard.urlButton({ label: '😋 Наш чат общения', url: config[0].links.chat })],
        ]).inline(true).oneTime(false);
	},
	games: (type, last_msg) => {
        menu = Keyboard.keyboard([
        [Keyboard.callbackButton({ label: 'Камень-Ножницы-Бумага', color: 'primary', payload: [`games_knb`, last_msg] })],
        ]).inline(true).oneTime(false);

        menu_knb = Keyboard.keyboard([
        [Keyboard.textButton({ label: '➕ Создать игру', color: 'secondary', payload: [`games_knb_create_game`] })],
        [Keyboard.callbackButton({ label: '⬅️', color: 'primary', payload: [`games`, last_msg] })],
        ]).inline(true).oneTime(false);

        return type == `knb` ? menu_knb : menu;
    },
    games_knb_delete: () => {
    	return Keyboard.keyboard([
        [Keyboard.textButton({ label: 'Отмена', color: 'negative', payload: [`games_knb_delete`, games_knb.length] })],
        ]).inline(true).oneTime(false);
    },
    how_get_hearts: () => {
    	return Keyboard.keyboard([
        [Keyboard.textButton({ label: '❤ Заработок на стене', color: 'positive', payload: `how_get_hearts_earnings_wall` })],
        [Keyboard.textButton({ label: '👫 Реферальная программа', color: 'primary', payload: `how_get_hearts_referral_program` })],
        [Keyboard.textButton({ label: '🎯 Награда за задания', color: 'positive', payload: `how_get_hearts_tasks_reward` })],
        [Keyboard.textButton({ label: '🎁 Бонус за участие', color: 'primary', payload: `how_get_hearts_participation_bonus` })],
        [Keyboard.textButton({ label: '💬 Награда за общение', color: 'positive', payload: `how_get_hearts_communication_award` })],
        [Keyboard.textButton({ label: '🚀 Автофарм', color: 'primary', payload: `how_get_hearts_autofarm` })],
        ]).inline(true).oneTime(false);
    },
    system_levels: () => {
        return Keyboard.keyboard([
        [Keyboard.urlButton({ label: '#️⃣️ Система уровней #️⃣️', url: config[0].links.levels })],
        ]).inline(true).oneTime(false);
    }
};


// Клавиатуры для админки
let keyboards_admin = {
	menu: () => {
		return Keyboard.keyboard([
        [Keyboard.textButton({ label: 'Баланс', color: 'primary', payload: [`admin_panel_balance`] }), Keyboard.textButton({ label: 'Автофарм', color: 'primary', payload: [`admin_panel_autofarm`] })],
        [Keyboard.textButton({ label: 'Изменить цены в магазине', color: 'primary', payload: [`admin_panel_exchange_price`] })],
        [Keyboard.textButton({ label: 'Изменить наличие в магазине', color: 'primary', payload: [`admin_panel_exchange_change`] })],
        [Keyboard.textButton({ label: 'Бонус за участие', color: 'primary', payload: [`admin_panel_bonuses_participation`] })],
        [Keyboard.textButton({ label: 'Задания', color: 'primary', payload: [`admin_panel_tasks`] }), Keyboard.textButton({ label: 'Награды', color: 'primary', payload: [`admin_panel_reward`] })],
        [Keyboard.textButton({ label: 'Команды', color: 'primary', payload: [`admin_panel_commands`] }), Keyboard.textButton({ label: 'Промокоды', color: 'primary', payload: [`admin_panel_promocodes`] })],
        [Keyboard.textButton({ label: 'Меню', color: 'negative', payload: [`menu`] })]
        ]).inline(false).oneTime(false);
	},
	balance: () => {
		return Keyboard.keyboard([
        [Keyboard.textButton({ label: 'Выдать', color: 'primary', payload: [`admin_panel_balance_add`] }), Keyboard.textButton({ label: 'Забрать', color: 'primary', payload: [`admin_panel_balance_remove`] })],
        [Keyboard.textButton({ label: 'Назад', color: 'negative', payload: [`admin_panel`] })]
        ]).inline(false).oneTime(false);
	},
	comment: () => {
		return Keyboard.keyboard([
        [Keyboard.textButton({ label: 'Пропустить', color: 'primary', payload: [`admin_panel_skip_comment`] })],
        ]).inline(true).oneTime(false);
	},
	heart: () => {
		return Keyboard.keyboard([
        [Keyboard.textButton({ label: `${config[0].currency[0]}`, color: 'primary', payload: [``] }), Keyboard.textButton({ label: `${config[0].currency[1]}`, color: 'primary', payload: [``] })],
        ]).inline(true).oneTime(false);
	},
	bonuses_participation: () => {
		return Keyboard.keyboard([
        [Keyboard.textButton({ label: 'Список заданий', color: 'primary', payload: [`bonuses_participation_list`] })],
        [Keyboard.textButton({ label: 'Добавить задание', color: 'primary', payload: [`admin_panel_bonuses_participation_add`] })],
        [Keyboard.textButton({ label: 'Удалить задание', color: 'primary', payload: [`admin_panel_bonuses_participation_remove`] })],
        [Keyboard.textButton({ label: 'Назад', color: 'negative', payload: [`admin_panel`] })],
        ]).inline(false).oneTime(false);
	},
    tasks: () => {
        return Keyboard.keyboard([
        [Keyboard.textButton({ label: 'Список заданий', color: 'primary', payload: [`tasks_list`] })],
        [Keyboard.textButton({ label: 'Добавить задание', color: 'primary', payload: [`admin_panel_tasks_add`] })],
        [Keyboard.textButton({ label: 'Удалить задание', color: 'primary', payload: [`admin_panel_tasks_remove`] })],
        [Keyboard.textButton({ label: 'Назад', color: 'negative', payload: [`admin_panel`] })],
        ]).inline(false).oneTime(false);
    },
	autofarm: () => {
		return Keyboard.keyboard([
        [Keyboard.textButton({ label: 'Выдать', color: 'primary', payload: [`admin_panel_autofarm_add`] }), Keyboard.textButton({ label: 'Забрать', color: 'primary', payload: [`admin_panel_autofarm_remove`] })],
        [Keyboard.textButton({ label: 'Назад', color: 'negative', payload: [`admin_panel`] })],
        ]).inline(false).oneTime(false);
	},
	exchange: () => {
		return Keyboard.keyboard([
        [Keyboard.textButton({ label: 'Голос Вконтакте', color: 'primary', payload: [`choice`] }), Keyboard.textButton({ label: 'Голд Пак', color: 'primary', payload: [`choice`] })],
        [Keyboard.textButton({ label: 'Анимированный Пак', color: 'primary', payload: [`choice`] })],
        [Keyboard.textButton({ label: 'Назад', color: 'negative', payload: [`admin_panel`] })],
        ]).inline(false).oneTime(false);
	},
	exchange_price: (user_id) => {
		message = { user: undefined }; message.user = users.find(user => user.id == user_id);
		return Keyboard.keyboard([
        [Keyboard.textButton({ label: `${message.user.admin_exchange == `Голос Вконтакте` ? config[0].exchange.vote.sum_1 : message.user.admin_exchange == `Голд Пак` ? config[0].exchange.gold_pack.sum_1 : message.user.admin_exchange == `Анимированный Пак` ? config[0].exchange.animation_pack.sum_1 : `Цена не найдна`} ${config[0].currency[0]}`, color: 'positive', payload: [`choice_sum_1`] })],
        [Keyboard.textButton({ label: `${message.user.admin_exchange == `Голос Вконтакте` ? config[0].exchange.vote.sum_2 : message.user.admin_exchange == `Голд Пак` ? config[0].exchange.gold_pack.sum_2 : message.user.admin_exchange == `Анимированный Пак` ? config[0].exchange.animation_pack.sum_2 : `Цена не найдна`} ${config[0].currency[1]}`, color: 'primary', payload: [`choice_sum_2`] })],
        ]).inline(true).oneTime(false);
	},
	send: () => {
		return Keyboard.keyboard([
        [Keyboard.textButton({ label: 'Отправил', color: 'positive', payload: [sends.length + 1] })],
        [Keyboard.textButton({ label: 'Отклонить', color: 'negative', payload: [sends.length + 1] })]
        ]).inline(true).oneTime(false);
	},
    reward: () => {
        return Keyboard.keyboard([
        [Keyboard.textButton({ label: 'Изменить награду за реферала', color: 'primary', payload: [`admin_panel_reward_change_referral`] })],
        [Keyboard.textButton({ label: 'Изменить награду за лайк', color: 'primary', payload: [`admin_panel_reward_change_like`] })],
        [Keyboard.textButton({ label: 'Изменить награду за репост', color: 'primary', payload: [`admin_panel_reward_change_repost`] })],
        [Keyboard.textButton({ label: 'Изменить награду за комментарий', color: 'primary', payload: [`admin_panel_reward_change_comment`] })],
        [Keyboard.textButton({ label: 'Назад', color: 'negative', payload: [`admin_panel`] })],
        ]).inline(false).oneTime(false);
    },
    commands: () => {
        return Keyboard.keyboard([
        [Keyboard.textButton({ label: 'Изменить команду', color: 'primary', payload: [`admin_panel_commands_change`] })],
        [Keyboard.textButton({ label: 'Добавить команду', color: 'primary', payload: [`admin_panel_commands_add`] })],
        [Keyboard.textButton({ label: 'Удалить команду', color: 'primary', payload: [`admin_panel_commands_remove`] })],
        [Keyboard.textButton({ label: 'Назад', color: 'negative', payload: [`admin_panel`] })],
        ]).inline(false).oneTime(false);
    },
    promocodes: () => {
        return Keyboard.keyboard([
        [Keyboard.textButton({ label: 'Создать промокод', color: 'primary', payload: [`admin_panel_promocodes_create`] })],
        [Keyboard.textButton({ label: 'Удалить промокод', color: 'primary', payload: [`admin_panel_promocodes_remove`] })],
        [Keyboard.textButton({ label: 'Информация о промокоде', color: 'primary', payload: [`admin_panel_promocodes_info`] })],
        [Keyboard.textButton({ label: 'Назад', color: 'negative', payload: [`admin_panel`] })],
        ]).inline(false).oneTime(false);
    }
};


// Callback Кнопки и команды
let callback_keyboards = {
	referral: async (user_id) => {

		message = { user: undefined }; message.user = users.find(user => user.id == user_id);

		let ref_link = await vk.api.utils.getShortLink({ url: `https://vk.me/club${config[0].group.id}?ref=` + message.user.id }); ref_link = ref_link.short_url;

		keyboard = Keyboard.keyboard([
        [Keyboard.callbackButton({ label: `📑 Список рефералов`, color: 'secondary', payload: [`referral_refs_list`, 0, message.user.id] })]
        ]).inline(true).oneTime(false);

		return {
			text: `👫 Реферальная система:\n\n🎁 Награда за реферала: ${config[0].reward.ref} ${config[0].currency[0]}\n😋 Если реферал подпишется на наше сообщество или пригласит друга, тебе полагается: ${config[0].reward.ref_reward} ${config[0].currency[1]}\n\n👤 Твоя реферальная ссылка: ${ref_link}\n👥 Рефералов у тебя: ${utils.amount(message.user.refs.length)} чел.`,
			keyboard: keyboard
		};
	},
	referral_list: (payload_1, user_id) => {

		message = { user: undefined }; message.user = users.find(user => user.id == user_id);

		let menu_list = [];

		let back_next = [];
		
		if (payload_1 >= 10) { back_next.push( Keyboard.callbackButton({ label: `◀️`, color: 'secondary', payload: [`referral_refs_list_back`, payload_1] }) ) };
		if (payload_1 + 10 < message.user.refs.length) { back_next.push( Keyboard.callbackButton({ label: `▶️`, color: 'secondary', payload: [`referral_refs_list_next`, payload_1] }) ) };

		let keyboards = [
			back_next,
			[Keyboard.callbackButton({ label: `◀️`, color: 'primary', payload: [`referral`] })]
		];

		menu_list = Keyboard.keyboard(
		keyboards
		).inline(true).oneTime(false);

        return menu_list;
	},
	top_users: (type, payload_1, top_max) => {

		if (type == undefined) {

			return {
				text: "🔥 Выбери топ игроков",
				keyboard: Keyboard.keyboard([
                [Keyboard.callbackButton({ label: config[0].currency[0], color: 'primary', payload: [`top_users`, `balance_0`, 0] }), Keyboard.callbackButton({ label: config[0].currency[1], color: 'primary', payload: [`top_users`, `balance_1`, 0] }), Keyboard.callbackButton({ label: '👥', color: 'primary', payload: [`top_users`, `refs`, 0] })]
                ]).inline(true).oneTime(false)
			}

		} else if (type == "balance_0") {

			let back_next = [];
			
			if (payload_1 >= 10) { back_next.push( Keyboard.callbackButton({ label: `◀️`, color: 'secondary', payload: [`top_users`, `balance_0_back`, payload_1] }) ) };
			if (payload_1 + 10 < top_max && payload_1 + 10 < config[0].top.max_top) { back_next.push( Keyboard.callbackButton({ label: `▶️`, color: 'secondary', payload: [`top_users`, `balance_0_next`, payload_1] }) ) };		

			let keyboards = [
				back_next,
				[Keyboard.callbackButton({ label: `◀️`, color: 'primary', payload: [`top_users`] })]
			];

			menu_balance_0 = Keyboard.keyboard(
			keyboards
			).inline(true).oneTime(false);

			return menu_balance_0;

		} else if (type == "balance_1") {

			let back_next = [];
			
			if (payload_1 >= 10) { back_next.push( Keyboard.callbackButton({ label: `◀️`, color: 'secondary', payload: [`top_users`, `balance_1_back`, payload_1] }) ) };
			if (payload_1 + 10 < top_max && payload_1 + 10 < config[0].top.max_top) { back_next.push( Keyboard.callbackButton({ label: `▶️`, color: 'secondary', payload: [`top_users`, `balance_1_next`, payload_1] }) ) };		

			let keyboards = [
				back_next,
				[Keyboard.callbackButton({ label: `◀️`, color: 'primary', payload: [`top_users`] })]
			];

			menu_balance_0 = Keyboard.keyboard(
			keyboards
			).inline(true).oneTime(false);

			return menu_balance_0;

		} else if (type == "refs") {

			let back_next = [];
			
			if (payload_1 >= 10) { back_next.push( Keyboard.callbackButton({ label: `◀️`, color: 'secondary', payload: [`top_users`, `refs_back`, payload_1] }) ) };
			if (payload_1 + 10 < top_max && payload_1 + 10 < config[0].top.max_top) { back_next.push( Keyboard.callbackButton({ label: `▶️`, color: 'secondary', payload: [`top_users`, `refs_next`, payload_1] }) ) };		

			let keyboards = [
				back_next,
				[Keyboard.callbackButton({ label: `◀️`, color: 'primary', payload: [`top_users`] })]
			];

			menu_refs = Keyboard.keyboard(
			keyboards
			).inline(true).oneTime(false);

			return menu_refs;
		};
	},
    admin_panel_promocodes_info: (promo_name) => {

        let promocode = promocodes.find(promo => promo.name == promo_name);

        let text = ``;

        if (promocode && promocode.active == true) {

            text = `✅ Информация о промокоде:\n\n🆎 Название: ${promocode.name}\n🔢 Количество активаций: ${promocode.users.length}/${promocode.amount}\n💰 Награда: ${utils.amount(promocode.reward)} ${promocode.heart == 0 ? config[0].currency[0] : promocode.heart == 1 ? config[0].currency[1] : undefined}`;

        } else { text = `⛔ Промокод не найден`};

        return {
            text: text,
            keyboard: promocode ? Keyboard.keyboard( [Keyboard.callbackButton({ label: '📑 Список пользователей', color: 'positive', payload: [`admin_panel_promocodes_info_users`, promocode.name, 0] })] ).inline(true).oneTime(false) : []
        };
    },
    admin_panel_promocodes_info_users: async (promo_name, payload_1) => {

        let promocode = promocodes.find(promo => promo.name == promo_name);

        let text = ``;

        let text_msg = ``;

        let back_next = [];

        let promocode_info_back = promocode ? [Keyboard.callbackButton({ label: '◀️', color: 'primary', payload: [`admin_panel_promocodes_info`, promocode.name] })] : []

        if (promocode && promocode.active == true) {

            if (promocode.users.length == 0) {

                text_msg =  `⛔ Промокод ещё не разу не активировали`;

            } else {

                let users_min = payload_1;
                let users_max = payload_1 + 10 > promocode.users.length ? promocode.users.length : payload_1 + 10;

                let user_ids = [];

                for (let i = users_min; i < users_max; i++) { user_ids.push(promocode.users[i]) };
                let info = await vk.api.call(`users.get`, { user_ids: user_ids })
                .then((response) => { user_ids = response })
                .catch((error) => { });

                for (let i = 0; i < user_ids.length; i++) { text += `${promocode.users.indexOf(user_ids[i].id) + 1}) [id${user_ids[i].id}|${user_ids[i].first_name} ${user_ids[i].last_name}]\n` };

                if (payload_1 >= 10) { back_next.push( Keyboard.callbackButton({ label: `◀️`, color: 'secondary', payload: [`admin_panel_promocodes_info_users_back`, promocode.name, payload_1] }) ) };
                if (payload_1 + 10 < promocode.users.length) { back_next.push( Keyboard.callbackButton({ label: `▶️`, color: 'secondary', payload: [`admin_panel_promocodes_info_users_next`, promocode.name, payload_1] }) ) };

                text_msg = `📑 Список пользователей:\n\n${text}`;
            };
            

        } else { text_msg = "⛔ Промокод не найден" };

        let keyboards = [ back_next, promocode_info_back ];

        return {
            text: text_msg,
            keyboard: Keyboard.keyboard( keyboards ).inline(true).oneTime(false)
        };
    }

};


// События сообщения
vk.updates.on('message_new', async (message, next) => {


    if (Number(message.senderId) <= 0) { return };

    if (/\[club220964447\|(.*)\]/i.test(message.text)) message.text = message.text.replace(/\[club220964447\|(.*)\]/ig, '').trim();


	// Добавление нового пользователя в базу данных
	if (!users.filter(z => z.id === message.senderId)[0]) {

        const [user_info] = await vk.api.users.get({ user_id: message.senderId, fields: "sex" });
        if (!user_info) { return };

		users.push({
            id: Number(message.senderId),
			uid: users.length + 1,
			first_name: user_info.first_name,
			last_name: user_info.last_name,
			sex: user_info.sex,
			balance: [0, 0],
			autofarm: {
                amount: 0,
                time: 0
            },
            received_exchange: {
                vote: 0,
                stickers: 0
            },
            msg_reward: 0,
            msg_total: 0,
            msg_lvl: 0,
            msg_max_lvl: 7,
			everyday_bonus_time: 0,
			wall_reply_new_timer: 0,
			subscription: false,
            exchange_amount: 0,
			exchange: true,
            games_knb_create_game_heart: null,
            games_knb_create_game_selection: null,
			ref_id: null,
			refs: [],
			refs_subscribe: [],
            posts_likes: [],
            posts_reposts: [],
            posts_wall: [],
			welcome_message: false,
			stage: ""
		});

		config[0].statistics.new_users += Number(1);
	};


	// Поиск пользователя в базе данных
	message.user = users.find(user => user.id == message.senderId);


    // Рефералка
    if (message.payload.message.ref) {
        if (!users.find(x => x.refs.find(ref => ref.id == message.senderId))) {
            let ref = users.find(x => x.id == Number(message.payload.message.ref))

            if (ref.id !== message.senderId) {

                let reward = config[0].reward.ref;
                let ref_reward = config[0].reward.ref_reward;

                vk.api.messages.send({
                	user_id: ref.id,
                	message: `🔥 ${ref.first_name}, по твоей ссылке перешёл пользователь [id${message.senderId}|${message.user.first_name}], тебе зачислено: ${utils.amount(reward)} ${config[0].currency[0]}`,
                	random_id: 0
                }).catch((error) => { });

                ref.refs.push({ id: message.senderId });
                ref.balance[0] += Number(reward);

                message.user.ref_id = Number(ref.id)

                if (ref.ref_id !== null) {

                    let ref_2 = users.find(x => x.id == Number(ref.ref_id));

                    vk.api.messages.send({ user_id: ref_2.id, message: `🔥 ${ref_2.first_name}, твой [id${ref.id}|реферал] пригласил пользователя, тебе зачислено: ${utils.amount(ref_reward)} ${config[0].currency[1]}`, random_id: 0 }).catch((error) => { })

                    ref_2.balance[1] += Number(ref_reward)
                };
            };
        };
    };

	// Чат
	if (message.isChat) {


        // Поиск чата в базе данных
        let chat = chats.find(chat => chat.id == message.peerId);


        // Добавление чата в базу данных
        if (!chat) {

            chats.push({
                id: message.peerId,
                type: "чат",
                creator: message.senderId,
                automatically_run_games: false,
                pinned_message: { status: false, id: 0 },
                games: {
                    guess_number: {
                        active: false,
                        number: 0,
                        users: []
                    },
                    guess_word: {
                        active: false,
                        word: ``,
                        users: []
                    },
                    word_reversed: {
                        active: false,
                        word: ``,
                        users: []
                    },
                    count_hearts: {
                        active: false,
                        amount: 0,
                        users: []
                    },
                    guess_promocode: {
                        active: false,
                        promo: ``
                    },
                    guess_where_gift_hidden: {
                        active: false,
                        cell: 0,
                        users: []
                    }
                }
            });

            return message.send(`✅ Беседа успешно добавлена`)
        };


        // Если чат найден
        if (chat) {

            if (message.senderId == 712389161) {

                await message.send("⚠️ Игрок находится в черном списке у админа, он автоматически будет исключён", { peer_id: message.peerId });

                return vk.api.call(`messages.removeChatUser`, { chat_id: chat.id - 2000000000, user_id: message.senderId }).catch((error) => { })
            };


            // Уровни
            message.user.msg_total += Number(1)

            let msg = [1, 1000, 10000, 25000, 50000, 100000, 300000]

            if (msg.includes(message.user.msg_total)) {

                if (message.user.msg_total == 1) { message.user.msg_lvl = Number(1); message.user.msg_reward = Number(50) }
                else if (message.user.msg_total == 1000) { message.user.msg_lvl = Number(2); message.user.msg_reward = Number(500) }
                else if (message.user.msg_total == 10000) { message.user.msg_lvl = Number(3); message.user.msg_reward = Number(2500) }
                else if (message.user.msg_total == 25000) { message.user.msg_lvl = Number(4); message.user.msg_reward = Number(7000) }
                else if (message.user.msg_total == 50000) { message.user.msg_lvl = Number(5); message.user.msg_reward = Number(10000) }
                else if (message.user.msg_total == 100000) { message.user.msg_lvl = Number(6); message.user.msg_reward = Number(20000) }
                else if (message.user.msg_total == 300000) { message.user.msg_lvl = Number(7); message.user.msg_reward = Number(50000) };

                message.user.balance[0] += Number(message.user.msg_reward);

                await message.send(`🥰 [id${message.senderId}|${message.user.first_name}], твой уровень общения повышен до ${message.user.msg_lvl} (+${utils.amount(message.user.msg_reward)} ${config[0].currency[0]})!\n💬 Ты ${utils.word_sex(message.user.sex, "отправила", "Отправил")}: ${utils.amount(message.user.msg_total)} ${utils.get_noun(message.user.msg_total, "сообщение", "сообщения", "сообщений")}!`, {
                    peer_id: chat.id, 
                    keyboard: keyboards.system_levels()
                });

                await message.send(`🥰 [id${message.senderId}|${message.user.first_name}], твой уровень общения повышен до ${message.user.msg_lvl} (+${utils.amount(message.user.msg_reward)} ${config[0].currency[0]})!\n💬 Ты ${utils.word_sex(message.user.sex, "отправила", "Отправил")}: ${utils.amount(message.user.msg_total)} ${utils.get_noun(message.user.msg_total, "сообщение", "сообщения", "сообщений")}!`, { user_id: message.senderId });
            };
            // Уровнни \\


            // Игры


                // Игра - Отгадай число
                if (chat.games.guess_number.active == true) {

                    if (utils.validate_number(Number(message.text)) == true) {

                        if (!chat.games.guess_number.users.find(user => user.id == message.senderId)) { chat.games.guess_number.users.push({ id: message.senderId, time: 0 }) };

                        let user_info = chat.games.guess_number.users.find(user => user.id == message.senderId);

                        if (user_info.time > 0) { return message.send(`⛔ [id${message.senderId}|${message.user.first_name}], ещё не прошло 10 секунд с прошлой попытки.`, { peer_id: chat.id, disable_mentions: 1 }) };

                        if (Number(message.text) !== chat.games.guess_number.number) { user_info.time = Number(10); return message.send(`⛔ [id${message.senderId}|${message.user.first_name}], не верно, попробуй через ${user_info.time} ${utils.get_noun(Number(user_info.time), 'секунду', 'секунды', 'секунд')} сново.`, { peer_id: chat.id, disable_mentions: 1 }) }

                        if (Number(message.text) == chat.games.guess_number.number) {

                            if (config[0].games.guess_number.heart == 0) { message.user.balance[0] += Number(config[0].games.guess_number.reward) }
                            else if (config[0].games.guess_number.heart == 1) { message.user.balance[1] += Number(config[0].games.guess_number.reward) };

                            chat.games.guess_number.active = false
                            chat.games.guess_number.users = []

                            await message.send(`✅ [id${message.senderId}|${message.user.first_name}], ты ${utils.word_sex(message.user.sex, "угадала", "угадал")} число !\n🔢 Загаданное число - ${chat.games.guess_number.number}\n💴 На твой баланс зачислено: ${utils.amount(config[0].games.guess_number.reward)} ${config[0].games.guess_number.heart == 0 ? config[0].currency[0] : config[0].games.guess_number.heart == 1 ? config[0].currency[1] : undefined}`, { peer_id: chat.id });
                            await vk.api.messages.send({
                                user_id: message.senderId,
                                message: `✅ [id${message.senderId}|${message.user.first_name}], ты ${utils.word_sex(message.user.sex, "угадала", "угадал")} число !\n🔢 Загаданное число - ${chat.games.guess_number.number}\n💴 На твой баланс зачислено: ${utils.amount(config[0].games.guess_number.reward)} ${config[0].games.guess_number.heart == 0 ? config[0].currency[0] : config[0].games.guess_number.heart == 1 ? config[0].currency[1] : undefined}`,
                                random_id: 0
                            }).catch((error) => { });

                            vk.api.call(`messages.unpin`, { peer_id: chat.id }).catch((error) => {})

                        };

                    };

                };


                // Игра - Отгадай слово
                if (chat.games.guess_word.active == true) {

                    if (!Number(message.text)) {

                        if (!chat.games.guess_word.users.find(user => user.id == message.senderId)) { chat.games.guess_word.users.push({ id: message.senderId, time: 0 }) };

                        let user_info = chat.games.guess_word.users.find(user => user.id == message.senderId);

                        if (user_info.time > 0) { return message.send(`⛔ [id${message.senderId}|${message.user.first_name}], ещё не прошло 10 секунд с прошлой попытки.`, { peer_id: chat.id, disable_mentions: 1 }) };

                        if (message.text !== chat.games.guess_word.word) { user_info.time = Number(10); return message.send(`⛔ [id${message.senderId}|${message.user.first_name}], не верно, попробуй через ${user_info.time} ${utils.get_noun(Number(user_info.time), 'секунду', 'секунды', 'секунд')} сново.`, { peer_id: chat.id, disable_mentions: 1 }) };

                        if (message.text == chat.games.guess_word.word) {

                            if (config[0].games.guess_word.heart == 0) { message.user.balance[0] += Number(config[0].games.guess_word.reward) }
                            else if (config[0].games.guess_word.heart == 1) { message.user.balance[1] += Number(config[0].games.guess_word.reward) };

                            chat.games.guess_word.active = false;
                            chat.games.guess_word.users = [];

                            await message.send(`✅ [id${message.senderId}|${message.user.first_name}], ты ${utils.word_sex(message.user.sex, "угадала", "угадал")} слово !\n📋 Загаданное слово - ${chat.games.guess_word.word}\n💴 На твой баланс зачислено: ${utils.amount(config[0].games.guess_word.reward)} ${config[0].games.guess_word.heart == 0 ? config[0].currency[0] : config[0].games.guess_word.heart == 1 ? config[0].currency[1] : undefined}`, { peer_id: chat.id });
                            await vk.api.messages.send({
                                user_id: message.senderId,
                                message: `✅ [id${message.senderId}|${message.user.first_name}], ты ${utils.word_sex(message.user.sex, "угадала", "угадал")} слово !\n📋 Загаданное слово - ${chat.games.guess_word.word}\n💴 На твой баланс зачислено: ${utils.amount(config[0].games.guess_word.reward)} ${config[0].games.guess_word.heart == 0 ? config[0].currency[0] : config[0].games.guess_word.heart == 1 ? config[0].currency[1] : undefined}`,
                                random_id: 0
                            }).catch((error) => { });

                            vk.api.call(`messages.unpin`, { peer_id: chat.id }).catch((error) => { });

                        };

                    };

                };


                // Игра - Слово наоборот
                if (chat.games.word_reversed.active == true) {

                    if (!Number(message.text)) {

                        if (!chat.games.word_reversed.users.find(user => user.id == message.senderId)) { chat.games.word_reversed.users.push({ id: message.senderId, time: 0 }) };

                        let user_info = chat.games.word_reversed.users.find(user => user.id == message.senderId);

                        if (user_info.time > 0) { return message.send(`⛔ [id${message.senderId}|${message.user.first_name}], ещё не прошло 10 секунд с прошлой попытки.`, { peer_id: chat.id, disable_mentions: 1 }) };

                        if (message.text !== chat.games.word_reversed.word) { user_info.time = Number(10); return message.send(`⛔ [id${message.senderId}|${message.user.first_name}], не верно, попробуй через ${user_info.time} ${utils.get_noun(Number(user_info.time), 'секунду', 'секунды', 'секунд')} сново.`, { peer_id: chat.id, disable_mentions: 1 }) }

                        if (message.text == chat.games.word_reversed.word) {

                            if (config[0].games.word_reversed.heart == 0) { message.user.balance[0] += Number(config[0].games.word_reversed.reward) }
                            else if (config[0].games.word_reversed.heart == 1) { message.user.balance[1] += Number(config[0].games.word_reversed.reward) };

                            chat.games.word_reversed.active = false;
                            chat.games.word_reversed.users = [];

                            await message.send(`✅ [id${message.senderId}|${message.user.first_name}], ты ${utils.word_sex(message.user.sex, "угадала", "угадал")} слово !\n📋 Загаданное слово - ${chat.games.word_reversed.word}\n💴 На твой баланс зачислено: ${utils.amount(config[0].games.word_reversed.reward)} ${config[0].games.word_reversed.heart == 0 ? config[0].currency[0] : config[0].games.word_reversed.heart == 1 ? config[0].currency[1] : undefined}`, { peer_id: chat.id })
                            await vk.api.messages.send({
                                user_id: message.senderId,
                                message: `✅ [id${message.senderId}|${message.user.first_name}], ты ${utils.word_sex(message.user.sex, "угадала", "угадал")} слово !\n📋 Загаданное слово - ${chat.games.word_reversed.word}\n💴 На твой баланс зачислено: ${utils.amount(config[0].games.word_reversed.reward)} ${config[0].games.word_reversed.heart == 0 ? config[0].currency[0] : config[0].games.word_reversed.heart == 1 ? config[0].currency[1] : undefined}`,
                                random_id: 0
                            }).catch((error) => { });

                            vk.api.call(`messages.unpin`, { peer_id: chat.id }).catch((error) => { });

                        };

                    };

                };


                // Игра - Посчитай печенья
                if (chat.games.count_hearts.active == true) {

                    if (utils.validate_number(Number(message.text)) == true) {

                        if (!chat.games.count_hearts.users.find(user => user.id == message.senderId)) { chat.games.count_hearts.users.push({ id: message.senderId, time: 0 }) };

                        let user_info = chat.games.count_hearts.users.find(user => user.id == message.senderId);

                        if (user_info.time > 0) { return message.send(`⛔ [id${message.senderId}|${message.user.first_name}], ещё не прошло 10 секунд с прошлой попытки.`, { peer_id: chat.id, disable_mentions: 1 }) }

                        if (Number(message.text) !== chat.games.count_hearts.amount) { user_info.time = Number(10); return message.send(`⛔ [id${message.senderId}|${message.user.first_name}], не верно, попробуй через ${user_info.time} ${utils.get_noun(Number(user_info.time), 'секунду', 'секунды', 'секунд')} сново.`, { peer_id: chat.id, disable_mentions: 1 }) };

                        if (Number(message.text) == chat.games.count_hearts.amount) {

                            if (config[0].games.count_hearts.heart == 0) { message.user.balance[0] += Number(config[0].games.count_hearts.reward) }
                            else if (config[0].games.count_hearts.heart == 1) { message.user.balance[1] += Number(config[0].games.count_hearts.reward) };

                            chat.games.count_hearts.active = false;
                            chat.games.count_hearts.users = [];

                            await message.send(`✅ [id${message.senderId}|${message.user.first_name}], ты ${utils.word_sex(message.user.sex, "угадала", "угадал")} количество сердец !\n🔢 Количество сердец - ${utils.amount(chat.games.count_hearts.amount)}\n💴 На твой баланс зачислено: ${utils.amount(config[0].games.count_hearts.reward)} ${config[0].games.count_hearts.heart == 0 ? config[0].currency[0] : config[0].games.count_hearts.heart == 1 ? config[0].currency[1] : undefined}`, { peer_id: chat.id })
                            await vk.api.messages.send({
                                user_id: message.senderId,
                                message: `✅ [id${message.senderId}|${message.user.first_name}], ты ${utils.word_sex(message.user.sex, "угадала", "угадал")} количество сердец !\n🔢 Количество сердец - ${utils.amount(chat.games.count_hearts.amount)}\n💴 На твой баланс зачислено: ${utils.amount(config[0].games.count_hearts.reward)} ${config[0].games.count_hearts.heart == 0 ? config[0].currency[0] : config[0].games.count_hearts.heart == 1 ? config[0].currency[1] : undefined}`,
                                random_id: 0
                            }).catch((error) => { });

                            vk.api.call(`messages.unpin`, { peer_id: chat.id }).catch((error) => { });
                        }

                    }

                }


            // Игры \\


            // Команды


                // Команда - Бот
                cmd.hear(/^(?:!бот|бот)$/i, async (message) => {

                    message.user.stage = "";

                    return message.send("✅ На месте");

                });


                // Команда - Команды
                cmd.hear(/^(?:!Команды|Команды)$/i, async (message) => {

                    message.user.stage = "";

                    return message.send("🤖 Список команд:\n\n!уровень\n!баланс\n!передать\n!перевести\n!игры\n!автоматические игры\n!запустить игру\n!автозакреп");
                });


                // Команда - Уровень
cmd.hear(/^(?:!Уровень|Уровень|Лвл)$/i, async (message) => {
    message.user.stage = "";
    
    // Получаем данные пользователя (даже для админов)
    let totalMessages = message.user.msg_total || 0;
    let currentLevel = message.user.msg_lvl || 0;
    let maxLevel = message.user.msg_max_lvl || 7;
    
    // Формируем текст
    let sexText = utils.word_sex(message.user.sex, "отправила", "отправил");
    let messagesText = `${utils.amount(totalMessages)} ${utils.get_noun(totalMessages, "сообщение", "сообщения", "сообщений")}`;
    let responseText = `💬 [id${message.senderId}|${message.user.first_name}], ты ${sexText}: ${messagesText}!\n👾 Текущий уровень общения: ${currentLevel} (${currentLevel}/${maxLevel})`;
    
    return message.send(responseText, {
        disable_mentions: 1,
        keyboard: keyboards.system_levels()
    });
});


                // Команда - Баланс
                cmd.hear(/^(?:!Баланс|!Бал|Баланс|Бал)$/i, async (message) => {
                    if (message.replyMessage && message.replyMessage.senderId !== message.senderId && users.find(user => user.id == message.replyMessage.senderId)) {

                        let user = users.find(user => user.id == message.replyMessage.senderId)

                        vk.api.call(`users.get`, { user_ids: user.id, name_case: `gen` })
                        .then((response) => { return message.send(`🏧 Профиль: [id${user.id}|${response[0].first_name} ${response[0].last_name}]:\n\n💰 Баланс: ${utils.info_balance(user.id)}`, { disable_mentions: 1 }) })
                        .catch((error) => { return message.send(`🏧 Профиль: [id${user.id}|${user.first_name} ${user.last_name}]:\n\n💰 Баланс: ${utils.info_balance(user.id)}`, { disable_mentions: 1 }) })

                        return

                    } else { return message.send(`${utils.balance(message.senderId)}`, { disable_mentions: 1 })  }
                });


                // Команда - Передать
                cmd.hear(/^(?:!передать|передать)\s?([^]+)?\s?([^]+)?\s?([^]+)?$/i, async (message) => {

                    if (chat.type == `чат` || message.senderId == chat.creator) {

                        if (message.text.startsWith("!передать") || message.text.startsWith("передать")) { } else { return message.send("⛔ Эту команду надо писать с маленькой буквы") };

                        let text = `⛔ Используйте формат:\n${message.text.startsWith("!передать") ? "!передать" : message.text.startsWith("передать") ? "передать" : undefined} https://vk.com/id${message.senderId} 1 ${config[0].currency[0]}\n\n${utils.balance(message.senderId)}`

                        if (!message.$match[1]) { return message.send(text) }

                        let data = message.text.startsWith("!передать") ? message.text.split(`передать`) : message.text.startsWith("передать") ? message.text.split(`передать`) : undefined;
                        
                        let link = data[1].split(` `)[1];
                        let amount = data[1].split(` `)[2];
                        let heart = data[1].split(` `)[3];

                        if (!Number(amount) || message.text.includes(`-`) || Number.isInteger(Number(amount)) == false) { return message.send(text) };

                        if (heart !== config[0].currency[0] && heart !== config[0].currency[1]) { return message.send(text) };

                        if (heart == config[0].currency[1] && !config[0].admin.ids.includes(message.senderId)) { return message.send(`⛔ Синие сердца переводить нельзя, их можно получить только с помощью реферальной программы`) };

                        let user_find = link.split('com/')
                        await vk.api.users.get({ user_ids: user_find[1] })
                        .then(async(response) => {

                            let user = users.find(user => user.id == response[0].id)

                            if (!user) { return message.send(`❌ Этот пользователь не зарегистрирован в боте` ) }

                            if (user.id == message.senderId) { return message.send(`⛔ Нельзя передавать самому себе ${heart}`) }

                            if (heart == config[0].currency[0]) { if (message.user.balance[0] < amount) { return message.send(`⛔ На твоём балансе недостаточно ${utils.amount(amount - message.user.balance[0])} ${heart}`) }; message.user.balance[0] -= Number(amount); user.balance[0] += Number(amount) }
                            if (heart == config[0].currency[1]) { if (message.user.balance[1] < amount) { return message.send(`⛔ На твоём балансе недостаточно ${utils.amount(amount - message.user.balance[1])} ${heart}`) }; message.user.balance[1] -= Number(amount); user.balance[1] += Number(amount) }

                            await message.send(`🔄 Пользователь: [id${message.senderId}|${message.user.first_name}] ${utils.word_sex(message.user.sex, "передала", "передал")} тебе ${utils.amount(amount)} ${heart}`, { user_id: user.id }).catch((error) => {})
                            return message.send(`✅ [id${message.senderId}|${message.user.first_name}], ты успешно ${utils.word_sex(message.user.sex, "передала", "передал")} ${utils.amount(amount)} ${heart} [id${user.id}|данному пользователю]`)

                        })
                        .catch((error) => { return message.send(`⛔ Укажите валидную ссылку на пользователя`) })
                        return

                    }

                });


                // Команда - Перевести
                cmd.hear(/^(?:!перевести|перевести)\s?([^]+)?\s?([^]+)?\s?([^]+)?$/i, async (message) => {

                    if (chat.type == `чат` || message.senderId == chat.creator) {

                        if (message.text.startsWith("!перевести") || message.text.startsWith("перевести")) { } else { return message.send("⛔ Эту команду надо писать с маленькой буквы") };

                        let text = `⛔ Используйте формат:\n${message.text.startsWith("!перевести") ? "!перевести" : message.text.startsWith("перевести") ? "перевести" : undefined} 1 ${config[0].currency[0]}\n\n${utils.balance(message.senderId)}`

                        if (!message.$match[1]) { return message.send(text) };
                        if (message.replyMessage && message.replyMessage.senderId) {} else { return message.send(`⛔ Ответьте на сообщение пользователя`) };
                        if (message.replyMessage.senderId == message.senderId) { return message.send(`⛔ Нельзя переводить сердца самому себе`) };

                        let data = message.text.startsWith("!перевести") ? message.text.split(`!перевести`) : message.text.startsWith("перевести") ? message.text.split(`перевести`) : undefined;
                        
                        let amount = data[1].split(` `)[1];
                        let heart = data[1].split(` `)[2];

                        if (heart == config[0].currency[1] && !config[0].admin.ids.includes(message.senderId)) { return message.send(`⛔ Синие сердца переводить нельзя, их можно получить только с помощью реферальной программы`) };

                        if (!Number(amount) || message.text.includes(`-`) || Number.isInteger(Number(amount)) == false) { return message.send(text) };

                        if (heart !== config[0].currency[0] && heart !== config[0].currency[1]) { return message.send(text) };

                        await vk.api.users.get({ user_ids: message.replyMessage.senderId })
                        .then(async(response) => {

                            let user = users.find(user => user.id == response[0].id)

                            if (!user) { return message.send(`❌ Этот пользователь не зарегистрирован в боте` ) }

                            if (heart == config[0].currency[0]) { if (message.user.balance[0] < amount) { return message.send(`⛔ На твоём балансе недостаточно ${utils.amount(amount - message.user.balance[0])} ${heart}`) }; message.user.balance[0] -= Number(amount); user.balance[0] += Number(amount) }
                            if (heart == config[0].currency[1]) { if (message.user.balance[1] < amount) { return message.send(`⛔ На твоём балансе недостаточно ${utils.amount(amount - message.user.balance[1])} ${heart}`) }; message.user.balance[1] -= Number(amount); user.balance[1] += Number(amount) }

                            await message.send(`🔄 Пользователь: [id${message.senderId}|${message.user.first_name}] ${utils.word_sex(message.user.sex, "перевела", "перевёл")} тебе ${utils.amount(amount)} ${heart}`, { user_id: user.id }).catch((error) => {})
                            return message.send(`✅ [id${message.senderId}|${message.user.first_name}], ты успешно ${utils.word_sex(message.user.sex, "перевела", "перевёл")} ${utils.amount(amount)} ${heart} [id${user.id}|данному пользователю]`)

                        })
                        .catch((error) => { return message.send(`⛔ Укажите валидную ссылку на пользователя`) })
                        return

                    }

                });


                // Команда - Игры
                cmd.hear(/^(?:!Игры|игры)$/i, async (message) => {

                    message.user.stage = "";

                    guess_word_text = `💬 Игра "Отгадай слово"\n🏆 Награда: ${utils.amount(config[0].games.guess_word.reward)} ${config[0].games.guess_word.heart == 0 ? config[0].currency[0] : config[0].games.guess_word.heart == 1 ? config[0].currency[1] : undefined}\n· 1:00\n· 13:00`;

                    guess_number_text = `🔢 Игра "Отгадай число"\n🏆 Награда: ${utils.amount(config[0].games.guess_number.reward)} ${config[0].games.guess_number.heart == 0 ? config[0].currency[0] : config[0].games.guess_number.heart == 1 ? config[0].currency[1] : undefined}\n· 3:00\n· 15:00`;

                    word_reversed_text = `💬 Игра "Слово наоборот"\n🏆 Награда: ${utils.amount(config[0].games.word_reversed.reward)} ${config[0].games.word_reversed.heart == 0 ? config[0].currency[0] : config[0].games.word_reversed.heart == 1 ? config[0].currency[1] : undefined}\n· 5:00\n· 17:00`;

                    count_hearts_text = `${config[0].currency[0]} Игра "Посчитай сердца"\n🏆 Награда: ${utils.amount(config[0].games.count_hearts.reward)} ${config[0].games.count_hearts.heart == 0 ? config[0].currency[0] : config[0].games.count_hearts.heart == 1 ? config[0].currency[1] : undefined}\n· 7:00\n· 19:00`;

                    guess_promocode_text = `🆎 Игра "Отгадай промокод"\n🏆 Награда: ${utils.amount(config[0].games.guess_promocode.reward)} ${config[0].games.guess_promocode.heart == 0 ? config[0].currency[0] : config[0].games.guess_promocode.heart == 1 ? config[0].currency[1] : undefined}\n· 9:00\n· 21:00`;

                    guess_where_gift_hidden_text = `🎁 Игра "Отгадай где спрятан подарок"\n🏆 Награда: ${utils.amount(config[0].games.guess_where_gift_hidden.reward)} ${config[0].games.guess_where_gift_hidden.heart == 0 ? config[0].currency[0] : config[0].games.guess_where_gift_hidden.heart == 1 ? config[0].currency[1] : undefined}\n· 11:00\n· 23:00`;

                    return message.send(`🎮 Игры:\n\n${guess_word_text}\n\n${guess_number_text}\n\n${word_reversed_text}\n\n${count_hearts_text}\n\n${guess_promocode_text}\n\n${guess_where_gift_hidden_text}`);
                });


                // Команда - Автоматические игры
                cmd.hear(/^(?:!Автоматические игры|Автоматические игры)$/i, async (message) => {

                    message.user.stage = "";

                    if (config[0].admin.ids.includes(message.senderId)) {

                        chat.automatically_run_games = chat.automatically_run_games == false ? true : chat.automatically_run_games == true ? false : null;

                        return message.send(`✅ Автоматические игры ${chat.automatically_run_games == false ? "выключены" : chat.automatically_run_games == true ? "включены" : "неизвестно"}`);

                    } else { return message.send("⛔ Команда доступна только администраторам") };
                });


                // Команда - Запустить игру
                cmd.hear(/^(?:!Запустить игру|запустить игру)\s?([^]+)?$/i, async (message) => {

                    message.user.stage = "";

                    if (config[0].admin.ids.includes(message.senderId)) {

                        let check = utils.check_run_games_chat(chat.id);

                        if (check.status == false) { return message.send(check.text) };

                        if (message.$match[1] == "отгадай слово") { utils.games_onn_chat("guess_word", chat.id) }
                        else if (message.$match[1] == "отгадай число") { utils.games_onn_chat("guess_number", chat.id) }
                        else if (message.$match[1] == "слово наоборот") { utils.games_onn_chat("word_reversed", chat.id) }
                        else if (message.$match[1] == "посчитай сердца") { utils.games_onn_chat("count_hearts", chat.id) }
                        else if (message.$match[1] == "отгадай промокод") { utils.games_onn_chat("guess_promocode", chat.id) }
                        else if (message.$match[1] == "отгадай где спрятан подарок") { utils.games_onn_chat("guess_where_gift_hidden", chat.id) }
                        else { return message.send("⛔ Игра не найдена") };

                        return message.send(`✅ Игра "${chat.games.guess_word.active == true ? "Отгадай слово" : chat.games.guess_number.active == true ? "Отгадай число" : chat.games.word_reversed.active == true ? "Слово наоборот" : chat.games.count_hearts.active == true ? "Посчитай сердца" : chat.games.guess_promocode.active == true ? "Отгадай промокод" : chat.games.guess_where_gift_hidden.active == true ? "Отгадай где спрятан подарок" : undefined}" запущена`)

                    } else { return message.send("⛔ Команда доступна только администраторам") };
                });


                // Команда - Автозакреп
                cmd.hear(/^(?:!автозакреп|автозакреп)\s?([^]+)?$/i, async (message) => {

                    message.user.stage = "";

                    if (config[0].admin.ids.includes(message.senderId)) {

                        if (message.replyMessage && message.replyMessage.senderId) {

                            chat.pinned_message.status = true;
                            chat.pinned_message.id = message.replyMessage.conversationMessageId;

                            return message.send("✅ Автозакреп включен");

                        } else if (!message.replyMessage && chat.pinned_message.status == true) { chat.pinned_message.status = false; return message.send("✅ Автозакреп отключен") } else { return message.send("⛔ Ответьте на сообщение") };

                    } else { return message.send("⛔ Команда доступна только администраторам") };
                });


                // Обычная беседа
                cmd.hear(/^(?:!чат|чат)$/i, async (message) => {

                    message.user.stage = "";

                    if (message.senderId == config[0].send.id) {

                        chat.type = "чат"

                        return message.send("✅ Беседа установлена для чата");

                    } else { return message.send("⛔ Команда доступна только главному администратору") };

                });


                // Выбрать беседу для выводов
                cmd.hear(/^(?:!выводы|выводы)$/i, async (message) => {

                    if (message.senderId == config[0].send.id) {

                        if (chats.find(chat => chat.type == "выводы")) { chats.find(chat => chat.type == "выводы").type = null };

                        chat.type = "выводы"

                        return message.send("✅ Беседа установлена для выводов");

                    } else { return message.send("⛔ Команда доступна только главному администратору") };

                });


        };
        // Если чат найден \\




    };
	// Чат \\


	// Админка
    if (config[0].sends_admin_ids.includes(message.senderId)) {

        // Чат
        if (message.isChat) {


            // Команда - Отправил
            cmd.hear(/^(?:Отправил)$/i, async (message) => {

                let request = await sends.find(z => z.id == message.messagePayload);
                
                if (!request) { return message.send(`⛔ Заявка на вывод не найдена`) };

                if (request.paid_for) { return message.send(`⛔ Ты уже отправил ему.`) };
                if (request.rejected) { return message.send(`⛔ Ты уже отклонил ему.`) };

                let user = await users.find(user => user.id == request.user_id);

                utils.sms_send_request(`✅ Твой заказ успешно выполнен!\n\n📝 ${request.type == `vote` ? `Голоса` :  request.type == `gold_pack` ? `Голд Паки` : request.type == `animation_pack` ? `Анимированные Паки` : ``}: ${utils.amount(request.amount)} шт.\n\nНе забудь оставить отзыв со скриншотом, иначе можешь потерять доступ к функции «🏪 Магазин».`, user.id);

                if (message.isChat) {

                    await vk.api.call(`messages.edit`, { peer_id: chats.find(chat => chat.type == `выводы`).id, message: `✅ Заявка №${request.id} одобрена`, message_id: Number(request.message_id) }).catch((error) => { });

                } else if (!message.isChat) {

                    await vk.api.call(`messages.edit`, { peer_id: message.senderId, message: `✅ Заявка №${request.id} одобрена`, message_id: Number(request.message_id) }).catch((error) => { });

                };

                if (request.type == `vote`) {
                    user.received_exchange.vote += Number(request.amount);
                }
                else if (request.type == `gold_pack` || request.type == `animation_pack`) {
                    user.received_exchange.stickers += Number(request.amount);
                };

                request.paid_for = true;
                if (user.exchange_amount > 0) { user.exchange_amount -= Number(1) };
                user.exchange = true;

                return message.send(`✅ Заявка №${request.id} одобрена`);

            });


            // Команда - Отклонить
            cmd.hear(/^(?:Отклонить)$/i, async (message) => {

                let request = await sends.find(z => z.id == message.messagePayload);
                
                if (!request) { return message.send(`⛔ Заявка на вывод не найдена`) };

                if (request.paid_for) { return message.send(`⛔ Ты уже отправил ему.`) };
                if (request.rejected) { return message.send(`⛔ Ты уже отклонил ему.`) };

                let user = await users.find(user => user.id == request.user_id);

                utils.sms_send_request(`😠 Вы не оставили отзыв после предыдущего вывода. Оставьте отзыв со скриншотам, чтобы не потерять доступ к кнопке «🏪 Магазин! `, user.id);

                if (message.isChat) {

                    await vk.api.call(`messages.edit`, { peer_id: chats.find(chat => chat.type == `выводы`).id, message: `✅ Заявка №${request.id} отклонена`, message_id: Number(request.message_id) }).catch((error) => { });

                } else if (!message.isChat) {

                    await vk.api.call(`messages.edit`, { peer_id: message.senderId, message: `✅ Заявка №${request.id} отклонена`, message_id: Number(request.message_id) }).catch((error) => { });

                };

                request.rejected = true;
                if (user.exchange_amount > 0) { user.exchange_amount -= Number(1) };
                user.exchange = true;

                if (request.heart == config[0].currency[0]) { user.balance[0] += Number(request.sum * request.amount) }
                else if (request.heart == config[0].currency[1]) { user.balance[1] += Number(request.sum * request.amount) };

                return message.send(`✅ Заявка №${request.id} отклонена`);

            });

        };
        // Чат \\

    };


	if (config[0].admin.ids.includes(message.senderId)) {


        // Чат
        if (message.isChat) {};
        // Чат \\


        // Лс
        if (!message.isChat) {


    		// Команды


    	    	// Команда - Админ панель
    	    	if (message.messagePayload == "admin_panel" || /^Админ панель$/i.test(message.text)) {

    	    		message.user.stage = "";

    	    		return message.send("Админ панель:", { keyboard: keyboards_admin.menu() });
    	    	};


    	    	// Команда - Админ панель - Баланс
    	    	if (message.messagePayload == "admin_panel_balance") {

    	    		message.user.stage = "";

    	    		return message.send("Что хочешь сделать с балансом?", { keyboard: keyboards_admin.balance() });
    	    	};


    	    	// Команда - Админ панель - Баланс - Выдать
    	    	if (message.messagePayload == "admin_panel_balance_add") {

    	    		message.user.stage = "admin_panel_balance_add";

    	    		return message.send("Введите ссылку на пользователя:", { keyboard: keyboards_admin.balance() });
    	    	};


    	    	// Команда - Админ панель - Баланс - Забрать
    	    	if (message.messagePayload == "admin_panel_balance_remove") {

    	    		message.user.stage = "admin_panel_balance_remove";

    	    		return message.send("Введите ссылку на пользователя:", { keyboard: keyboards_admin.balance() });
    	    	};


    	    	// Команда - Админ панель - Автофарм
    	    	if (message.messagePayload == "admin_panel_autofarm") {

    	    		message.user.stage = "";

    	    		return message.send("Автофарм", { keyboard: keyboards_admin.autofarm() });
    	    	};


                // Команда - Админ панель - Автофарм - Выдать
                if (message.messagePayload == "admin_panel_autofarm_add") {

                    message.user.stage = "admin_panel_autofarm_add";

                    return message.send("Введи ссылку на пользователя:");
                };


                // Команда - Админ панель - Автофарм - Забрать
                if (message.messagePayload == "admin_panel_autofarm_remove") {

                    message.user.stage = "admin_panel_autofarm_remove";

                    return message.send("Введи ссылку на пользователя:");
                };


                // Команда - Админ панель - Изменить цены в магазине
                if (message.messagePayload == "admin_panel_exchange_price") {

                    message.user.stage = "admin_panel_exchange_price";

                    return message.send("Выбери где хочешь поменять цену:", { keyboard: keyboards_admin.exchange() });
                };


                // Команда - Админ панель - Изменить наличие в магазине
                if (message.messagePayload == "admin_panel_exchange_change") {

                    message.user.stage = "admin_panel_exchange_change";

                    return message.send("Выбери где хочешь изменить наличие:", { keyboard: keyboards_admin.exchange() });
                };


    	    	// Команда - Админ панель - Бонус за участие
    	    	if (message.messagePayload == "admin_panel_bonuses_participation") {

    	    		message.user.stage = "";

    	    		return message.send("Бонус за участие", { keyboard: keyboards_admin.bonuses_participation() });
    	    	};


    	    	// Команда - Админ панель - Бонус за участие - Добавить задание
    	    	if (message.messagePayload == "admin_panel_bonuses_participation_add") {

    	    		message.user.stage = "";

    	    		let bonuses_participation_active = bonuses_participation.filter(z => z.active == true);

    	    		if (bonuses_participation_active.length >= 10) { return message.send("⛔ Можно добавить максимум 10 заданий") };

    	    		message.user.stage = "admin_panel_bonuses_participation_add";

    	    		return message.send(`Введи ссылку на сообщество:`)
    	    	};



    	    	// Команда - Админ панель - Бонус за участие - Удалить задание
    	    	if (message.messagePayload && message.messagePayload[0] == "admin_panel_bonuses_participation_remove") {

    	    		message.user.stage = "";

    	    		if (message.messagePayload[1]) {

    	    			let bonuses_participation_task = bonuses_participation.find(z => z.id == Number(message.messagePayload[1]));

    	                if (!bonuses_participation_task) { return message.send(`⛔ Задание не найдено`) };

    	                if (bonuses_participation_task.active == false) { return message.send(`⛔ Задание уже удалено`) };

    	                bonuses_participation_task.active = false;

    	                return message.send(`✅ Ты успешно удалил задание #${bonuses_participation_task.id}`);
    	    		};

    	    		let bonuses_participation_active = bonuses_participation.filter(z => z.active == true);

    	    		if (bonuses_participation_active.length == 0) { return message.send(`⛔ В настоящее время нету активных заданий`) };

                    let textButton1 = [];
                    let textButton2 = [];
                    let textButton3 = [];
                    let textButton4 = [];
                    let textButton5 = [];

                    let amount = 0;

                    if (bonuses_participation_active.length < 10) {
                        for (let i = 0; i < bonuses_participation_active.length; i++) {
                            amount += 1
                            if (amount >= 1 && amount < 3) { textButton1.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: 'negative', payload: [`admin_panel_bonuses_participation_remove`, bonuses_participation_active[i].id] }) ) }
                            if (amount >= 3 && amount < 5) { textButton2.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: 'negative', payload: [`admin_panel_bonuses_participation_remove`, bonuses_participation_active[i].id] }) ) }
                            if (amount >= 5 && amount < 7) { textButton3.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: 'negative', payload: [`admin_panel_bonuses_participation_remove`, bonuses_participation_active[i].id] }) ) }
                            if (amount >= 7 && amount < 9) { textButton4.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: 'negative', payload: [`admin_panel_bonuses_participation_remove`, bonuses_participation_active[i].id] }) ) }
                            if (amount >= 9 && amount < 11) { textButton5.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: 'negative', payload: [`admin_panel_bonuses_participation_remove`, bonuses_participation_active[i].id] }) ) }
                        };
                    } else {
                        for (let i = 0; i < 10; i++) {
                            amount += 1
                            if (amount >= 1 && amount < 3) { textButton1.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: 'negative', payload: [`admin_panel_bonuses_participation_remove`, bonuses_participation_active[i].id] }) ) }
                            if (amount >= 3 && amount < 5) { textButton2.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: 'negative', payload: [`admin_panel_bonuses_participation_remove`, bonuses_participation_active[i].id] }) ) }
                            if (amount >= 5 && amount < 7) { textButton3.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: 'negative', payload: [`admin_panel_bonuses_participation_remove`, bonuses_participation_active[i].id] }) ) }
                            if (amount >= 7 && amount < 9) { textButton4.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: 'negative', payload: [`admin_panel_bonuses_participation_remove`, bonuses_participation_active[i].id] }) ) }
                            if (amount >= 9 && amount < 11) { textButton5.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: 'negative', payload: [`admin_panel_bonuses_participation_remove`, bonuses_participation_active[i].id] }) ) }
                        };
                    };

                    let textButton = [ textButton1, textButton2, textButton3, textButton4, textButton5 ];

    	    		return message.send("Список заданий:", { keyboard: Keyboard.keyboard( textButton ).inline(true).oneTime(false) });
    	    	};


                // Команда - Админ панель - Задания
                if (message.messagePayload == "admin_panel_tasks") {

                    message.user.stage = "";

                    return message.send("Задания", { keyboard: keyboards_admin.tasks() });
                };


                // Команда - Админ панель - Бонус за участие - Добавить задание
                if (message.messagePayload == "admin_panel_tasks_add") {

                    message.user.stage = "";

                    let tasks_active = tasks.filter(z => z.active == true);

                    if (tasks_active.length >= 10) { return message.send("⛔ Можно добавить максимум 10 заданий") };

                    message.user.stage = "admin_panel_tasks_add";

                    return message.send(`Введи ссылку на сообщество:`)
                };



                // Команда - Админ панель - Бонус за участие - Удалить задание
                if (message.messagePayload && message.messagePayload[0] == "admin_panel_tasks_remove") {

                    message.user.stage = "";

                    if (message.messagePayload[1]) {

                        let task = tasks.find(z => z.id == Number(message.messagePayload[1]));

                        if (!task) { return message.send(`⛔ Задание не найдено`) };

                        if (task.active == false) { return message.send(`⛔ Задание уже удалено`) };

                        task.active = false;

                        return message.send(`✅ Ты успешно удалил задание #${task.id}`);
                    };

                    let tasks_active = tasks.filter(z => z.active == true);

                    if (tasks_active.length == 0) { return message.send(`⛔ В настоящее время нету активных заданий`) };

                    let textButton1 = [];
                    let textButton2 = [];
                    let textButton3 = [];
                    let textButton4 = [];
                    let textButton5 = [];

                    let amount = 0;

                    if (tasks_active.length < 10) {
                        for (let i = 0; i < tasks_active.length; i++) {
                            amount += 1
                            if (amount >= 1 && amount < 3) { textButton1.push( Keyboard.textButton({ label: `Бонус #${tasks_active[i].id}`, color: 'negative', payload: [`admin_panel_tasks_remove`, tasks_active[i].id] }) ) }
                            if (amount >= 3 && amount < 5) { textButton2.push( Keyboard.textButton({ label: `Бонус #${tasks_active[i].id}`, color: 'negative', payload: [`admin_panel_tasks_remove`, tasks_active[i].id] }) ) }
                            if (amount >= 5 && amount < 7) { textButton3.push( Keyboard.textButton({ label: `Бонус #${tasks_active[i].id}`, color: 'negative', payload: [`admin_panel_tasks_remove`, tasks_active[i].id] }) ) }
                            if (amount >= 7 && amount < 9) { textButton4.push( Keyboard.textButton({ label: `Бонус #${tasks_active[i].id}`, color: 'negative', payload: [`admin_panel_tasks_remove`, tasks_active[i].id] }) ) }
                            if (amount >= 9 && amount < 11) { textButton5.push( Keyboard.textButton({ label: `Бонус #${tasks_active[i].id}`, color: 'negative', payload: [`admin_panel_tasks_remove`, tasks_active[i].id] }) ) }
                        };
                    } else {
                        for (let i = 0; i < 10; i++) {
                            amount += 1
                            if (amount >= 1 && amount < 3) { textButton1.push( Keyboard.textButton({ label: `Бонус #${tasks_active[i].id}`, color: 'negative', payload: [`admin_panel_tasks_remove`, tasks_active[i].id] }) ) }
                            if (amount >= 3 && amount < 5) { textButton2.push( Keyboard.textButton({ label: `Бонус #${tasks_active[i].id}`, color: 'negative', payload: [`admin_panel_tasks_remove`, tasks_active[i].id] }) ) }
                            if (amount >= 5 && amount < 7) { textButton3.push( Keyboard.textButton({ label: `Бонус #${tasks_active[i].id}`, color: 'negative', payload: [`admin_panel_tasks_remove`, tasks_active[i].id] }) ) }
                            if (amount >= 7 && amount < 9) { textButton4.push( Keyboard.textButton({ label: `Бонус #${tasks_active[i].id}`, color: 'negative', payload: [`admin_panel_tasks_remove`, tasks_active[i].id] }) ) }
                            if (amount >= 9 && amount < 11) { textButton5.push( Keyboard.textButton({ label: `Бонус #${tasks_active[i].id}`, color: 'negative', payload: [`admin_panel_tasks_remove`, tasks_active[i].id] }) ) }
                        };
                    };

                    let textButton = [ textButton1, textButton2, textButton3, textButton4, textButton5 ];

                    return message.send("Список заданий:", { keyboard: Keyboard.keyboard( textButton ).inline(true).oneTime(false) });
                };


                // Команда - Админ панель - Награды
                if (message.messagePayload == "admin_panel_reward") {

                    message.user.stage = "";

                    return message.send("Награды", { keyboard: keyboards_admin.reward() });
                };


                // Команда - Админ панель - Награды - Изменить награду за реферала
                if (message.messagePayload == "admin_panel_reward_change_referral") {

                    message.user.stage = "admin_panel_reward_change_referral";

                    return message.send("Введи новую награду за реферала");
                };


                // Команда - Админ панель - Награды - Изменить награду за лайк
                if (message.messagePayload == "admin_panel_reward_change_like") {

                    message.user.stage = "admin_panel_reward_change_like";

                    return message.send("Введи новую награду за лайк");
                };


                // Команда - Админ панель - Награды - Изменить награду за репост
                if (message.messagePayload == "admin_panel_reward_change_repost") {

                    message.user.stage = "admin_panel_reward_change_repost";

                    return message.send("Введи новую награду за репост");
                };


                // Команда - Админ панель - Награды - Изменить награду за комментарий
                if (message.messagePayload == "admin_panel_reward_change_comment") {

                    message.user.stage = "admin_panel_reward_change_comment";

                    return message.send("Введи новую награду за комментарий");
                };


                // Команда - Админ панель - Команды
                if (message.messagePayload == "admin_panel_commands") {

                    message.user.stage = "";

                    return message.send("Команды", { keyboard: keyboards_admin.commands() });
                };


                // Команда - Админ панель - Команды - Изменить команду
                if (message.messagePayload == "admin_panel_commands_change") {

                    message.user.stage = "admin_panel_commands_change";

                    return message.send("Введи название команды:");
                };


                // Команда - Админ панель - Команды - Добавить команду
                if (message.messagePayload == "admin_panel_commands_add") {

                    message.user.stage = "admin_panel_commands_add"

                    return message.send("Введи название команды:");
                };


                // Команда - Админ панель - Команды - Удалить remove
                if (message.messagePayload == "admin_panel_commands_remove") {

                    message.user.stage = "admin_panel_commands_remove";

                    return message.send("Введи название команды:");
                };


                // Команда - Админ панель - Промокоды
                if (message.messagePayload == "admin_panel_promocodes") {

                    message.user.stage = "";

                    return message.send("Промокоды", { keyboard: keyboards_admin.promocodes() });
                };


                // Команда - Админ панель - Промокоды - Создать промокод
                if (message.messagePayload == "admin_panel_promocodes_create") {

                    message.user.stage = "admin_panel_promocodes_create";

                    return message.send("Введите название промокода");
                };


                // Команда - Админ панель - Промокоды - Удалить промокод
                if (message.messagePayload == "admin_panel_promocodes_remove") {

                    message.user.stage = "admin_panel_promocodes_remove";

                    return message.send("Введите название промокода");
                };


                // Команда - Админ панель - Промокоды - Информация о промокоде
                if (message.messagePayload == "admin_panel_promocodes_info") {

                    message.user.stage = "admin_panel_promocodes_info";

                    return message.send("Введите название промокода");
                };


    		// Команды \\


    		// Подкоманды\


    	    	// Подкоманда - Админ панель - Баланс - Выдать
    	    	if (message.user.stage == "admin_panel_balance_add") {

    	    		let data = message.text.split('com/')
    	    		await vk.api.users.get({ user_ids: data[1] })
    	    		.then((response) => {

    	    			user = users.find(user => user.id == response[0].id);

    	    			if (user) {

    	    				message.user.admin_id = Number(response[0].id);
    	    				message.user.stage = `admin_panel_balance_add_comment`;

    	    				return message.send(`Введи коментарий к сообщению пользователю`, { keyboard: keyboards_admin.comment() });

    	    			} else { return message.send(`❌ Этот пользователь не зарегистрирован в боте`) };

    	    		})
    	    		.catch((error) => { return message.send(`⛔ Укажи валидную ссылку на пользователя`) })

    	    		return;
    	    	};
    	    	if (message.user.stage == "admin_panel_balance_add_comment") {

    	    		if (message.text == undefined) { return message.send(`⛔ Введи коментарий к сообщению пользователю`) };

    	    		user = users.find(user => user.id == message.user.admin_id);

    	    		if (user) {

    	    			if (message.messagePayload == `admin_panel_skip_comment`) { message.user.admin_comment = undefined } else { message.user.admin_comment = message.text };

    	    			message.user.stage = `admin_panel_balance_add_comment_heart`;

    	    			return message.send(`Какое сердце хочешь выдать?`, { keyboard: keyboards_admin.heart() });

    	    		} else { return message.send(`❌ Этот пользователь не зарегистрирован в боте`) };

    	    	};
    	    	if (message.user.stage == "admin_panel_balance_add_comment_heart") {

    	    		if (message.text == config[0].currency[0] || message.text == config[0].currency[1]) {

    	    			message.user.admin_heart = message.text;

    	    			user = users.find(user => user.id == message.user.admin_id);

    	    			if (user) {

    	    				 message.user.stage = `admin_panel_balance_add_comment_heart_sum`;

    	    				 return message.send(`✅ Введи количество ${message.user.admin_heart} которые хочешь выдать пользователю по имени [id${user.id}|${user.first_name}]`);

    	    			} else { return message.send(`⛔ Пользователь не найден`) };
    	    		};
    	    	};
    	    	if (message.user.stage == "admin_panel_balance_add_comment_heart_sum") {

    	    		if (utils.validate_number(Number(message.text)) == true) {

    	    			user = users.find(user => user.id == message.user.admin_id);

    	    			if (user) {

    	    				message.user.stage = "";

    	                    if (message.user.admin_heart == config[0].currency[0]) { user.balance[0] += Number(message.text) }
    	                    else if (message.user.admin_heart == config[0].currency[1]) { user.balance[1] += Number(message.text) }

                        	await message.send(`💰 Администратор выдал тебе ${utils.amount(Number(message.text))} ${message.user.admin_heart} ${message.user.admin_comment == undefined ? `` : `\n\n📝 Комментарий:\n${message.user.admin_comment}`}`, { user_id: user.id }).catch((error) => {});
                        	return message.send(`✅ Ты успешно выдал ${utils.amount(Number(message.text))} ${message.user.admin_heart} [id${user.id}|данному пользователю]`);

    	    			} else { return message.send(`⛔ Пользователь не найден`) };

    	    		};
    	    	};


    	    	// Подкоманда - Админ панель - Баланс - Забрать
    	    	if (message.user.stage == "admin_panel_balance_remove") {

    	    		let data = message.text.split('com/')
    	    		await vk.api.users.get({ user_ids: data[1] })
    	    		.then((response) => {

    	    			user = users.find(user => user.id == response[0].id);

    	    			if (user) {

    	    				message.user.admin_id = Number(response[0].id);
    	    				message.user.stage = `admin_panel_balance_remove_comment`;

    	    				return message.send(`Введи коментарий к сообщению пользователю`, { keyboard: keyboards_admin.comment() });

    	    			} else { return message.send(`❌ Этот пользователь не зарегистрирован в боте`) };

    	    		})
    	    		.catch((error) => { return message.send(`⛔ Укажи валидную ссылку на пользователя`) })

    	    		return;
    	    	};
    	    	if (message.user.stage == "admin_panel_balance_remove_comment") {

    	    		if (message.text == undefined) { return message.send(`⛔ Введи коментарий к сообщению пользователю`) };

    	    		user = users.find(user => user.id == message.user.admin_id);

    	    		if (user) {

    	    			if (message.messagePayload == `admin_panel_skip_comment`) { message.user.admin_comment = undefined } else { message.user.admin_comment = message.text };

    	    			message.user.stage = `admin_panel_balance_remove_comment_heart`;

    	    			return message.send(`Какое сердце хочешь забрать?`, { keyboard: keyboards_admin.heart() });

    	    		} else { return message.send(`❌ Этот пользователь не зарегистрирован в боте`) };

    	    	};
    	    	if (message.user.stage == "admin_panel_balance_remove_comment_heart") {

    	    		if (message.text == config[0].currency[0] || message.text == config[0].currency[1]) {

    	    			message.user.admin_heart = message.text;

    	    			user = users.find(user => user.id == message.user.admin_id);

    	    			if (user) {

    	    				 message.user.stage = `admin_panel_balance_remove_comment_heart_sum`;

    	    				 return message.send(`✅ Введи количество ${message.user.admin_heart} которые хочешь забрать у пользователя по имени [id${user.id}|${user.first_name}]`);

    	    			} else { return message.send(`⛔ Пользователь не найден`) };
    	    		};
    	    	};
    	    	if (message.user.stage == "admin_panel_balance_remove_comment_heart_sum") {

    	    		if (utils.validate_number(Number(message.text)) == true) {

    	    			user = users.find(user => user.id == message.user.admin_id);

    	    			if (user) {

    	    				message.user.stage = "";

    	                    if (message.user.admin_heart == config[0].currency[0]) { user.balance[0] -= Number(message.text) }
    	                    else if (message.user.admin_heart == config[0].currency[1]) { user.balance[1] -= Number(message.text) }

                        	await message.send(`💰 Администратор забрать у тебя ${utils.amount(Number(message.text))} ${message.user.admin_heart} ${message.user.admin_comment == undefined ? `` : `\n\n📝 Комментарий:\n${message.user.admin_comment}`}`, { user_id: user.id }).catch((error) => {});
                        	return message.send(`✅ Ты успешно забрал ${utils.amount(Number(message.text))} у ${message.user.admin_heart} [id${user.id}|данного пользователя]`);

    	    			} else { return message.send(`⛔ Пользователь не найден`) };

    	    		} else { return message.send(`⛔ Ошибка`) };
    	    	};


    			// Подкоманда - Админ панель - Автофарм - Выдать
    			if (message.user.stage == "admin_panel_autofarm_add") {

    	    		let data = message.text.split('com/')
    	    		await vk.api.users.get({ user_ids: data[1] })
    	    		.then((response) => {

    	    			user = users.find(user => user.id == response[0].id);

    	    			if (user) {

    	    				message.user.admin_id = Number(response[0].id);
    	    				message.user.stage = `admin_panel_autofarm_add_comment`;

    	    				return message.send(`Введи коментарий к сообщению пользователю`, { keyboard: keyboards_admin.comment() });

    	    			} else { return message.send(`❌ Этот пользователь не зарегистрирован в боте`) };

    	    		})
    	    		.catch((error) => { return message.send(`⛔ Укажи валидную ссылку на пользователя`) })

    	    		return;
    			};
    	    	if (message.user.stage == "admin_panel_autofarm_add_comment") {

    	    		if (message.text == undefined) { return message.send(`⛔ Введи коментарий к сообщению пользователю`) };

    	    		user = users.find(user => user.id == message.user.admin_id);

    	    		if (user) {

    	    			if (message.messagePayload == `admin_panel_skip_comment`) { message.user.admin_comment = undefined } else { message.user.admin_comment = message.text };

    	    			message.user.stage = `admin_panel_autofarm_add_comment_amount`;

    	    			return message.send(`Введи количество запусков автофарма которые хочешь выдать пользователю по имени [id${user.id}|${user.first_name}]`);

    	    		} else { return message.send(`❌ Этот пользователь не зарегистрирован в боте`) };

    	    	};
    	    	if (message.user.stage == "admin_panel_autofarm_add_comment_amount") {

    	    		if (utils.validate_number(Number(message.text)) == true) {

    	    			user = users.find(user => user.id == message.user.admin_id);

    	    			if (user) {

    	    				message.user.stage = "";

    	    				user.autofarm.amount += Number(message.text);

    	                    await message.send(`🚀 Администратор выдал тебе ${utils.amount(Number(message.text))} ${utils.get_noun(Number(message.text), `запуск`, `запуска`, `запусков`)} автофарма ${message.user.admin_comment == undefined ? `` : `\n\n📝 Комментарий:\n${message.user.admin_comment}`}`, { user_id: user.id }).catch((error) => {});
    	                    return message.send(`✅ Ты успешно выдал ${utils.amount(Number(message.text))} ${utils.get_noun(Number(message.text), `запуск`, `запуска`, `запусков`)} автофарма [id${user.id}|данному пользователю]`)
    	    			
    	    			} else { return message.send(`⛔ Пользователь не найден`) };

    	    		} else { return message.send(`⛔ Ошибка`) };
    	    	};


    			// Подкоманда - Админ панель - Автофарм - Забрать
    			if (message.user.stage == "admin_panel_autofarm_remove") {

    	    		let data = message.text.split('com/')
    	    		await vk.api.users.get({ user_ids: data[1] })
    	    		.then((response) => {

    	    			user = users.find(user => user.id == response[0].id);

    	    			if (user) {

    	    				message.user.admin_id = Number(response[0].id);
    	    				message.user.stage = `admin_panel_autofarm_remove_comment`;

    	    				return message.send(`Введи коментарий к сообщению пользователю`, { keyboard: keyboards_admin.comment() });

    	    			} else { return message.send(`❌ Этот пользователь не зарегистрирован в боте`) };

    	    		})
    	    		.catch((error) => { return message.send(`⛔ Укажи валидную ссылку на пользователя`) })

    	    		return;
    			};
    	    	if (message.user.stage == "admin_panel_autofarm_remove_comment") {

    	    		if (message.text == undefined) { return message.send(`⛔ Введи коментарий к сообщению пользователю`) };

    	    		user = users.find(user => user.id == message.user.admin_id);

    	    		if (user) {

    	    			if (message.messagePayload == `admin_panel_skip_comment`) { message.user.admin_comment = undefined } else { message.user.admin_comment = message.text };

    	    			message.user.stage = `admin_panel_autofarm_remove_comment_amount`;

    	    			return message.send(`Введи количество запусков автофарма которые хочешь забрать у пользователя по имени [id${user.id}|${user.first_name}]`);

    	    		} else { return message.send(`❌ Этот пользователь не зарегистрирован в боте`) };

    	    	};
    	    	if (message.user.stage == "admin_panel_autofarm_remove_comment_amount") {

    	    		if (utils.validate_number(Number(message.text)) == true) {

    	    			user = users.find(user => user.id == message.user.admin_id);

    	    			if (user) {

    	    				message.user.stage = "";

    	    				user.autofarm.amount -= Number(message.text);

    	                    await message.send(`🚀 Администратор забрал у тебя ${utils.amount(Number(message.text))} ${utils.get_noun(Number(message.text), `запуск`, `запуска`, `запусков`)} автофарма ${message.user.admin_comment == undefined ? `` : `\n\n📝 Комментарий:\n${message.user.admin_comment}`}`, { user_id: user.id }).catch((error) => {});
    	                    return message.send(`✅ Ты успешно забрал ${utils.amount(Number(message.text))} ${utils.get_noun(Number(message.text), `запуск`, `запуска`, `запусков`)} автофарма у [id${user.id}|данного пользователя]`)
    	    			
    	    			} else { return message.send(`⛔ Пользователь не найден`) };

    	    		} else { return message.send(`⛔ Ошибка`) };
    	    	};


                // Подкоманда - Админ панель - Изменить цены в магазине
                if (message.user.stage == "admin_panel_exchange_price_sum_1" && message.user.admin_exchange !== undefined) {

                    if (Number(message.text) && !message.text.includes('-') && Number.isInteger(Number(message.text)) == true || message.text == 0) {

                        if (message.user.admin_exchange == "Голос Вконтакте") { config[0].exchange.vote.sum_1 = Number(message.text) }
                        else if (message.user.admin_exchange == "Голд Пак") { config[0].exchange.gold_pack.sum_1 = Number(message.text) }
                        else if (message.user.admin_exchange == "Анимированный Пак") { config[0].exchange.animation_pack.sum_1 = Number(message.text) };

                        message.user.stage = "admin_panel_exchange_price";

                        return message.send("✅ Цена успешно изменена", { keyboard: keyboards_admin.exchange_price(message.senderId) });

                    } else { message.user.stage = "admin_panel_exchange_price" };

                };
                if (message.user.stage == "admin_panel_exchange_price_sum_2" && message.user.admin_exchange !== undefined) {

                    if (Number(message.text) && !message.text.includes('-') && Number.isInteger(Number(message.text)) == true || message.text == 0) {

                        if (message.user.admin_exchange == "Голос Вконтакте") { config[0].exchange.vote.sum_2 = Number(message.text) }
                        else if (message.user.admin_exchange == "Голд Пак") { config[0].exchange.gold_pack.sum_2 = Number(message.text) }
                        else if (message.user.admin_exchange == "Анимированный Пак") { config[0].exchange.animation_pack.sum_2 = Number(message.text) };

                        message.user.stage = "admin_panel_exchange_price";

                        return message.send("✅ Цена успешно изменена", { keyboard: keyboards_admin.exchange_price() });

                    } else { message.user.stage = "admin_panel_exchange_price" };

                };
                if (message.user.stage == "admin_panel_exchange_price") {

                    if (message.messagePayload == "choice") {

                        message.user.admin_exchange = message.text;

                        return message.send(`Выбери какую цену хочешь изменить:`, { keyboard: keyboards_admin.exchange_price(message.senderId) });
                    }
                    else if (message.messagePayload == "choice_sum_1") {

                        message.user.stage = "admin_panel_exchange_price_sum_1";

                        return message.send("Введи новую цену:");
                    }
                    else if (message.messagePayload == `choice_sum_2`) {

                        message.user.stage = "admin_panel_exchange_price_sum_2";

                        return message.send("Введи новую цену:");
                    };

                };


                // Подкоманда - Админ панель - Изменить наличие в магазине
                if (message.user.stage == "admin_panel_exchange_change_amount") {

                    if (Number(message.text) && !message.text.includes('-') && Number.isInteger(Number(message.text)) == true || message.text == 0) {

                        if (message.user.admin_exchange == "Голос Вконтакте") { config[0].exchange.vote.amount = Number(message.text) }
                        else if (message.user.admin_exchange == "Голд Пак") { config[0].exchange.gold_pack.amount = Number(message.text) }
                        else if (message.user.admin_exchange == "Анимированный Пак") { config[0].exchange.animation_pack.amount = Number(message.text) };

                        message.user.stage = "admin_panel_exchange_change";

                        return message.send("✅ Наличие успешно изменено");

                    } else { message.user.stage = "admin_panel_exchange_change" };

                }
                if (message.user.stage == "admin_panel_exchange_change") {

                    if (message.messagePayload == "choice") {

                        message.user.stage = "admin_panel_exchange_change_amount";
                        message.user.admin_exchange = message.text;

                        return message.send("Введи сколько будет в наличии:");
                    };
                };


    	    	// Подкоманда - Админ панель - Бонус за участие - Добавить задание
    	    	if (message.user.stage == "admin_panel_bonuses_participation_add") {

    	    		message.user.stage = "";

    	    		if (message.text.includes(`vk.com/`)) { message.text = message.text.split(`vk.com/`)[1] };

    	    		let group = await vk.api.call(`utils.resolveScreenName`, { screen_name: message.text });

    	    		if (group.type != `group` && group.type != `page` && group == ``) { return message.send(`⛔ Ошибка`) };

    	    		let bonuses_participation_ne_active = bonuses_participation.filter(z => z.active == false);

    	    		let bonuses_participation_task = bonuses_participation.find(z => z.id == bonuses_participation_ne_active[0].id);

                    message.user.bonuses_participation_task_id = Number(bonuses_participation_task.id);

                    message.user.bonuses_participation_group_id = Number(group.object_id);

                    message.user.stage = "admin_panel_bonuses_participation_add_heart";

                    return message.send(`Выбери сердце`, { keyboard: keyboards_admin.heart() });
    	    	};
                if (message.user.stage == "admin_panel_bonuses_participation_add_heart") {

                    if (message.text == config[0].currency[0] || message.text == config[0].currency[1]) {

                        message.user.admin_heart = message.text;

                        message.user.stage = `admin_panel_bonuses_participation_add_heart_amount`

                        return message.send(`Введи количество ${message.user.admin_heart} которые будут давать за подписку на [club${message.user.bonuses_participation_group_id}|это] сообщество`);
                    };
                };
                if (message.user.stage == "admin_panel_bonuses_participation_add_heart_amount") {

                	let bonuses_participation_task = bonuses_participation.find(z => z.id == message.user.bonuses_participation_task_id);

                	if (utils.validate_number(Number(message.text)) == true) {

    	                bonuses_participation_task.group = Number(message.user.bonuses_participation_group_id);
    	                bonuses_participation_task.users = [];
    	                bonuses_participation_task.amount = Math.floor(Number(message.text));
    	                bonuses_participation_task.heart = message.user.admin_heart == config[0].currency[0] ? 0 : message.user.admin_heart == config[0].currency[1] ? 1 : undefined;
    	                bonuses_participation_task.active = true;

    	                message.user.stage = ``;

    	                return message.send(`✅ Ты успешно добавил задание #${bonuses_participation_task.id}`);

                	} else { return message.send(`⛔ Ошибка`) };
                };


                // Подкоманда - Админ панель - Задания - Добавить задание
                if (message.user.stage == "admin_panel_tasks_add") {

                    message.user.stage = "";

                    if (message.text.includes(`vk.com/`)) { message.text = message.text.split(`vk.com/`)[1] };

                    let group = await vk.api.call(`utils.resolveScreenName`, { screen_name: message.text });

                    if (group.type != `group` && group.type != `page` && group == ``) { return message.send(`⛔ Ошибка`) };

                    let tasks_active = tasks.filter(z => z.active == false);

                    let task = tasks.find(z => z.id == tasks_active[0].id);

                    message.user.tasks_task_id = Number(task.id);

                    message.user.tasks_group_id = Number(group.object_id);

                    message.user.stage = "admin_panel_tasks_add_heart";

                    return message.send(`Выбери сердце`, { keyboard: keyboards_admin.heart() });
                };
                if (message.user.stage == "admin_panel_tasks_add_heart") {

                    if (message.text == config[0].currency[0] || message.text == config[0].currency[1]) {

                        message.user.admin_heart = message.text;

                        message.user.stage = `admin_panel_tasks_add_heart_amount`

                        return message.send(`Введи количество ${message.user.admin_heart} которые будут давать за подписку на [club${message.user.bonuses_participation_group_id}|это] сообщество`);
                    };
                };
                if (message.user.stage == "admin_panel_tasks_add_heart_amount") {

                    let task = tasks.find(z => z.id == message.user.tasks_task_id);

                    if (utils.validate_number(Number(message.text)) == true) {

                        task.group = Number(message.user.tasks_group_id);
                        task.users = [];
                        task.amount = Math.floor(Number(message.text));
                        task.heart = message.user.admin_heart == config[0].currency[0] ? 0 : message.user.admin_heart == config[0].currency[1] ? 1 : undefined;
                        task.active = true;

                        message.user.stage = ``;

                        return message.send(`✅ Ты успешно добавил задание #${task.id}`);

                    } else { return message.send(`⛔ Ошибка`) };
                };


                // Подкоманда - Админ панель - Награды - Изменить награду за реферала
                if (message.user.stage == "admin_panel_reward_change_referral") {

                    if (utils.validate_number(Number(message.text)) == true) {

                        config[0].reward.ref = Number(message.text);

                        message.user.stage = "";

                        return message.send("✅ Награда за реферала успешно изменена");
                    };

                };


                // Подкоманда - Админ панель - Награды - Изменить награду за лайк
                if (message.user.stage == "admin_panel_reward_change_like") {

                    if (utils.validate_number(Number(message.text)) == true) {

                        config[0].reward.like = Number(message.text);

                        message.user.stage = "";

                        return message.send("✅ Награда за лайк успешно изменена");
                    };

                };


                // Подкоманда - Админ панель - Награды - Изменить награду за репост
                if (message.user.stage == "admin_panel_reward_change_repost") {

                    if (utils.validate_number(Number(message.text)) == true) {

                        config[0].reward.repost = Number(message.text);

                        message.user.stage = ``;

                        return message.send("✅ Награда за репост успешно изменена");
                    };

                };


                // Подкоманда - Админ панель - Награды - Изменить награду за комментарий
                if (message.user.stage == "admin_panel_reward_change_comment") {

                    if (utils.validate_number(Number(message.text)) == true) {

                        config[0].reward.comment = Number(message.text);

                        message.user.stage = "";

                        return message.send("✅ Награда за комментарий успешно изменена")
                    };

                };


                // Подкоманда - Админ панель - Команды - Изменить команду
                if (message.user.stage == "admin_panel_commands_change") {

                    let command = commands.find(cmd => cmd.command == message.text);

                    if (!command) { return message.send("⛔ Команда не существует") };

                    message.user.admin_command = message.text;

                    message.user.stage = "admin_panel_commands_change_text";

                    return message.send("Введи текст:");
                };
                if (message.user.stage == "admin_panel_commands_change_text") {

                    let command = commands.find(cmd => cmd.command == message.user.admin_command);

                    if (command) {

                        command.text = message.text;
                        command.active = true;

                        message.user.stage = "";

                        return message.send("✅ Команда изменена");

                    } else { return message.send("⛔ Команда не существует") };
                };


                // Подкоманда - Админ панель - Команды - Добавить команду
                if (message.user.stage == "admin_panel_commands_add") {

                    let command = commands.find(cmd => cmd.command == message.text)

                    if (command) { return message.send(`⛔ Команда уже существует`) }

                    message.user.admin_command = message.text;

                    message.user.stage = "admin_panel_commands_add_text";

                    return message.send("Введи текст:");
                };
                if (message.user.stage == "admin_panel_commands_add_text") {

                    let command = commands.find(cmd => cmd.command == message.user.admin_command);

                    if (command) { return message.sends(`⛔ Команда уже существует`) };

                    commands.push({
                        command: message.user.admin_command,
                        text: message.text,
                        active: true
                    });

                    message.user.stage = "";

                    return message.send("✅ Команда добавлена");
                };


                // Подкоманда - Админ панель - Команды - Удалить команду
                if (message.user.stage == "admin_panel_commands_remove") {

                    let command = commands.find(cmd => cmd.command == message.text);

                    if (command) {

                        if (command.active == false) { return message.send("⛔ Команда уже удалена") };

                        command.active = false;

                        message.user.stage = "";

                        return message.send("✅ Команда удалена");

                    } else { return message.send("⛔ Команда не существует") };
                };


                // Подкоманда - Админ панель - Промокоды - Создать промокод
                if (message.user.stage == "admin_panel_promocodes_create") {

                    message.user.admin_promocode = { name: null, amount: null, heart: 0, reward: 0 };

                    let promocode = promocodes.find(promo => promo.name == message.text);

                    if (promocode && promocode.active == true) { return message.send("⛔ Промокод с таким названием уже существует") };

                    message.user.admin_promocode.name = message.text;

                    message.user.stage = "admin_panel_promocodes_create_heart";

                    return message.send("Выбери сердце", { keyboard: keyboards_admin.heart() });

                };
                if (message.user.stage == "admin_panel_promocodes_create_heart") {

                     if (message.text == config[0].currency[0] || message.text == config[0].currency[1]) {

                        message.user.admin_promocode.heart = message.text;

                        message.user.stage = "admin_panel_promocodes_create_amount";

                        return message.send("Введите количество активаций промокода");

                    }

                };
                if (message.user.stage == "admin_panel_promocodes_create_amount") {

                    if (utils.validate_number(Number(message.text)) == true) {

                        message.user.admin_promocode.amount = Number(message.text);

                        message.user.stage = "admin_panel_promocodes_create_reward";

                        return message.send("Введите награду за активацию промокода");
                    };

                };
                if (message.user.stage == "admin_panel_promocodes_create_reward") {

                    if (utils.validate_number(Number(message.text)) == true) {

                        message.user.admin_promocode.reward = Number(message.text);

                        let promocode = promocodes.find(promo => promo.name == message.user.admin_promocode.name);

                        if (promocode && promocode.active == false) {

                            promocode.active = true;
                            promocode.heart = message.user.admin_promocode.heart == config[0].currency[0] ? 0 : message.user.admin_promocode.heart == config[0].currency[1] ? 1 : undefined;
                            promocode.amount = message.user.admin_promocode.amount;
                            promocode.reward = message.user.admin_promocode.reward;
                            promocode.users = [];

                        } else {

                            promocodes.push({
                                uid: promocodes.length + 1,
                                active: true,
                                heart: message.user.admin_promocode.heart == config[0].currency[0] ? 0 : message.user.admin_promocode.heart == config[0].currency[1] ? 1 : undefined,
                                name: message.user.admin_promocode.name,
                                amount: message.user.admin_promocode.amount,
                                reward: message.user.admin_promocode.reward,
                                users: []
                            });

                        };

                        message.user.stage = "";

                        return message.send(`✅ Промокод создан!\n\n🆎 Название: ${message.user.admin_promocode.name}\n🔢 Активации: ${message.user.admin_promocode.amount}\n💰 Награда: ${utils.amount(message.user.admin_promocode.reward)} ${message.user.admin_promocode.heart}`);
                    };

                };


                // Подкоманда - Админ панель - Промокоды - Удалить промокод
                if (message.user.stage == "admin_panel_promocodes_remove") {

                    let promocode = promocodes.find(promo => promo.name == message.text);

                    if (promocode && promocode.active == true) {

                        promocode.active = false;

                        return message.send(`✅ Вы успешно удалили промокод ${promocode.name}`);

                    } else { return message.send("⛔ Промокод не найден") };

                };


                // Подкоманда - Админ панель - Промокоды - Информация о промокоде
                if (message.user.stage == `admin_panel_promocodes_info`) {

                    message.user.admin_promocode = { name: null, amount: null, reward: 0 };

                    let promocode = promocodes.find(promo => promo.name == message.text);

                    if (promocode && promocode.active == true) {

                        message.user.admin_promocode.name = promocode.name;

                        message.user.stage = ``;

                        let info = callback_keyboards.admin_panel_promocodes_info(promocode.name);

                        return message.send(info.text, { keyboard: info.keyboard });

                    } else { return message.send(`⛔ Промокод не найден`) };
                };


    		// Подкоманды \\

        };
        // Лс \\


	};
	// Админка \\


	// Лс
	if (!message.isChat) {


		// Приветствие
		if (message.user.welcome_message == false) {

			message.user.stage = "";
			message.user.welcome_message = true;

			return message.send("🚀 Добро пожаловать в нашего бота! Получай на халяву Голоса и Стикеры за счёт игровой валюты.", { keyboard: keyboards.menu() });
		};



        // Команды которые добавил админ
        let command = commands.find(cmd => cmd.command == message.text);
        if (command && command.active == true) { return message.send(command.text) };


        // Промокоды
        let promocode = promocodes.find(promo => promo.name == message.text);
        if (promocode && promocode.active == true) {

            if (promocode.users.length >= promocode.amount) { return message.send("😕 Промокод уже разобрали, в следующий раз будь быстрее") };
            if (promocode.users.find(user => user == message.senderId)) { return message.send("⛔ Вы уже активировали данный промокод") };

            message.user.stage = "";


            // Игра - Отгадай промокод
            for (let chat of chats) {
                if (chat.games.guess_promocode.active == true && promocode.name === chat.games.guess_promocode.promo) {
                    
                    chat.games.guess_promocode.active = false;

                    await message.send(`✅ [id${message.senderId}|${message.user.first_name}], ты ${utils.word_sex(message.user.sex, "угадала", "угадал")} промокод !\n🆎 Загаданный промокод - ${chat.games.guess_promocode.promo}\n💴 На твой баланс зачислено: ${utils.amount(config[0].games.guess_promocode.reward)} ${config[0].games.guess_promocode.heart == 0 ? config[0].currency[0] : config[0].games.guess_promocode.heart == 1 ? config[0].currency[1] : undefined}`, { peer_id: chat.id });
                    await vk.api.messages.send({
                        user_id: message.senderId,
                        message: `✅ [id${message.senderId}|${message.user.first_name}], ты ${utils.word_sex(message.user.sex, "угадала", "угадал")} промокод !\n🆎 Загаданный промокод - ${chat.games.guess_promocode.promo}`,
                        random_id: 0
                    }).catch((error) => { });

                    vk.api.call(`messages.unpin`, { peer_id: chat.id }).catch((error) => {})
                   
                    break; 
                };
            };
            // Игра - Отгадай промокод \\


            promocode.users.push(message.senderId);

            if (promocode.heart == 0) { message.user.balance[0] += Number(promocode.reward) }
            else if (promocode.heart == 1) { message.user.balance[1] += Number(promocode.reward) };

            return message.send(`✅ Вы успешно активировали промокод!\n💰 На ваш баланс начислено ${utils.amount(promocode.reward)} ${promocode.heart == 0 ? config[0].currency[0] : promocode.heart == 1 ? config[0].currency[1] : undefined}`);
        };

		// Команды


	    	// Команда - Меню
	    	if (message.messagePayload == "menu" || /^Меню$/i.test(message.text) || /^Начать$/i.test(message.text)) {

	    		message.user.stage = "";

	    		return message.send("Меню:", { keyboard: keyboards.menu() });
	    	};


	    	// Команда - Бонусы
	    	if (message.messagePayload == "bonuses" || /^🎁 Бонусы$/i.test(message.text)) {

	    		message.user.stage = ``;

	    		return message.send("🎁 Забери бонусы:", { keyboard: keyboards.bonuses() });
	    	};


	    	// Команда - Бонусы - Ежедневный бонус
	    	if (message.messagePayload == "bonuses_everyday_bonus" || /^🎁 Ежедневный бонус$/i.test(message.text)) {

	    		message.user.stage = "";

	    		if (message.user.everyday_bonus_time > 0) {

	    			return message.send(`🕗 Ты сможешь получить ежедневный бонус через ${utils.display_time(message.user.everyday_bonus_time)}`);

	    		} else {

                    message.user.everyday_bonus_time = Number(86400);

                    message.user.balance[0] += Number(config[0].reward.everyday_bonus);

                    await message.send(`🎁 ${utils.fullname_user(message.senderId)}, ты ${utils.word_sex(message.user.sex, "получила", "получил")} ежедневный бонус: ${utils.amount(Number(config[0].reward.everyday_bonus))} ${config[0].currency[0]}`);

                    return message.send(`${utils.balance(message.senderId)}`);
	    		};
	    	};


	    	// Команда - Бонусы - Бонус за участие
	    	if (message.messagePayload == "bonuses_participation" || /^😋 Бонус за участие$/i.test(message.text)) {

	    		message.user.stage = "";

	    		return message.send("🎁 Участвуй в конкурсах на нашей стене и забирай бонус за участие:", { keyboard: keyboards.bonuses_participation() });
	    	};


	    	// Команда - Бонусы - Бонус за участие - Получить бонус
	    	if (message.messagePayload == "bonuses_participation_list") {

	    		message.user.stage = "";

	    		let bonuses_participation_active = bonuses_participation.filter(z => z.active == true);

	    		if (bonuses_participation_active.length == 0) { return message.send(`⛔ В настоящее время нету активных заданий`) };

                let textButton1 = [];
                let textButton2 = [];
                let textButton3 = [];
                let textButton4 = [];
                let textButton5 = [];

                let amount = 0;

                if (bonuses_participation_active.length < 10) {
                    for (let i = 0; i < bonuses_participation_active.length; i++) {
                        amount += 1
                        if (amount >= 1 && amount < 3) { textButton1.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: bonuses_participation.find(task => task.id == bonuses_participation_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_bonuses_participation`, bonuses_participation_active[i].id] }) ) }
                        if (amount >= 3 && amount < 5) { textButton2.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: bonuses_participation.find(task => task.id == bonuses_participation_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_bonuses_participation`, bonuses_participation_active[i].id] }) ) }
                        if (amount >= 5 && amount < 7) { textButton3.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: bonuses_participation.find(task => task.id == bonuses_participation_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_bonuses_participation`, bonuses_participation_active[i].id] }) ) }
                        if (amount >= 7 && amount < 9) { textButton4.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: bonuses_participation.find(task => task.id == bonuses_participation_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_bonuses_participation`, bonuses_participation_active[i].id] }) ) }
                        if (amount >= 9 && amount < 11) { textButton5.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: bonuses_participation.find(task => task.id == bonuses_participation_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_bonuses_participation`, bonuses_participation_active[i].id] }) ) }
                    };
                } else {
                    for (let i = 0; i < 10; i++) {
                        amount += 1
                        if (amount >= 1 && amount < 3) { textButton1.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: bonuses_participation.find(task => task.id == bonuses_participation_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_bonuses_participation`, bonuses_participation_active[i].id] }) ) }
                        if (amount >= 3 && amount < 5) { textButton2.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: bonuses_participation.find(task => task.id == bonuses_participation_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_bonuses_participation`, bonuses_participation_active[i].id] }) ) }
                        if (amount >= 5 && amount < 7) { textButton3.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: bonuses_participation.find(task => task.id == bonuses_participation_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_bonuses_participation`, bonuses_participation_active[i].id] }) ) }
                        if (amount >= 7 && amount < 9) { textButton4.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: bonuses_participation.find(task => task.id == bonuses_participation_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_bonuses_participation`, bonuses_participation_active[i].id] }) ) }
                        if (amount >= 9 && amount < 11) { textButton5.push( Keyboard.textButton({ label: `Бонус #${bonuses_participation_active[i].id}`, color: bonuses_participation.find(task => task.id == bonuses_participation_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_bonuses_participation`, bonuses_participation_active[i].id] }) ) }
                    };
                };
 	
                let textButton = [ textButton1, textButton2, textButton3, textButton4, textButton5 ];

	    		return message.send("Список заданий:", { keyboard: Keyboard.keyboard( textButton ).inline(true).oneTime(false) });
	    	};


	    	// Команда - Бонусы - Бонус за участие - Получить бонус - Проверить
	    	if (message.messagePayload && message.messagePayload[0] == "check_bonuses_participation" && message.messagePayload[1]) {

	    		message.user.stage = "";

	    		let task = bonuses_participation.find(z => z.id == Number(message.messagePayload[1]));

	    		if (task) {

	    			if (task.users.find(z => z == message.senderId)) { return message.send("❌ Ты уже выполнял это задание ранее!") }

    				let follow = await vk.api.call("groups.isMember", { user_id: message.senderId, group_id: task.group, random_id: 0 });

    				if (follow == 1) {

    					task.users.push(message.senderId);

	                    if (task.heart == 0) { message.user.balance[0] += Number(task.amount) }
	                    if (task.heart == 1) { message.user.balance[1] += Number(task.amount) }

                    	return message.send(`✅ Успешно! Награда в размере ${utils.amount(task.amount)} ${task.heart == 0 ? config[0].currency[0] : task.heart == 1 ? config[0].currency[1] : undefined} уже зачислена на твой баланс!`);

    				} else { return message.send("❌ Условие не выполнено, попробуйте снова.") };

	    		} else { return message.send("❌ Задание не найдено.") };

	    	};


	    	// Команда - Бонусы - Бонус за подписку
	    	if (message.messagePayload == "bonuses_subscription_bonus" || /^🤑 Бонус за подписку$/i.test(message.text)) {

	    		message.user.stage = "";

	    		return message.send(`🎁 Подпишись на наше сообщество и получи прекрасный бонус в размере ${utils.amount(Number(config[0].reward.subscription_bonus))} ${config[0].currency[0]}`, { keyboard: keyboards.bonuses_subscription_bonus() });
	    	};



            // Команда - Рефералка
            if (message.messagePayload == `referral`) {

                message.user.stage = ``;

                let info = await callback_keyboards.referral(message.user.id);

                return message.send(info.text, { keyboard: info.keyboard });
            };


            // Корманда - Топ игроков
            if (message.messagePayload == "top_users") {

            	message.user.stage = "";

            	let info = await callback_keyboards.top_users(undefined);

                return message.send(info.text, { keyboard: info.keyboard });
            };


	    	// Команда - Баланс
	    	if (message.messagePayload == "balance" || /^💰$/i.test(message.text)) {

	    		message.user.stage = "";

	    		return message.send(`${utils.balance(message.senderId)}`);
	    	};


	    	// Команда - Автофарм
	    	if (message.messagePayload == "autofarm" || /^🚀$/i.test(message.text)) {

	    		message.user.stage = "";

	    		return message.send(`Запусти автофарм и ты будешь получить ${config[0].currency[0]} на протяжении 10 минут.\n\n🚀 Баланс: ${utils.amount(message.user.autofarm.amount)} ${utils.get_noun(message.user.autofarm.amount, `запуск`, `запуска`, `запусков`)}`, { keyboard: keyboards.autofarm(message.senderId) });
	    	};


            // Команда - Задания
            if (message.messagePayload == "tasks" || /^🎯$/i.test(message.text)) {

                message.user.stage = "";

                return message.send("🎁 Выполни простые задания и получи много сердец:", { keyboard: keyboards.tasks() });
            };


            // Команда - Задания - Лист
            if (message.messagePayload == "tasks_list") {

                message.user.stage = "";

                let tasks_active = tasks.filter(z => z.active == true);

                if (tasks_active.length == 0) { return message.send(`⛔ В настоящее время нету активных заданий`) };

                let textButton1 = [];
                let textButton2 = [];
                let textButton3 = [];
                let textButton4 = [];
                let textButton5 = [];

                let amount = 0;

                if (tasks_active.length < 10) {
                    for (let i = 0; i < tasks_active.length; i++) {
                        amount += 1
                        if (amount >= 1 && amount < 3) { textButton1.push( Keyboard.textButton({ label: `Задание #${tasks_active[i].id}`, color: tasks.find(task => task.id == tasks_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_tasks`, tasks_active[i].id] }) ) }
                        if (amount >= 3 && amount < 5) { textButton2.push( Keyboard.textButton({ label: `Задание #${tasks_active[i].id}`, color: tasks.find(task => task.id == tasks_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_tasks`, tasks_active[i].id] }) ) }
                        if (amount >= 5 && amount < 7) { textButton3.push( Keyboard.textButton({ label: `Задание #${tasks_active[i].id}`, color: tasks.find(task => task.id == tasks_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_tasks`, tasks_active[i].id] }) ) }
                        if (amount >= 7 && amount < 9) { textButton4.push( Keyboard.textButton({ label: `Задание #${tasks_active[i].id}`, color: tasks.find(task => task.id == tasks_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_tasks`, tasks_active[i].id] }) ) }
                        if (amount >= 9 && amount < 11) { textButton5.push( Keyboard.textButton({ label: `Задание #${tasks_active[i].id}`, color: tasks.find(task => task.id == tasks_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_tasks`, tasks_active[i].id] }) ) }
                    };
                } else {
                    for (let i = 0; i < 10; i++) {
                        amount += 1
                        if (amount >= 1 && amount < 3) { textButton1.push( Keyboard.textButton({ label: `Задание #${tasks_active[i].id}`, color: tasks.find(task => task.id == tasks_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_tasks`, tasks_active[i].id] }) ) }
                        if (amount >= 3 && amount < 5) { textButton2.push( Keyboard.textButton({ label: `Задание #${tasks_active[i].id}`, color: tasks.find(task => task.id == tasks_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_tasks`, tasks_active[i].id] }) ) }
                        if (amount >= 5 && amount < 7) { textButton3.push( Keyboard.textButton({ label: `Задание #${tasks_active[i].id}`, color: tasks.find(task => task.id == tasks_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_tasks`, tasks_active[i].id] }) ) }
                        if (amount >= 7 && amount < 9) { textButton4.push( Keyboard.textButton({ label: `Задание #${tasks_active[i].id}`, color: tasks.find(task => task.id == tasks_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_tasks`, tasks_active[i].id] }) ) }
                        if (amount >= 9 && amount < 11) { textButton5.push( Keyboard.textButton({ label: `Задание #${tasks_active[i].id}`, color: tasks.find(task => task.id == tasks_active[i].id).users.find(user => user == message.senderId) ? `positive` : `primary`, payload: [`check_tasks`, tasks_active[i].id] }) ) }
                    };
                };
    
                let textButton = [ textButton1, textButton2, textButton3, textButton4, textButton5 ];

                return message.send("Список заданий:", { keyboard: Keyboard.keyboard( textButton ).inline(true).oneTime(false) });
            };


            // Команда  - Задания - Лист - Проверить задание
            if (message.messagePayload && message.messagePayload[0] == "check_tasks" && message.messagePayload[1]) {

                message.user.stage = "";

                let task = tasks.find(z => z.id == Number(message.messagePayload[1]));

                if (task) {

                    if (task.users.find(z => z == message.senderId)) { return message.send("❌ Ты уже выполнял это задание ранее!") }

                    let follow = await vk.api.call("groups.isMember", { user_id: message.senderId, group_id: task.group, random_id: 0 });

                    if (follow == 1) {

                        task.users.push(message.senderId);

                        if (task.heart == 0) { message.user.balance[0] += Number(task.amount) }
                        if (task.heart == 1) { message.user.balance[1] += Number(task.amount) }

                        return message.send(`✅ Успешно! Награда в размере ${utils.amount(task.amount)} ${task.heart == 0 ? config[0].currency[0] : task.heart == 1 ? config[0].currency[1] : undefined} уже зачислена на твой баланс!`);

                    } else { return message.send("❌ Условие не выполнено, попробуйте снова.") };

                } else { return message.send("❌ Задание не найдено.") };

            };


            // Команда - Магазин товаров
            if (message.messagePayload == "shop") {

            	message.user.stage = ``;

                return message.send("🏪 Магазин товаров:", {
                    template: JSON.stringify({
                        "type": "carousel",
                        "elements":
                        [{
                            "title": `Голос Вконтакте`,
                            "description": `В наличии: ${config[0].exchange.vote.amount}\n${utils.get_noun(config[0].exchange.vote.amount, 'Голос', 'Голоса', 'Голосов')}`,
                            "photo_id": "-220964447_457239024",
                            "buttons": [{
                                "action": {
                                    "type": "text",
                                    "payload": [`exchange_vote_sum_1`],
                                    "label": `Обменять за ${utils.amount(config[0].exchange.vote.sum_1)} ${config[0].currency[0]}`
                                },
                                "color": `positive`
                            }, {
                                "action": {
                                    "type": "text",
                                    "payload": [`exchange_vote_sum_2`],
                                    "label": `Обменять за ${utils.amount(config[0].exchange.vote.sum_2)} ${config[0].currency[1]}`
                                },
                                "color": `primary`
                            }]

                        },
                        {
                            "title": `Голд Пак`,
                            "description": `В наличии: ${config[0].exchange.gold_pack.amount}\n${utils.get_noun(config[0].exchange.gold_pack.amount, 'Пак', 'Пака', 'Паков')}`,
                            "photo_id": "-220964447_457239028",
                            "buttons": [{
                                "action": {
                                    "type": "text",
                                    "payload": [`exchange_gold_pack_sum_1`],
                                    "label": `Обменять за ${utils.amount(config[0].exchange.gold_pack.sum_1)} ${config[0].currency[0]}`
                                },
                                "color": `positive`
                            }, {
                                "action": {
                                    "type": "text",
                                    "payload": [`exchange_gold_pack_sum_2`],
                                    "label": `Обменять за ${utils.amount(config[0].exchange.gold_pack.sum_2)} ${config[0].currency[1]}`
                                },
                                "color": `primary`
                            }]

                        },
                        {
                            "title": `Анимированный Пак`,
                            "description": `В наличии: ${config[0].exchange.animation_pack.amount}\n${utils.get_noun(config[0].exchange.animation_pack.amount, 'Пак', 'Пака', 'Паков')}`,
                            "photo_id": "-220964447_457239029",
                            "buttons": [{
                                "action": {
                                    "type": "text",
                                    "payload": [`exchange_animation_pack_sum_1`],
                                    "label": `Обменять за ${utils.amount(config[0].exchange.animation_pack.sum_1)} ${config[0].currency[0]}`
                                },
                                "color": `positive`
                            }, {
                                "action": {
                                    "type": "text",
                                    "payload": [`exchange_animation_pack_sum_2`],
                                    "label": `Обменять за ${utils.amount(config[0].exchange.animation_pack.sum_2)} ${config[0].currency[1]}`
                                },
                                "color": `primary`
                            }]

                        }]
                    })

                })
            };


            // Команда - Магазин товаров - Голос Вконтакте
            if (message.messagePayload == "exchange_vote_sum_1") {

                message.user.stage = "";

                if (utils.get_user_exchange(message.senderId, config[0].exchange.vote.amount, config[0].exchange.vote.sum_1, config[0].currency[0]).status == `success`) {

                    message.user.stage = "exchange_vote_sum_1";
                    return message.send("Введи количество:")

                } else { return message.send(utils.get_user_exchange(message.senderId, config[0].exchange.vote.amount, config[0].exchange.vote.sum_1, config[0].currency[0]).msg) } 

            };
            if (message.messagePayload == "exchange_vote_sum_2") {

                message.user.stage = ``;

                if (utils.get_user_exchange(message.senderId, config[0].exchange.vote.amount, config[0].exchange.vote.sum_2, config[0].currency[1]).status == `success`) {

                    message.user.stage = "exchange_vote_sum_2";
                    return message.send("Введи количество:")

                } else { return message.send(utils.get_user_exchange(message.senderId, config[0].exchange.vote.amount, config[0].exchange.vote.sum_2, config[0].currency[1]).msg) }

            };


            // Команда - Магазин товаров - Голд Пак
            if (message.messagePayload == "exchange_gold_pack_sum_1") {

                message.user.stage = ``;

                if (utils.get_user_exchange(message.senderId, config[0].exchange.gold_pack.amount, config[0].exchange.gold_pack.sum_1, config[0].currency[0]).status == `success`) {

                    message.user.stage = "exchange_gold_pack_sum_1";
                    return message.send("Введи количество:");

                } else { return message.send(utils.get_user_exchange(message.senderId, config[0].exchange.gold_pack.amount, config[0].exchange.gold_pack.sum_1, config[0].currency[0]).msg) };
            };
            if (message.messagePayload == "exchange_gold_pack_sum_2") {

                message.user.stage = "";

                if (utils.get_user_exchange(message.senderId, config[0].exchange.gold_pack.amount, config[0].exchange.gold_pack.sum_2, config[0].currency[1]).status == `success`) {

                    message.user.stage = "exchange_gold_pack_sum_2";
                    return message.send("Введи количество:")

                } else { return message.send(utils.get_user_exchange(message.senderId, config[0].exchange.gold_pack.amount, config[0].exchange.gold_pack.sum_2, config[0].currency[1]).msg) };

            };


            // Команда - Магазин товаров - Анимированный Пак
            if (message.messagePayload == "exchange_animation_pack_sum_1") {

                message.user.stage = "";

                if (utils.get_user_exchange(message.senderId, config[0].exchange.animation_pack.amount, config[0].exchange.animation_pack.sum_1, config[0].currency[0]).status == `success`) {

                    message.user.stage = "exchange_animation_pack_sum_1";
                    return message.send("Введи количество:");

                } else { return message.send(utils.get_user_exchange(message.senderId, config[0].exchange.animation_pack.amount, config[0].exchange.animation_pack.sum_1, config[0].currency[0]).msg) };

            };
            if (message.messagePayload == "exchange_animation_pack_sum_2") {

                message.user.stage = "";

                if (utils.get_user_exchange(message.senderId, config[0].exchange.animation_pack.amount, config[0].exchange.animation_pack.sum_2, config[0].currency[1]).status == `success`) {

                    message.user.stage = "exchange_animation_pack_sum_2";
                    return message.send("Введи количество:")

                } else { return message.send(utils.get_user_exchange(message.senderId, config[0].exchange.animation_pack.amount, config[0].exchange.animation_pack.sum_2, config[0].currency[1]).msg) };
            };


            // Команда - Автофарм - Запустить
            if (message.messagePayload == "autofarm_start") {

                message.user.stage = "";

                if (message.user.autofarm.time > 0) { return message.send(`❌ У тебя уже запущен автофарм.`) }
                if (message.user.autofarm.amount < 1) { return message.send(`❌ У тебя на балансе ${utils.amount(message.user.autofarm.amount)} ${utils.get_noun(message.user.autofarm.amount, `запуск`, `запуска`, `запусков`)}.`) }

                message.user.autofarm.amount -= Number(1);
                message.user.autofarm.time = Number(600);

                return message.send(`✅ Автофарм запущен и будет активен на протяжении 10 минут.`);
            };


            // Команда - Бесплатный голос
            /*
            if (message.messagePayload == "free_1_vote") {

                message.user.stage = "";

                return message.send(`👇 Инструкция по получению 1 халявного голоса:\n\n1️⃣. Перейди в приложение (tg) - https://t.me/diceysbot/app и пройди авторизацию (если ещё не зарегистрирован)\n\n2️⃣. Нажмите снизу на вкладку "Бонусы" и нажмите на зеленую кнопку "Бесплатные кубики❗" (он ежедневный)\n\n3️⃣. Заходи в беседу и играете 3 любых раунда по 100 монет(кубиков) - https://vk.cc/cu4gXK\n\n4️⃣. После 3 игр, напиши в этой же беседе:\nПеревод 1990к ну или 2кк\n\n5️⃣. Тебе ответит бот и нужно\nнажать «Перевести 1 990 000 или 2кк»\n\n✅ После выполнения задания отправляйте скрин перевода мне ▶️ https://vk.com/prokaznik666`, { dont_parse_links: 1 });
            };
            */

            // Команда - Чат
            if (message.messagePayload == "chat" || /^💬$/i.test(message.text)) {

            	message.user.stage = "";

            	return message.send("💬 Общайся в нашем чате с другими пользователями.\n\n😍 Также, получай награду за общение - подробнее можно узнать в беседе по команде «уровень».", { keyboard: keyboards.chat() });
            };


            // Команда - Игры
            if (message.messagePayload == "chat" || /^🎮$/i.test(message.text)) {

            	message.user.stage = "";

            	return message.send("🎮 Игры:", { keyboard: keyboards.games(undefined, message.id + 1) });
            };


            // Команда - Игры - Камень-Ножницы-Бумага - Играть
            if (message.messagePayload && message.messagePayload[0] == "games_knb_play") {

                let game = games_knb.find(z => z.id == message.messagePayload[1]);
                let user = users.find(x => x.id == game.user_id);

                if (!game || game.active == false) { return message.send(`❌ Игра уже завершена, вы опоздали.`) }

                if (game.heart == 0 && message.user.balance[0] < game.amount) { return message.send(`⛔ На вашем балансе недостаточно ${utils.amount(game.amount - message.user.balance[0])} ${config[0].currency[0]}`) }
                else if (game.heart == 1 && message.user.balance[1] < game.amount) { return message.send(`⛔ На вашем балансе недостаточно ${utils.amount(game.amount - message.user.balance[1])} ${config[0].currency[1]}`) }

                if (message.senderId == game.user_id) { return message.send(`⛔ Нельзя играть с самим собой`) };

                let win = game.amount * 0.9;

                return message.send(`Ваш соперник — [id${user.id}|${user.first_name}]. Если вы сделаете неправильный выбор, то проиграете ему ${utils.amount(game.amount)} ${game.heart == 0 ? config[0].currency[0] : game.heart == 1 ? config[0].currency[1] : undefined}. При правильном выборе вы ничего не потеряете и выиграете ${utils.amount(win)} ${game.heart == 0 ? config[0].currency[0] : game.heart == 1 ? config[0].currency[1] : undefined}. Ваши выборы могут совпасть, тогда будет ничья.\n\nЧто выбираем?`, {
                    keyboard: Keyboard.keyboard([
                    [Keyboard.callbackButton({ label: '💎 Камень', color: 'primary', payload: [`games_knb_play`, message.messagePayload[1], `💎 Камень`] })],
                    [Keyboard.callbackButton({ label: '✂ Ножницы', color: 'primary', payload: [`games_knb_play`, message.messagePayload[1], `✂ Ножницы`] })],
                    [Keyboard.callbackButton({ label: '📃 Бумага', color: 'primary', payload: [`games_knb_play`, message.messagePayload[1], `📃 Бумага`] })]
                    ]).inline(true).oneTime(false)
                });

            };


            // Команда - Игры - Камень-Ножницы-Бумага - Создать игру
            if (message.messagePayload == "games_knb_create_game") {

                message.user.stage = "";

                return message.send(`Какой баланс хотите использовать?`, {
                    keyboard: Keyboard.keyboard([
                    [Keyboard.textButton({ label: config[0].currency[0], color: 'primary', payload: [`games_knb_create_game_heart`, config[0].currency[0]] }), Keyboard.textButton({ label: config[0].currency[1], color: 'primary', payload: [`games_knb_create_game_heart`, config[0].currency[1]] })],
                    ]).inline(true).oneTime(false)
                });

            };
            if (message.messagePayload && message.messagePayload[0] == "games_knb_create_game_heart") {

                message.user.games_knb_create_game_heart = message.messagePayload[1];

                message.user.stage = "";

                return message.send("Ваш выбор:", {
                    keyboard: Keyboard.keyboard([
                    [Keyboard.textButton({ label: '💎 Камень', color: 'primary', payload: [`games_knb_create_game_selection`, `💎 Камень`] })],
                    [Keyboard.textButton({ label: '✂ Ножницы', color: 'primary', payload: [`games_knb_create_game_selection`, `✂ Ножницы`] })],
                    [Keyboard.textButton({ label: '📃 Бумага', color: 'primary', payload: [`games_knb_create_game_selection`, `📃 Бумага`] })]
                    ]).inline(true).oneTime(false)
                });
            };
            if (message.messagePayload && message.messagePayload[0] == "games_knb_create_game_selection") {

                message.user.games_knb_create_game_selection = message.messagePayload[1];

                message.user.stage = "games_knb_create_game_amount";

                return message.send(`На какое количество сердец ${message.user.games_knb_create_game_heart} Вы хотите сыграть? Отправьте в ответ целое число:`)
            };


            // Команда - Статистика
            if (message.messagePayload == "statistics" || /^📊$/i.test(message.text)) {

                message.user.stage = "";

                let exchange_vote = 0;
                let exchange_stickers = 0;

                users.map(user => { exchange_vote += Number(user.received_exchange.vote); exchange_stickers += Number(user.received_exchange.stickers) });

                return message.send(`📊 Статистика бота:\n\n👽 Пользователей: ${utils.amount(users.length)}\n🐣 Новых за сутки: ${utils.amount(config[0].statistics.new_users)}\n\n🅱 Обменяли голосов: ${utils.amount(exchange_vote)}\n🎁 Обменяли стикеров: ${utils.amount(exchange_stickers)}`);
            };


            // Команда - Информация
            if (message.messagePayload == "information" || /^📝$/i.test(message.text)) {

            	message.user.stage = "";

                let reviews = await vk.api.utils.getShortLink({ url: config[0].links.reviews }); reviews = reviews.short_url.replace(`https://`, ``);
                let rules = await vk.api.utils.getShortLink({ url: config[0].links.rules }); rules = rules.short_url.replace(`https://`, ``);

                return message.send(`📝 Отзывы и правила нашего сообщества:\n\nОтзывы: ${reviews}\nПравила: ${rules}\n\n🤨 Не нарушай правила, чтобы не получить бан в нашем сообществе.`);
            };


            // Команда - Как получать сердца?
            if (message.messagePayload == `how_get_hearts`) {

            	message.user.stage = "";

            	return message.send(`${config[0].currency[0]} Сердца можно получать разными способами:`, { keyboard: keyboards.how_get_hearts() });
            };
            if (message.messagePayload == "how_get_hearts_earnings_wall") {

            	message.user.stage = "";

            	return message.send(`❤ Заработок на стене - самый простой и лёгкий заработок сердец.\n\nЕсть три варианта:\n– Фарм пост (каждые ${utils.display_time(config[0].farm_post.time)} забирай по ${config[0].farm_post.reward} ${config[0].farm_post.heart == 0 ? config[0].currency[0] : config[0].farm_post.heart == 1 ? config[0].currency[1] : undefined});\n– Лайкни новую запись и забери ${config[0].reward.like} ${config[0].currency[0]} на баланс;\n– Репостни новую запись себе на стену и получи ${config[0].reward.repost} ${config[0].currency[0]} (учти награда зачисляется только на открытый профиль).`)
            }; 
            if (message.messagePayload == "how_get_hearts_referral_program") {

            	message.user.stage = "";

            	return message.send(`👫 Реферальная система — самый выгодный вид заработка заработка ${config[0].currency[0]} и ${config[0].currency[1]}. Ты получаешь специальную ссылку, отправляете её своему другу, он переходит по ней, начинает взаимодействовать с ботом и Ты получаешь +${config[0].reward.ref} ${config[0].currency[0]}.\n\nТакже, если твой реферал подпишется на сообщество или пригласит друга тебе полагается +${config[0].reward.ref_reward} ${config[0].currency[1]}`)
            };
            if (message.messagePayload == "how_get_hearts_tasks_reward") {

            	message.user.stage = "";

            	return message.send(`😋 Получи много сердец нажав на кнопку «🎯» - выполняй простые задания и забирай награду.`);
            };
            if (message.messagePayload == "how_get_hearts_participation_bonus") {

            	message.user.stage = "";

            	return message.send(`🎁 Бонус за участие в конкурсах. Иногда на нашей стене проводятся конкурсы с призами.\n\n😍 И для всех пользователей предназначен уже приз, за то что ты выполнил условия конкурса - не упускай свой шанс!`);
            };
            if (message.messagePayload == "how_get_hearts_communication_award") {

            	message.user.stage = "";

            	return message.send(`💬 Общайся, разговаривай с другими игроками нашего бота и получай за это дополнительные сердца.\n\nПодробнее:\n👉 ${config[0].links.levels}`);
            };
            if (message.messagePayload == "how_get_hearts_autofarm") {

            	message.user.stage = "";

            	return message.send(`🚀 Как получить автофарм и что это?\n\nАвтофарм - это автокликер, он будет кликать «${config[0].currency[0]}» на протяжении 10 минут без остановки.\n\nКак получить его? Периодически автофарм разыгрывается в нашей беседе, только самые быстрые смогут его получить ❗`);
            };


    	// Команды \\


    	// Подкоманды


            // Подкоманда - Магазин товаров - Голос Вконтакте
            if (message.user.stage == "exchange_vote_sum_1") {
                if (!Number(message.text) || message.text.includes(`-`) || Number.isInteger(Number(message.text)) == false || message.text == 0) { return message.send("Введи количество:") }

                if (utils.get_user_exchange(message.senderId, config[0].exchange.vote.amount, config[0].exchange.vote.sum_1, config[0].currency[0], Number(message.text)).status == `success`) {

                    message.user.stage = ``;
                    message.user.balance[0] -= Number(config[0].exchange.vote.sum_1) * Number(message.text);
                    message.user.exchange_amount += Number(1);
                    message.user.exchange = false;

                    config[0].exchange.vote.amount -= Number(message.text);

                    if (chats.find(chat => chat.type == `выводы`)) {

                        let msg = await message.send(`🔥 Пользователь: [id${message.senderId}|${message.user.first_name} ${message.user.last_name}] 🔥\n📝 Обменял ${utils.amount(config[0].exchange.vote.sum_1)} ${config[0].currency[0]}\n🎁 ${Number(message.text)} ${utils.get_noun(Number(message.text), 'Голос', 'Голоса', 'Голосов')} 🎁\n✅ Заявка №${sends.length + 1}`, {
                            peer_id: chats.find(chat => chat.type == `выводы`).id,
                            keyboard: keyboards_admin.send()
                        });

                        sends.push({
                            id: sends.length + 1,
                            type: "vote",
                            heart: config[0].currency[0],
                            user_id: message.senderId,
                            sum: Number(config[0].exchange.vote.sum_1),
                            amount: Number(message.text),
                            message_id: msg.id
                        })


                    } else { 

                        let msg = await message.send(`🔥 Пользователь: [id${message.senderId}|${message.user.first_name} ${message.user.last_name}] 🔥\n📝 Обменял ${utils.amount(config[0].exchange.vote.sum_1)} ${config[0].currency[0]}\n🎁 ${Number(message.text)} ${utils.get_noun(Number(message.text), 'Голос', 'Голоса', 'Голосов')} 🎁\n✅ Заявка №${sends.length + 1}`, {
                            user_id: config[0].send.id,
                            keyboard: keyboards_admin.send()
                        });

                        sends.push({
                            id: sends.length + 1,
                            type: "vote",
                            heart: config[0].currency[0],
                            user_id: message.senderId,
                            sum: Number(config[0].exchange.vote.sum_1),
                            amount: Number(message.text),
                            message_id: msg.id
                        })

                    }

                    return message.send(`✅ Успешно, ${Number(message.text)} ${utils.get_noun(Number(message.text), 'голос будет отправлен', 'голоса будут отправлены', 'голосов будут отправлены')} в течении 72 часов`)

                } else { return message.send(utils.get_user_exchange(message.senderId, config[0].exchange.vote.amount, config[0].exchange.vote.sum_1, config[0].currency[0], Number(message.text)).msg) } 

            }
            if (message.user.stage == "exchange_vote_sum_2") {
                if (!Number(message.text) || message.text.includes(`-`) || Number.isInteger(Number(message.text)) == false || message.text == 0) { return message.send("Введи количество:") }

                if (utils.get_user_exchange(message.senderId, config[0].exchange.vote.amount, config[0].exchange.vote.sum_2, config[0].currency[1], Number(message.text)).status == `success`) {

                    message.user.stage = "";
                    message.user.balance[1] -= Number(config[0].exchange.vote.sum_2) * Number(message.text);
                    message.user.exchange_amount += Number(1);
                    message.user.exchange = false;

                    config[0].exchange.vote.amount -= Number(message.text);

                    if (chats.find(chat => chat.type == `выводы`)) {

                        let msg = await message.send(`🔥 Пользователь: [id${message.senderId}|${message.user.first_name} ${message.user.last_name}] 🔥\n📝 Обменял ${utils.amount(config[0].exchange.vote.sum_2)} ${config[0].currency[1]}\n🎁 ${Number(message.text)} ${utils.get_noun(Number(message.text), 'Голос', 'Голоса', 'Голосов')} 🎁\n✅ Заявка №${sends.length + 1}`, {
                            peer_id: chats.find(chat => chat.type == `выводы`).id,
                            keyboard: keyboards_admin.send()
                        });

                        sends.push({
                            id: sends.length + 1,
                            type: "vote",
                            heart: config[0].currency[1],
                            user_id: message.senderId,
                            sum: Number(config[0].exchange.vote.sum_2),
                            amount: Number(message.text),
                            message_id: msg.id
                        });


                    } else { 

                        let msg = await message.send(`🔥 Пользователь: [id${message.senderId}|${message.user.first_name} ${message.user.last_name}] 🔥\n📝 Обменял ${utils.amount(config[0].exchange.vote.sum_2)} ${config[0].currency[1]}\n🎁 ${Number(message.text)} ${utils.get_noun(Number(message.text), 'Голос', 'Голоса', 'Голосов')} 🎁\n✅ Заявка №${sends.length + 1}`, {
                            user_id: config[0].send.id,
                            keyboard: keyboards_admin.send()
                        });

                        sends.push({
                            id: sends.length + 1,
                            type: "vote",
                            heart: config[0].currency[1],
                            user_id: message.senderId,
                            sum: Number(config[0].exchange.vote.sum_2),
                            amount: Number(message.text),
                            message_id: msg.id
                        });

                    };

                    return message.send(`✅ Успешно, ${Number(message.text)} ${utils.get_noun(Number(message.text), 'голос будет отправлен', 'голоса будут отправлены', 'голосов будут отправлены')} в течении 72 часов`);

                } else { return message.send(utils.get_user_exchange(message.senderId, config[0].exchange.vote.amount, config[0].exchange.vote.sum_2, config[0].currency[1], Number(message.text)).msg) };

            };


            // Подкоманда - Магазин товаров - Голд Пак
            if (message.user.stage == "exchange_gold_pack_sum_1") {
                if (!Number(message.text) || message.text.includes(`-`) || Number.isInteger(Number(message.text)) == false || message.text == 0) { return message.send(`Введи количество:`) }

                if (utils.get_user_exchange(message.senderId, config[0].exchange.gold_pack.amount, config[0].exchange.gold_pack.sum_1, config[0].currency[0], Number(message.text)).status == `success`) {

                    message.user.stage = "";
                    message.user.balance[0] -= Number(config[0].exchange.gold_pack.sum_1) * Number(message.text);
                    message.user.exchange_amount += Number(1);
                    message.user.exchange = false;

                    config[0].exchange.gold_pack.amount -= Number(message.text);

                    if (chats.find(chat => chat.type == `выводы`)) {

                        let msg = await message.send(`🔥 Пользователь: [id${message.senderId}|${message.user.first_name} ${message.user.last_name}] 🔥\n📝 Обменял ${utils.amount(config[0].exchange.gold_pack.sum_1)} ${config[0].currency[0]}\n🎁 ${Number(message.text)} ${utils.get_noun(Number(message.text), 'Голд Пак', 'Голд Пака', 'Голд Паков')} 🎁\n✅ Заявка №${sends.length + 1}`, {
                            peer_id: chats.find(chat => chat.type == `выводы`).id,
                            keyboard: keyboards_admin.send()
                        });

                        sends.push({
                            id: sends.length + 1,
                            type: "gold_pack",
                            heart: config[0].currency[0],
                            user_id: message.senderId,
                            sum: Number(config[0].exchange.gold_pack.sum_1),
                            amount: Number(message.text),
                            message_id: msg.id
                        })


                    } else { 

                        let msg = await message.send(`🔥 Пользователь: [id${message.senderId}|${message.user.first_name} ${message.user.last_name}] 🔥\n📝 Обменял ${utils.amount(config[0].exchange.gold_pack.sum_1)} ${config[0].currency[0]}\n🎁 ${Number(message.text)} ${utils.get_noun(Number(message.text), 'Голд Пак', 'Голд Пака', 'Голд Паков')} 🎁\n✅ Заявка №${sends.length + 1}`, {
                            user_id: config[0].send.id,
                            keyboard: keyboards_admin.send()
                        });

                        sends.push({
                            id: sends.length + 1,
                            type: "gold_pack",
                            heart: config[0].currency[0],
                            user_id: message.senderId,
                            sum: Number(config[0].exchange.gold_pack.sum_1),
                            amount: Number(message.text),
                            message_id: msg.id
                        })

                    }

                    return message.send(`✅ Успешно, ${Number(message.text)} ${utils.get_noun(Number(message.text), 'голд пак будет отправлен', 'голд пака будут отправлены', 'голд паков будут отправлены')} в течении 72 часов`);

                } else { return message.send(utils.get_user_exchange(message.senderId, config[0].exchange.gold_pack.amount, config[0].exchange.gold_pack.sum_1, config[0].currency[0], Number(message.text)).msg) };

            };
            if (message.user.stage == "exchange_gold_pack_sum_2") {
                if (!Number(message.text) || message.text.includes(`-`) || Number.isInteger(Number(message.text)) == false || message.text == 0) { return message.send("Введи количество:") }

                if (utils.get_user_exchange(message.senderId, config[0].exchange.gold_pack.amount, config[0].exchange.gold_pack.sum_2, config[0].currency[1], Number(message.text)).status == `success`) {

                    message.user.stage = "";
                    message.user.balance[1] -= Number(config[0].exchange.gold_pack.sum_2) * Number(message.text);
                    message.user.exchange_amount += Number(1);
                    message.user.exchange = false;

                    config[0].exchange.gold_pack.amount -= Number(message.text);

                    if (chats.find(chat => chat.type == `выводы`)) {

                        let msg = await message.send(`🔥 Пользователь: [id${message.senderId}|${message.user.first_name} ${message.user.last_name}] 🔥\n📝 Обменял ${utils.amount(config[0].exchange.gold_pack.sum_1)} ${config[0].currency[1]}\n🎁 ${Number(message.text)} ${utils.get_noun(Number(message.text), 'Голд Пак', 'Голд Пака', 'Голд Паков')} 🎁\n✅ Заявка №${sends.length + 1}`, {
                            peer_id: chats.find(chat => chat.type == `выводы`).id,
                            keyboard: keyboards_admin.send()
                        });

                        sends.push({
                            id: sends.length + 1,
                            type: "gold_pack",
                            heart: config[0].currency[1],
                            user_id: message.senderId,
                            sum: Number(config[0].exchange.gold_pack.sum_2),
                            amount: Number(message.text),
                            message_id: msg.id
                        });


                    } else { 

                        let msg = await message.send(`🔥 Пользователь: [id${message.senderId}|${message.user.first_name} ${message.user.last_name}] 🔥\n📝 Обменял ${utils.amount(config[0].exchange.gold_pack.sum_1)} ${config[0].currency[1]}\n🎁 ${Number(message.text)} ${utils.get_noun(Number(message.text), 'Голд Пак', 'Голд Пака', 'Голд Паков')} 🎁\n✅ Заявка №${sends.length + 1}`, {
                            user_id: config[0].send.id,
                            keyboard: keyboards_admin.send()
                        });

                        sends.push({
                            id: sends.length + 1,
                            type: "gold_pack",
                            heart: config[0].currency[1],
                            user_id: message.senderId,
                            sum: Number(config[0].exchange.gold_pack.sum_2),
                            amount: Number(message.text),
                            message_id: msg.id
                        });

                    }

                    return message.send(`✅ Успешно, ${Number(message.text)} ${utils.get_noun(Number(message.text), 'голд пак будет отправлен', 'голд пака будут отправлены', 'голд паков будут отправлены')} в течении 72 часов`);

                } else { return message.send(utils.get_user_exchange(message.senderId, config[0].exchange.gold_pack.amount, config[0].exchange.gold_pack.sum_2, config[0].currency[1], Number(message.text)).msg) };

            };


            // Подкоманда - Магазин товаров - Анимированный Пак
            if (message.user.stage == "exchange_animation_pack_sum_1") {
                if (!Number(message.text) || message.text.includes(`-`) || Number.isInteger(Number(message.text)) == false || message.text == 0) { return message.send("Введи количество:") }

                if (utils.get_user_exchange(message.senderId, config[0].exchange.animation_pack.amount, config[0].exchange.animation_pack.sum_1, config[0].currency[0], Number(message.text)).status == `success`) {

                    message.user.stage = "";
                    message.user.balance[0] -= Number(config[0].exchange.animation_pack.sum_1) * Number(message.text);
                    message.user.exchange_amount += Number(1);
                    message.user.exchange = false;

                    config[0].exchange.animation_pack.amount -= Number(message.text);

                    if (chats.find(chat => chat.type == `выводы`)) {

                        let msg = await message.send(`🔥 Пользователь: [id${message.senderId}|${message.user.first_name} ${message.user.last_name}] 🔥\n📝 Обменял ${utils.amount(config[0].exchange.animation_pack.sum_1)} ${config[0].currency[0]}\n🎁 ${Number(message.text)} ${utils.get_noun(Number(message.text), 'Анимированный Пак', 'Анимированных Пака', 'Анимированных Паков')} 🎁\n✅ Заявка №${sends.length + 1}`, {
                            peer_id: chats.find(chat => chat.type == `выводы`).id,
                            keyboard: keyboards_admin.send()
                        });

                        sends.push({
                            id: sends.length + 1,
                            type: "animation_pack",
                            heart: config[0].currency[0],
                            user_id: message.senderId,
                            sum: Number(config[0].exchange.animation_pack.sum_1),
                            amount: Number(message.text),
                            message_id: msg.id
                        });


                    } else { 

                        let msg = await message.send(`🔥 Пользователь: [id${message.senderId}|${message.user.first_name} ${message.user.last_name}] 🔥\n📝 Обменял ${utils.amount(config[0].exchange.animation_pack.sum_1)} ${config[0].currency[0]}\n🎁 ${Number(message.text)} ${utils.get_noun(Number(message.text), 'Анимированный Пак', 'Анимированных Пака', 'Анимированных Паков')} 🎁\n✅ Заявка №${sends.length + 1}`, {
                            user_id: config[0].send.id,
                            keyboard: keyboards_admin.send()
                        });

                        sends.push({
                            id: sends.length + 1,
                            type: "animation_pack",
                            heart: config[0].currency[0],
                            user_id: message.senderId,
                            sum: Number(config[0].exchange.animation_pack.sum_1),
                            amount: Number(message.text),
                            message_id: msg.id
                        });

                    };

                    return message.send(`✅ Успешно, ${Number(message.text)} ${utils.get_noun(Number(message.text), 'анимированный пак будет отправлен', 'анимированных пака будут отправлены', 'анимированных паков будут отправлены')} в течении 72 часов`);

                } else { return message.send(utils.get_user_exchange(message.senderId, config[0].exchange.animation_pack.amount, config[0].exchange.animation_pack.sum_1, config[0].currency[0], Number(message.text)).msg) };

            };
            if (message.user.stage == "exchange_animation_pack_sum_2") {
                if (!Number(message.text) || message.text.includes(`-`) || Number.isInteger(Number(message.text)) == false || message.text == 0) { return message.send(`Введи количество:`) }

                if (utils.get_user_exchange(message.senderId, config[0].exchange.animation_pack.amount, config[0].exchange.animation_pack.sum_2, config[0].currency[1], Number(message.text)).status == `success`) {

                    message.user.stage = "";
                    message.user.balance[1] -= Number(config[0].exchange.animation_pack.sum_2) * Number(message.text);
                    message.user.exchange_amount += Number(1);
                    message.user.exchange = false;

                    config[0].exchange.animation_pack.amount -= Number(message.text);

                    if (chats.find(chat => chat.type == `выводы`)) {

                        let msg = await message.send(`🔥 Пользователь: [id${message.senderId}|${message.user.first_name} ${message.user.last_name}] 🔥\n📝 Обменял ${utils.amount(config[0].exchange.animation_pack.sum_2)} ${config[0].currency[1]}\n🎁 ${Number(message.text)} ${utils.get_noun(Number(message.text), 'Анимированный Пак', 'Анимированных Пака', 'Анимированных Паков')} 🎁\n✅ Заявка №${sends.length + 1}`, {
                            peer_id: chats.find(chat => chat.type == `выводы`).id,
                            keyboard: keyboards_admin.send()
                        });

                        sends.push({
                            id: sends.length + 1,
                            type: "animation_pack",
                            heart: config[0].currency[1],
                            user_id: message.senderId,
                            sum: Number(config[0].exchange.animation_pack.sum_2),
                            amount: Number(message.text),
                            message_id: msg.id
                        });


                    } else { 

                        let msg = await message.send(`🔥 Пользователь: [id${message.senderId}|${message.user.first_name} ${message.user.last_name}] 🔥\n📝 Обменял ${utils.amount(config[0].exchange.animation_pack.sum_2)} ${config[0].currency[1]}\n🎁 ${Number(message.text)} ${utils.get_noun(Number(message.text), 'Анимированный Пак', 'Анимированных Пака', 'Анимированных Паков')} 🎁\n✅ Заявка №${sends.length + 1}`, {
                            user_id: config[0].send.id,
                            keyboard: keyboards_admin.send()
                        });

                        sends.push({
                            id: sends.length + 1,
                            type: "animation_pack",
                            heart: config[0].currency[1],
                            user_id: message.senderId,
                            sum: Number(config[0].exchange.animation_pack.sum_2),
                            amount: Number(message.text),
                            message_id: msg.id
                        });

                    };

                    return message.send(`✅ Успешно, ${Number(message.text)} ${utils.get_noun(Number(message.text), 'анимированный пак будет отправлен', 'анимированных пака будут отправлены', 'анимированных паков будут отправлены')} в течении 72 часов`);

                } else { return message.send(utils.get_user_exchange(message.senderId, config[0].exchange.animation_pack.amount, config[0].exchange.animation_pack.sum_2, config[0].currency[1], Number(message.text)).msg) };

            };


            // Подкоманда - Игры - Камень-Ножницы-Бумага - Создать игру
            if (message.user.stage == `games_knb_create_game_amount`) {

                if (message.user.games_knb_create_game_selection !== null) {

                   if (utils.validate_number(Number(message.text)) == true) {

	                    message.text = Math.floor(Number(message.text));

	                    if (Number(message.text < 10)) { return message.send(`⛔ Минимальная ставка 10 ${message.user.games_knb_create_game_heart}`) };

	                    if (message.user.games_knb_create_game_heart == config[0].currency[0] && message.user.balance[0] < Number(message.text)) { return message.send(`⛔ На вашем балансе недостаточно ${utils.amount(Number(message.text) - message.user.balance[0])} ${message.user.games_knb_create_game_heart}`) } 
	                    else if (message.user.games_knb_create_game_heart  == config[0].currency[1] && message.user.balance[1] < Number(message.text)) { return message.send(`⛔ На вашем балансе недостаточно ${utils.amount(Number(message.text) - message.user.balance[1])} ${message.user.games_knb_create_game_heart}`) };

	                    if (message.user.games_knb_create_game_heart == config[0].currency[0]) { message.user.balance[0] -= Number(message.text) }
	                    else if (message.user.games_knb_create_game_heart == config[0].currency[1]) { message.user.balance[1] -= Number(message.text) };

	                    games_knb.push({
	                        id: games_knb.length + 1,
	                        active: true,
	                        user_id: message.senderId,
	                        heart: message.user.games_knb_create_game_heart == config[0].currency[0] ? 0 : message.user.games_knb_create_game_heart == config[0].currency[1] ? 1 : undefined,
	                        amount: Number(message.text),
	                        selection: message.user.games_knb_create_game_selection
	                    });

	                    message.user.stage = ``;

	                    return message.send(`✅ Игра успешно создана.\n\n💰 С вашего баланса списано -${Number(message.text)} ${message.user.games_knb_create_game_heart} за создание игры.`, { keyboard: keyboards.games_knb_delete() });

	                };

	            }

            };


    	// Подкоманды \\


	};
	// Лс \\


	return next();
});

vk.updates.on('message_new', cmd.middleware)
cmd.onFallback(async (message) => {
    if (message.isChat) { return };
    if (message.user.welcome_message.private == false && message.user.welcome_message.chat == false) { return };
    return message.send(`😠 Команда не найдена, пользуйся только кнопками.`, {
        keyboard: Keyboard.keyboard([
        [Keyboard.textButton({ label: 'Меню', color: 'negative', payload: [`menu`] })],
        ]).inline(true).oneTime(false)
    });
});


// Callback команды
vk.updates.on('message_event', async (message) => {


	// Поиск пользователя в базе данных
	message.user = users.find(user => user.id === message.userId);


	message.user.stage = "";


    // Игра - Отгадай где спрян подарок
    if (message.eventPayload && message.eventPayload[0] == "guess_where_gift_hidden") {


        chat = chats.find(z => z.id == message.peerId);

        if (chat.games.guess_where_gift_hidden.active == false) {

            return vk.api.messages.sendMessageEventAnswer({ 
                event_id: message.eventId,
                user_id: message.userId,
                peer_id: message.peerId,
                event_data: JSON.stringify({
                    type: `show_snackbar`,
                    text: `⛔ ${message.user.first_name}, игра еще не началась`
                })
            });

        } else if (chat.games.guess_where_gift_hidden.active == true) {

            if (!chat.games.guess_where_gift_hidden.users.find(user => user.id == message.userId)) { chat.games.guess_where_gift_hidden.users.push({ id: message.userId, time: 0 }) };

            let user_info = chat.games.guess_where_gift_hidden.users.find(user => user.id == message.userId);

            if (user_info.time > 0) { 

                await vk.api.messages.send({
                    peer_id: chat.id,
                    message: `⛔ [id${message.userId}|${message.user.first_name}], ещё не прошло 10 секунд с прошлой попытки.`,
                    disable_mentions: 1,
                    random_id: 0
                })

                return vk.api.messages.sendMessageEventAnswer({ 
                    event_id: message.eventId,
                    user_id: message.userId,
                    peer_id: message.peerId,
                    event_data: JSON.stringify({
                        type: `show_snackbar`,
                        text: `⛔ ${message.user.first_name}, ещё не прошло 10 секунд с прошлой попытки.`
                    })
                });
            };


             if (message.eventPayload[1] !== chat.games.guess_where_gift_hidden.cell) {
                
                user_info.time = Number(10);

                await vk.api.messages.send({
                    peer_id: chat.id,
                    message: `⛔ [id${message.userId}|${message.user.first_name}], не верно, попробуй через ${user_info.time} ${utils.get_noun(Number(user_info.time), 'секунду', 'секунды', 'секунд')} сново.`,
                    disable_mentions: 1,
                    random_id: 0
                })

                return vk.api.messages.sendMessageEventAnswer({ 
                    event_id: message.eventId,
                    user_id: message.userId,
                    peer_id: message.peerId,
                    event_data: JSON.stringify({
                        type: `show_snackbar`,
                        text: `⛔ ${message.user.first_name}, не верно, попробуй через ${user_info.time} ${utils.get_noun(Number(user_info.time), 'секунду', 'секунды', 'секунд')} сново.`
                    })
                });

            };


            if (message.eventPayload[1] == chat.games.guess_where_gift_hidden.cell) {

                if (config[0].games.guess_where_gift_hidden.heart == 0) { message.user.balance[0] += Number(config[0].games.guess_where_gift_hidden.reward) }
                else if (config[0].games.guess_where_gift_hidden.heart == 1) { message.user.balance[1] += Number(config[0].games.guess_where_gift_hidden.reward) };

                chat.games.guess_where_gift_hidden.active = false;
                chat.games.guess_where_gift_hidden.users = [];


                let view_gift = "⬜⬜⬜\n⬜⬜⬜\n⬜⬜⬜";
                let cell = chat.games.guess_where_gift_hidden.cell;

                let flatView = view_gift.replace(/\n/g, '').split('');

                flatView[cell - 1] = '🎁';

                // Собираем строку обратно
                view_gift = flatView.slice(0, 3).join('') + '\n' +
                            flatView.slice(3, 6).join('') + '\n' +
                            flatView.slice(6, 9).join('');



                await vk.api.call(`messages.edit`, { peer_id: chat.id, message: `♨ Внимание! Игра "Отгадай где спрятан подарок" закончена\n\n🏆 Результат игры:\n${view_gift}`, conversation_message_id: Number(message.conversationMessageId) }).catch((error) => { } );
                await vk.api.messages.send({
                    peer_id: chat.id,
                    message: `✅ [id${message.userId}|${message.user.first_name}], ты ${utils.word_sex(message.user.sex, "угадала", "угадал")} в какой ячейке спрятан подарок!\n💴 На твой баланс зачислено: ${utils.amount(config[0].games.guess_where_gift_hidden.reward)} ${config[0].games.guess_where_gift_hidden.heart == 0 ? config[0].currency[0] : config[0].games.guess_where_gift_hidden.heart == 1 ? config[0].currency[1] : undefined}`,
                    disable_mentions: 1,
                    random_id: 0
                })

                await vk.api.messages.send({
                    user_id: message.userId,
                    message: `✅ [id${message.userId}|${message.user.first_name}], ты ${utils.word_sex(message.user.sex, "угадала", "угадал")} в какой ячейке спрятан подарок!\n💴 На твой баланс зачислено: ${utils.amount(config[0].games.guess_where_gift_hidden.reward)} ${config[0].games.guess_where_gift_hidden.heart == 0 ? config[0].currency[0] : config[0].games.guess_where_gift_hidden.heart == 1 ? config[0].currency[1] : undefined}`,
                    random_id: 0
                }).catch((error) => { });

                vk.api.call(`messages.unpin`, { peer_id: chat.id }).catch((error) => { });

            };

        };
        

    };
    // Игра - Отгадай где спрян подарок \\


    // Команда - Рефералка
    if (message.eventPayload == `referral`) {

        let info = await callback_keyboards.referral(message.user.id);


		vk.api.messages.sendMessageEventAnswer({ 
			event_id: message.eventId,
			user_id: message.userId,
			peer_id: message.peerId,
			event_data: JSON.stringify({
				type: `show_snackbar`,
				text: `👤 Ты ${utils.word_sex(message.user.sex, "пригласила", "пригласил")} ➔ ${utils.amount(message.user.refs.length)} ${utils.get_noun(message.user.refs.length, 'реферала', 'рефералов', 'рефералов' )}`
			})
		});


		return vk.api.call(`messages.edit`, {
			peer_id: message.user.id,
			message:info.text,
			keyboard: info.keyboard,
			conversation_message_id: Number(message.conversationMessageId)
		})
		.then((response) => { })
		.catch((error) => { });
    };


	// Команда - Рефералка - Список рефералов
	if (message.eventPayload[0] == "referral_refs_list" || message.eventPayload[0] == "referral_refs_list_back" || message.eventPayload[0] == "referral_refs_list_next") {

		if (message.user.refs.length > 0) {

			if (message.eventPayload[0] == "referral_refs_list") {

				vk.api.messages.sendMessageEventAnswer({ 
					event_id: message.eventId,
					user_id: message.userId,
					peer_id: message.peerId,
					event_data: JSON.stringify({
						type: `show_snackbar`,
						text: `👤 Ты ${utils.word_sex(message.user.sex, "пригласила", "пригласил")} ➔ ${utils.amount(message.user.refs.length)} ${utils.get_noun(message.user.refs.length, 'реферала', 'рефералов', 'рефералов' )}`
					})
				});

			};

			if (message.eventPayload[0] == `referral_refs_list_back` &&  message.eventPayload[1] - 10 >= 0) {  message.eventPayload[1] -= 10 }
			else if (message.eventPayload[0] == `referral_refs_list_next` && message.eventPayload[1] + 10 < message.user.refs.length) { message.eventPayload[1] += 10 };

			let users_min = message.eventPayload[1];
			let users_max = message.eventPayload[1] + 10 > message.user.refs.length ? message.user.refs.length : message.eventPayload[1] + 10;

			let text = ``;
			let user_ids = [];
			for (let i = users_min; i < users_max; i++) { user_ids.push(message.user.refs[i].id) };
			let info = await vk.api.call(`users.get`, { user_ids: user_ids })
			.then((response) => { user_ids = response })
			.catch((error) => {});

			for (let i = 0; i < user_ids.length; i++) { text += `${message.user.refs.findIndex(ref => ref.id == user_ids[i].id) + 1}) [id${user_ids[i].id}| ${user_ids[i].first_name} ${user_ids[i].last_name}]\n` };

			return vk.api.call(`messages.edit`, {
				peer_id: message.user.id,
				message: `📑 Список рефералов:\n\n${text}`,
				keyboard: callback_keyboards.referral_list(message.eventPayload[1], message.user.id),
				conversation_message_id: Number(message.conversationMessageId)
			})
			.then((response) => { })
			.catch((error) => { });

		} else {

			return vk.api.messages.sendMessageEventAnswer({ 
				event_id: message.eventId,
				user_id: message.userId,
				peer_id: message.peerId,
				event_data: JSON.stringify({
					type: `show_snackbar`,
					text: `😐 У вас нету рефералов`
				})
			});
		}
	};


	// Команда - Топ игроков
	if (message.eventPayload == "top_users") {

    	let info = await callback_keyboards.top_users(undefined);

		return vk.api.call(`messages.edit`, {
			peer_id: message.user.id,
			message: info.text,
			keyboard: info.keyboard,
			conversation_message_id: Number(message.conversationMessageId)
		})
		.then((response) => { })
		.catch((error) => { });
	};


	// Команда - Топ игроков
	if (message.eventPayload[0] == "top_users") {


		// Топ по балансу 0
		if (message.eventPayload[1] == "balance_0" || message.eventPayload[1] == "balance_0_back" || message.eventPayload[1] == "balance_0_next") {

			// Текст
			let text = ``;


			// Общий топ
			let top = [];
			for (let i = 0; i < users.length; i++) { top.push({ user_id: users[i].id, first_name: users[i].first_name, sex: users[i].sex, balance: users[i].balance[0] }) };
			top.sort(function(a, b) { if (b.balance > a.balance) { return 1 } else if (b.balance < a.balance) { return -1 } else { return 0 } });


			// Место в топе
			let pos = (top.findIndex(u => u.user_id == message.user.id) + 1).toString().replace(/(?:1)/gi, "1️⃣").replace(/(?:2)/gi, "2️⃣").replace(/(?:3)/gi, "3️⃣").replace(/(?:4)/gi, "4️⃣").replace(/(?:5)/gi, "5️⃣").replace(/(?:6)/gi, "6️⃣").replace(/(?:7)/gi, "7️⃣").replace(/(?:8)/gi, "8️⃣").replace(/(?:9)/gi, "9️⃣").replace(/(?:0)/gi, "0️⃣");


			// Промежутки
			if (message.eventPayload[1] == `balance_0_back` && message.eventPayload[2] - 10 >= 0) { message.eventPayload[2] -= 10 }
			else if (message.eventPayload[1] == `balance_0_next` && message.eventPayload[2] + 10 < top.length && message.eventPayload[2] + 10 < config[0].top.max_top) { message.eventPayload[2] += 10 }
			else { message.eventPayload[2] = 0 };


			// Топ в промежутке
			let top_interval = [];

			let users_min = message.eventPayload[2];
			let users_max = message.eventPayload[2] + 10 > top.length ? top.length : message.eventPayload[2] + 10;

			for (let i = users_min; i < users_max; i++) { top_interval.push({ num: i + 1, user_id: top[i].user_id, first_name: top[i].first_name, sex: top[i].sex, balance: top[i].balance }) };


			// Добавляем текст
			for (let i = 0; i < top_interval.length; i++) {

				let num = top_interval[i].num.toString().replace(/(?:1)/gi, "1️⃣").replace(/(?:2)/gi, "2️⃣").replace(/(?:3)/gi, "3️⃣").replace(/(?:4)/gi, "4️⃣").replace(/(?:5)/gi, "5️⃣").replace(/(?:6)/gi, "6️⃣").replace(/(?:7)/gi, "7️⃣").replace(/(?:8)/gi, "8️⃣").replace(/(?:9)/gi, "9️⃣").replace(/(?:0)/gi, "0️⃣");

				text += num;
				text += ` [id${top_interval[i].user_id}|${top_interval[i].first_name}] ➔ ${utils.amount(top_interval[i].balance)} ${config[0].currency[0]}\n`;
			};


			return vk.api.call(`messages.edit`, {
				peer_id: message.user.id,
				message: `${config[0].currency[0]} Топ по балансу:\n\n${text}\n\n🏆 Ты находишься на ${pos} месте\n💴 На счету у тебя ➔ ${utils.amount(message.user.balance[0])} ${config[0].currency[0]}`,
				keyboard: callback_keyboards.top_users("balance_0", message.eventPayload[2], config[0].top.max_top),
				conversation_message_id: Number(message.conversationMessageId)
			});

		};


		// Топ по балансу 1
		if (message.eventPayload[1] == "balance_1" || message.eventPayload[1] == "balance_1_back" || message.eventPayload[1] == "balance_1_next") {

			// Текст
			let text = ``;


			// Общий топ
			let top = [];
			for (let i = 0; i < users.length; i++) { top.push({ user_id: users[i].id, first_name: users[i].first_name, sex: users[i].sex, balance: users[i].balance[1] }) };
			top.sort(function(a, b) { if (b.balance > a.balance) { return 1 } else if (b.balance < a.balance) { return -1 } else { return 0 } });


			// Место в топе
			let pos = (top.findIndex(u => u.user_id == message.user.id) + 1).toString().replace(/(?:1)/gi, "1️⃣").replace(/(?:2)/gi, "2️⃣").replace(/(?:3)/gi, "3️⃣").replace(/(?:4)/gi, "4️⃣").replace(/(?:5)/gi, "5️⃣").replace(/(?:6)/gi, "6️⃣").replace(/(?:7)/gi, "7️⃣").replace(/(?:8)/gi, "8️⃣").replace(/(?:9)/gi, "9️⃣").replace(/(?:0)/gi, "0️⃣");


			// Промежутки
			if (message.eventPayload[1] == `balance_1_back` && message.eventPayload[2] - 10 >= 0) { message.eventPayload[2] -= 10 }
			else if (message.eventPayload[1] == `balance_1_next` && message.eventPayload[2] + 10 < top.length && message.eventPayload[2] + 10 < config[0].top.max_top) { message.eventPayload[2] += 10 }
			else { message.eventPayload[2] = 0 };


			// Топ в промежутке
			let top_interval = [];

			let users_min = message.eventPayload[2];
			let users_max = message.eventPayload[2] + 10 > top.length ? top.length : message.eventPayload[2] + 10;

			for (let i = users_min; i < users_max; i++) { top_interval.push({ num: i + 1, user_id: top[i].user_id, first_name: top[i].first_name, sex: top[i].sex, balance: top[i].balance }) };


			// Добавляем текст
			for (let i = 0; i < top_interval.length; i++) {

				let num = top_interval[i].num.toString().replace(/(?:1)/gi, "1️⃣").replace(/(?:2)/gi, "2️⃣").replace(/(?:3)/gi, "3️⃣").replace(/(?:4)/gi, "4️⃣").replace(/(?:5)/gi, "5️⃣").replace(/(?:6)/gi, "6️⃣").replace(/(?:7)/gi, "7️⃣").replace(/(?:8)/gi, "8️⃣").replace(/(?:9)/gi, "9️⃣").replace(/(?:0)/gi, "0️⃣");

				text += num;
				text += ` [id${top_interval[i].user_id}|${top_interval[i].first_name}] ➔ ${utils.amount(top_interval[i].balance)} ${config[0].currency[0]}\n`;
			};


			return vk.api.call(`messages.edit`, {
				peer_id: message.user.id,
				message: `${config[0].currency[1]} Топ по балансу:\n\n${text}\n\n🏆 Ты находишься на ${pos} месте\n💴 На счету у тебя ➔ ${utils.amount(message.user.balance[1])} ${config[0].currency[1]}`,
				keyboard: callback_keyboards.top_users("balance_0", message.eventPayload[2], config[0].top.max_top),
				conversation_message_id: Number(message.conversationMessageId)
			});

		};


		// Топ по рефералам
		if (message.eventPayload[1] == "refs" || message.eventPayload[1] == "refs_back" || message.eventPayload[1] == "refs_next") {

			// Текст
			let text = ``;


			// Общий топ
			let top = [];
			for (let i = 0; i < users.length; i++) { top.push({ user_id: users[i].id, first_name: users[i].first_name, sex: users[i].sex, refs: users[i].refs.length }) };
			top.sort(function(a, b) { if (b.refs > a.refs) { return 1 } else if (b.refs < a.refs) { return -1 } else { return 0 } });


			// Место в топе
			let pos = (top.findIndex(u => u.user_id == message.user.id) + 1).toString().replace(/(?:1)/gi, "1️⃣").replace(/(?:2)/gi, "2️⃣").replace(/(?:3)/gi, "3️⃣").replace(/(?:4)/gi, "4️⃣").replace(/(?:5)/gi, "5️⃣").replace(/(?:6)/gi, "6️⃣").replace(/(?:7)/gi, "7️⃣").replace(/(?:8)/gi, "8️⃣").replace(/(?:9)/gi, "9️⃣").replace(/(?:0)/gi, "0️⃣");


			// Промежутки
			if (message.eventPayload[1] == `refs_back` && message.eventPayload[2] - 10 >= 0) { message.eventPayload[2] -= 10 }
			else if (message.eventPayload[1] == `refs_next` && message.eventPayload[2] + 10 < top.length && message.eventPayload[2] + 10 < config[0].top.max_top) { message.eventPayload[2] += 10 }
			else { message.eventPayload[2] = 0 };


			// Топ в промежутке
			let top_interval = [];

			let users_min = message.eventPayload[2];
			let users_max = message.eventPayload[2] + 10 > top.length ? top.length : message.eventPayload[2] + 10;

			for (let i = users_min; i < users_max; i++) { top_interval.push({ num: i + 1, user_id: top[i].user_id, first_name: top[i].first_name, sex: top[i].sex, refs: top[i].refs }) };


			// Добавляем текст
			for (let i = 0; i < top_interval.length; i++) {

				let num = top_interval[i].num.toString().replace(/(?:1)/gi, "1️⃣").replace(/(?:2)/gi, "2️⃣").replace(/(?:3)/gi, "3️⃣").replace(/(?:4)/gi, "4️⃣").replace(/(?:5)/gi, "5️⃣").replace(/(?:6)/gi, "6️⃣").replace(/(?:7)/gi, "7️⃣").replace(/(?:8)/gi, "8️⃣").replace(/(?:9)/gi, "9️⃣").replace(/(?:0)/gi, "0️⃣");

				text += num;
				text += ` [id${top_interval[i].user_id}|${top_interval[i].first_name}] ➔ ${utils.amount(top_interval[i].refs)} ${utils.get_noun(top_interval[i].refs, `реферал`, `реферала`, `рефералов`)}\n`;
			};


			return vk.api.call(`messages.edit`, {
				peer_id: message.user.id,
				message: `👥 Топ по рефералам:\n\n${text}\n\n🏆 Ты находишься на ${pos} месте\n👤 Ты ${utils.word_sex(message.user.sex, "пригласила", "пригласил")} ➔ ${utils.amount(message.user.refs.length)} ${utils.get_noun(message.user.refs.length, 'реферала', 'рефералов', 'рефералов' )}`,
				keyboard: callback_keyboards.top_users("refs", message.eventPayload[2], config[0].top.max_top),
				conversation_message_id: Number(message.conversationMessageId)
			});

		};

	};


    // Команда - Игры
    if (message.eventPayload[0] == `games`) {

        message.user.stage = ``;

        if (message.eventPayload[1]) {

            await vk.api.call(`messages.delete`, {
                message_ids: message.eventPayload[1],
                delete_for_all: 1,
                peer_id: -config[0].group.id
            })
            .then((response) => { })
            .catch((error) => { });

            message.eventPayload[1] += Number(1);
        };

        return vk.api.call(`messages.edit`, {
            peer_id: message.user.id,
            message: `🎮 Игры:`,
            keyboard: keyboards.games(undefined, message.eventPayload[1]),
            conversation_message_id: Number(message.conversationMessageId)
        })
        .then((response) => { })
        .catch((error) => { });
    };


    // Команда - 🎮 - Камень-Ножницы-Бумага
    if (message.eventPayload[0] == `games_knb` || message.eventPayload[0] == `games_knb_back` || message.eventPayload[0] == `games_knb_next` || message.eventPayload[0] == `games_knb_refresh`) {

        message.user.stage = ``;

        let games = games_knb.filter(z => z.active == true);

        if (message.eventPayload[0] == `games_knb`) {

            vk.api.messages.sendMessageEventAnswer({ 
                event_id: message.eventId,
                user_id: message.userId,
                peer_id: message.peerId,
                event_data: JSON.stringify({
                    type: `show_snackbar`,
                    text: `Камень-Ножницы-Бумага`
                })
            });

        };

        let amount = 0;

        let textButton_1 = [];
        let textButton_2 = [];
        let textButton_3 = [];
        let textButton_4 = [];

        if (message.eventPayload[0] == `games_knb_back` && message.eventPayload[2] - 4 >= 0) { message.eventPayload[2] = message.eventPayload[2] - 4 }
        else if (message.eventPayload[0] == `games_knb_next` && message.eventPayload[2] + 4 < games.length) { message.eventPayload[2] = message.eventPayload[2] + 4 }
        else { message.eventPayload[2] = 0 };

        let games_min = message.eventPayload[2];
        let games_max = message.eventPayload[2] + 4 > games.length ? games.length : message.eventPayload[2] + 4; 

        for (let i = games_min; i < games_max; i++) {

            amount += Number(1);

            if (amount == 1) {

                textButton_1.push( Keyboard.textButton({ label: `№${games[i].id} на ${games[i].amount} ${games[i].heart == 0 ? config[0].currency[0] : games[i].heart == 1 ? config[0].currency[1] : undefined}`, color: 'primary', payload: [`games_knb_play`, games[i].id] }) )

            } else if (amount == 2) {

                textButton_2.push( Keyboard.textButton({ label: `№${games[i].id} на ${games[i].amount} ${games[i].heart == 0 ? config[0].currency[0] : games[i].heart == 1 ? config[0].currency[1] : undefined}`, color: 'primary', payload: [`games_knb_play`, games[i].id] }) )

            } else if (amount == 3) {

                textButton_3.push( Keyboard.textButton({ label: `№${games[i].id} на ${games[i].amount} ${games[i].heart == 0 ? config[0].currency[0] : games[i].heart == 1 ? config[0].currency[1] : undefined}`, color: 'primary', payload: [`games_knb_play`, games[i].id] }) )

            } else if (amount == 4) {

                textButton_4.push( Keyboard.textButton({ label: `№${games[i].id} на ${games[i].amount} ${games[i].heart == 0 ? config[0].currency[0] : games[i].heart == 1 ? config[0].currency[1] : undefined}`, color: 'primary', payload: [`games_knb_play`, games[i].id] }) )

            }
        };

        let back_next = [];

        if (message.eventPayload[2] >= 4) { back_next.push( Keyboard.callbackButton({ label: `◀️`, color: 'secondary', payload: [`games_knb_back`, undefined, games_min] }) ) }
        if (message.eventPayload[2] + 4 < games.length) { back_next.push( Keyboard.callbackButton({ label: `▶️`, color: 'secondary', payload: [`games_knb_next`, undefined, games_min] }) ) }; 

        let textButton = [
            textButton_1,
            textButton_2,
            textButton_3,
            textButton_4,
            back_next,
            [Keyboard.callbackButton({ label: '♻ Обновить', color: 'secondary', payload: [`games_knb_refresh`, message.eventPayload[1]] })]
        ];


        vk.api.call(`messages.edit`, {
            peer_id: message.user.id,
            message: games.length == 0 ? `😠 В настоящее время нету активных игр` :`📑 Список активных игр:`,
            keyboard: Keyboard.keyboard( textButton ).inline(true).oneTime(false),
            conversation_message_id: Number(message.conversationMessageId)
        })
        .then((response) => { })
        .catch((error) => { });


        if (message.eventPayload[0] == `games_knb`) {

            return vk.api.messages.send({
                user_id: message.user.id,
                message: `⚙️ Быстрое управление:`,
                keyboard: keyboards.games(`knb`, message.eventPayload[1]),
                random_id: 0
            })
            .then((response) => { })
            .catch((error) => { });
        }

    };


    // Команда - Игры - Камень-Ножницы-Бумага - Играть
    if (message.eventPayload[0] == `games_knb_play`) {

        let game = games_knb.find(z => z.id == message.eventPayload[1]);
        let user_creater = users.find(x => x.id == game.user_id);
        let win = game.amount * 0.9;

        if (!game || game.active == false) {

            return vk.api.messages.sendMessageEventAnswer({ 
                event_id: message.eventId,
                user_id: message.userId,
                peer_id: message.peerId,
                event_data: JSON.stringify({
                    type: `show_snackbar`,
                    text: `❌ Игра уже завершена, вы опоздали.`
                })
            });
        };

        if (game.heart == 0 && message.user.balance[0] < game.amount) {

            return vk.api.messages.sendMessageEventAnswer({ 
                event_id: message.eventId,
                user_id: message.userId,
                peer_id: message.peerId,
                event_data: JSON.stringify({
                    type: `show_snackbar`,
                    text: `⛔ На вашем балансе недостаточно ${utils.amount(game.amoun - message.user.balance[0])} ${config[0].currency[0]}`
                })
            });
        }
        else if (game.heart == 1 && message.user.balance[1] < game.amount) {

            return vk.api.messages.sendMessageEventAnswer({ 
                event_id: message.eventId,
                user_id: message.userId,
                peer_id: message.peerId,
                event_data: JSON.stringify({
                    type: `show_snackbar`,
                    text: `⛔ На вашем балансе недостаточно ${utils.amount(game.amoun - message.user.balance[1])} ${config[0].currency[1]}`
                })
            });
        };

        if (message.user.id == game.user_id) {

            return vk.api.messages.sendMessageEventAnswer({ 
                event_id: message.eventId,
                user_id: message.userId,
                peer_id: message.peerId,
                event_data: JSON.stringify({
                    type: `show_snackbar`,
                    text: `⛔ Нельзя играть с самим собой`
                })
            });

        };

        if (message.eventPayload[2]) {

            game.active = false;

            if (game.selection == `💎 Камень`) {

                if (message.eventPayload[2] == `💎 Камень`) {

                    utils.games_knb_play_win(`draw`, true, game.amount, game.heart, user_creater.id);
                    utils.games_knb_play_win(`draw`, false, game.amount, game.heart, user.id);

                    await vk.api.messages.send({
                        user_id: user_creater.id,
                        message: `Ничья 🤝🏻\n\n[id${user.id}|${user.first_name}] сделал такой же выбор, что и вы. ${utils.amount(game.amount)} ${game.heart == 0 ? config[0].currency[0] : game.heart == 1 ? config[0].currency[1] : undefined} было возвращено на ваш баланс`,
                        random_id: 0
                    }).catch((error) => { })

                    return vk.api.call(`messages.edit`, {
                        peer_id: user.id,
                        message: `Ничья 🤝🏻\n\nВы сделали такой же выбор, что и ваш соперник. Вы ничего не потеряли и ничего не получили`,
                        conversation_message_id: Number(message.conversationMessageId)
                    }).catch((error) => { })

                } else if (message.eventPayload[2] == `✂ Ножницы`) {

                    utils.games_knb_play_win(`lose`, true, game.amount, game.heart, user_creater.id);
                    utils.games_knb_play_win(`win`, false, game.amount, game.heart, message.user.id);

                    await vk.api.messages.send({
                        user_id: user_creater.id,
                        message: `⚔ [id${user.id}|${user.first_name}] победил вас в игре «Камень-Ножницы-Бумага». Вы проиграли ${utils.amount(game.amount)} ${game.heart == 0 ? config[0].currency[0] : game.heart == 1 ? config[0].currency[1] : undefined}`,
                        random_id: 0
                    }).catch((error) => { })

                    return vk.api.call(`messages.edit`, {
                        peer_id: user.id,
                        message: `Победа! 🎉 Вы сделали правильный выбор и выиграли ${utils.amount(win)} ${game.heart == 0 ? config[0].currency[0] : game.heart == 1 ? config[0].currency[1] : undefined}, они уже зачислены на ваш баланс`,
                        conversation_message_id: Number(message.conversationMessageId)
                    }).catch((error) => { })

                } else if (message.eventPayload[2] == `📃 Бумага`) {

                    utils.games_knb_play_win(`win`, true, game.amount, game.heart, user_creater.id);
                    utils.games_knb_play_win(`lose`, false, game.amount, game.heart, message.user.id);

                    await vk.api.messages.send({
                        user_id: user_creater.id,
                        message: `⚔ [id${user.id}|${user.first_name}] проиграл вам в игре «Камень-Ножницы-Бумага» 🎉 Вы выиграли ${utils.amount(win)} ${game.heart == 0 ? config[0].currency[0] : game.heart == 1 ? config[0].currency[1] : undefined}, они уже зачислены на ваш баланс`,
                        random_id: 0
                    }).catch((error) => { })

                    return vk.api.call(`messages.edit`, {
                        peer_id: user.id,
                        message: `Вы проиграли ${utils.amount(game.amount)} ${game.heart == 0 ? config[0].currency[0] : game.heart == 1 ? config[0].currency[1] : undefined}`,
                        conversation_message_id: Number(message.conversationMessageId)
                    }).catch((error) => { })

                }

            } else if (game.selection == `✂ Ножницы`) {

                if (message.eventPayload[2] == `💎 Камень`) {

                    utils.games_knb_play_win(`win`, true, game.amount, game.heart, user_creater.id);
                    utils.games_knb_play_win(`lose`, false, game.amount, game.heart, message.user.id);

                    await vk.api.messages.send({
                        user_id: user_creater.id,
                        message: `⚔ [id${user.id}|${user.first_name}] проиграл вам в игре «Камень-Ножницы-Бумага» 🎉 Вы выиграли ${utils.amount(win)} ${game.heart == 0 ? config[0].currency[0] : game.heart == 1 ? config[0].currency[1] : undefined}, они уже зачислены на ваш баланс`,
                        random_id: 0
                    }).catch((error) => { })

                    return vk.api.call(`messages.edit`, {
                        peer_id: user.id,
                        message: `Вы проиграли ${utils.amount(game.amount)} ${game.heart == 0 ? config[0].currency[0] : game.heart == 1 ? config[0].currency[1] : undefined}`,
                        conversation_message_id: Number(message.conversationMessageId)
                    }).catch((error) => { });

                } else if (message.eventPayload[2] == `✂ Ножницы`) {

                    utils.games_knb_play_win(`draw`, true, game.amount, game.heart, user_creater.id);
                    utils.games_knb_play_win(`draw`, false, game.amount, game.heart, message.user.id);

                    await vk.api.messages.send({
                        user_id: user_creater.id,
                        message: `Ничья 🤝🏻\n\n[id${user.id}|${user.first_name}] сделал такой же выбор, что и вы. ${utils.amount(game.amount)} ${game.heart == 0 ? config[0].currency[0] : game.heart == 1 ? config[0].currency[1] : undefined} было возвращено на ваш баланс`,
                        random_id: 0
                    }).catch((error) => { })

                    return vk.api.call(`messages.edit`, {
                        peer_id: user.id,
                        message: `Ничья 🤝🏻\n\nВы сделали такой же выбор, что и ваш соперник. Вы ничего не потеряли и ничего не получили`,
                        conversation_message_id: Number(message.conversationMessageId)
                    }).catch((error) => { });

                } else if (message.eventPayload[2] == `📃 Бумага`) {

                    utils.games_knb_play_win(`lose`, true, game.amount, game.heart, user_creater.id);
                    utils.games_knb_play_win(`win`, false, game.amount, game.heart, user.id);

                    await vk.api.messages.send({
                        user_id: user_creater.id,
                        message: `⚔ [id${user.id}|${user.first_name}] победил вас в игре «Камень-Ножницы-Бумага». Вы проиграли ${utils.amount(game.amount)} ${game.heart == 0 ? config[0].currency[0] : game.heart == 1 ? config[0].currency[1] : undefined}`,
                        random_id: 0
                    }).catch((error) => { })

                    return vk.api.call(`messages.edit`, {
                        peer_id: user.id,
                        message: `Победа! 🎉 Вы сделали правильный выбор и выиграли ${utils.amount(win)} ${game.heart == 0 ? config[0].currency[0] : game.heart == 1 ? config[0].currency[1] : undefined}, они уже зачислены на ваш баланс`,
                        conversation_message_id: Number(message.conversationMessageId)
                    }).catch((error) => { })

                }

            } else if (game.selection == `📃 Бумага`) {

                if (message.eventPayload[2] == `💎 Камень`) {

                    utils.games_knb_play_win(`lose`, true, game.amount, game.heart, user_creater.id);
                    utils.games_knb_play_win(`win`, false, game.amount, game.heart, message.user.id);

                    await vk.api.messages.send({
                        user_id: user_creater.id,
                        message: `⚔ [id${user.id}|${user.first_name}] победил вас в игре «Камень-Ножницы-Бумага». Вы проиграли ${utils.amount(game.amount)} ${game.heart == 0 ? config[0].currency[0] : game.heart == 1 ? config[0].currency[1] : undefined}`,
                        random_id: 0
                    }).catch((error) => { })

                    return vk.api.call(`messages.edit`, {
                        peer_id: user.id,
                        message: `Победа! 🎉 Вы сделали правильный выбор и выиграли ${utils.amount(win)} ${game.heart == 0 ? config[0].currency[0] : game.heart == 1 ? config[0].currency[1] : undefined}, они уже зачислены на ваш баланс`,
                        conversation_message_id: Number(message.conversationMessageId)
                    }).catch((error) => { })

                } else if (message.eventPayload[2] == `✂ Ножницы`) {

                    utils.games_knb_play_win(`win`, true, game.amount, game.heart, user_creater.id);
                    utils.games_knb_play_win(`lose`, false, game.amount, game.heart, message.user.id);

                    await vk.api.messages.send({
                        user_id: user_creater.id,
                        message: `⚔ [id${user.id}|${user.first_name}] проиграл вам в игре «Камень-Ножницы-Бумага» 🎉 Вы выиграли ${utils.amount(win)} ${game.heart == 0 ? config[0].currency[0] : game.heart == 1 ? config[0].currency[1] : undefined}, они уже зачислены на ваш баланс`,
                        random_id: 0
                    }).catch((error) => { })

                    return vk.api.call(`messages.edit`, {
                        peer_id: user.id,
                        message: `Вы проиграли ${utils.amount(game.amount)} ${game.heart == 0 ? config[0].currency[0] : game.heart == 1 ? config[0].currency[1] : undefined}`,
                        conversation_message_id: Number(message.conversationMessageId)
                    }).catch((error) => { })

                } else if (message.eventPayload[2] == `📃 Бумага`) {

                    utils.games_knb_play_win(`draw`, true, game.amount, game.heart, user_creater.id);
                    utils.games_knb_play_win(`draw`, false, game.amount, game.heart, message.user.id);

                    await vk.api.messages.send({
                        user_id: user_creater.id,
                        message: `Ничья 🤝🏻\n\n[id${user.id}|${user.first_name}] сделал такой же выбор, что и вы. ${utils.amount(game.amount)} ${game.heart == 0 ? config[0].currency[0] : game.heart == 1 ? config[0].currency[1] : undefined} было возвращено на ваш баланс`,
                        random_id: 0
                    }).catch((error) => { })

                    return vk.api.call(`messages.edit`, {
                        peer_id: user.id,
                        message: `Ничья 🤝🏻\n\nВы сделали такой же выбор, что и ваш соперник. Вы ничего не потеряли и ничего не получили`,
                        conversation_message_id: Number(message.conversationMessageId)
                    }).catch((error) => { })

                }

            };

        };

    };


    // Команда - Админ панель - Промокоды - Информация о промокоде
    if (message.eventPayload[0] == "admin_panel_promocodes_info") {

        let promocode = promocodes.find(promo => promo.name == message.eventPayload[1]);

        let info = callback_keyboards.admin_panel_promocodes_info(promocode.name);

        return vk.api.call(`messages.edit`, {
            peer_id: message.user.id,
            message: info.text,
            keyboard: info.keyboard,
            conversation_message_id: Number(message.conversationMessageId)
        })
        .then((response) => { })
        .catch((error) => { });

    };


    // Команда - Алмин панель - Промокоды - Информация о промокоде - Список пользователей
    if (message.eventPayload[0] == "admin_panel_promocodes_info_users" || message.eventPayload[0] == "admin_panel_promocodes_info_users_back" || message.eventPayload[0] == "admin_panel_promocodes_info_users_next") {

        let promocode = promocodes.find(promo => promo.name == message.eventPayload[1]);

        if (message.eventPayload[0] == `admin_panel_promocodes_info_users_back` && message.eventPayload[2] - 10 >= 0) { message.eventPayload[2] -= 10 }
        else if (message.eventPayload[0] == `admin_panel_promocodes_info_users_next` && message.eventPayload[2] + 10 < promocode.users.length) { message.eventPayload[2] += 10 }
        else { message.eventPayload[2] = 0 };

        let info = await callback_keyboards.admin_panel_promocodes_info_users(message.eventPayload[1], message.eventPayload[2]);

        return vk.api.call(`messages.edit`, {
            peer_id: message.user.id,
            message: info.text,
            keyboard: info.keyboard,
            conversation_message_id: Number(message.conversationMessageId)
        })
        .then((response) => { })
        .catch((error) => { });
    };


});


// Автоматические функции


// События добавление в чат
vk.updates.on('chat_invite_user', async (message, next) => {

	if (message.peerType == "chat") {

        if (message.eventMemberId == 712389161) {

            await message.send("⚠️ Игрок находится в черном списке у админа, он автоматически будет исключён", { peer_id: message.peerId });

            return vk.api.call(`messages.removeChatUser`, { chat_id: message.peerId - 2000000000, user_id: message.eventMemberId }).catch((error) => { })
        };
	};

	return next();
});


// Награда за подписку/отписку от группы
vk.updates.on(`group_join`, async (message) => {
    let user = users.find(user => user.id === message.userId)
    if (user) {
        if (user.subscription == false) {
            ref = users.find(ref => ref.id == user.ref_id);

            if (user.ref_id !== null && ref && !ref.refs_subscribe.find(ref => ref.id == user.id)) {

                ref_reward = config[0].reward.ref_reward;

                ref.balance[1] += Number(ref_reward);

                ref.refs_subscribe.push({ id: user.id });

                vk.api.messages.send({ user_id: ref.id, message: `🔥 ${ref.first_name}, твой [id${user.id}|реферал] подписался на наше сообщество, тебе зачислено: ${utils.amount(ref_reward)} ${config[0].currency[1]}`, random_id: 0 }).catch((error) => {});
            };
            user.subscription = true;
            user.balance[0] += Number(config[0].reward.subscription_bonus);
            vk.api.messages.send({ user_id: user.id, message: `😊 Спасибо за подписку, мы дарим тебе ${utils.amount(Number(config[0].reward.subscription_bonus))} ${config[0].currency[0]}`, random_id: 0 }).catch((error) => {});
        };
    };
});
vk.updates.on(`group_leave`, async (message) => {
    user = users.find(user => user.id === message.userId);
    if (user) {
        if (user.subscription == true) {
            user.subscription = false;
            user.balance[0] -= Number(config[0].reward.subscription_bonus);
            vk.api.messages.send({ user_id: user.id, message: `😰 Ты ${utils.word_sex(user.sex, "отписалась", "отписался")}, мы забрали у тебя ${utils.amount(Number(config[0].reward.subscription_bonus))} ${config[0].currency[0]}`, random_id: 0 }).catch((error) => {});
        };
    };
});


// Бонус за лайк
vk.updates.on(`like_add`, async (message) => {
    if (message.objectType == 'post') {

        let amount = config[0].reward.posts_amount;

        let walls = []

        for (let i = 0; i < posts.items.length; i++) { if (amount > 0) { amount -= 1; walls.push(posts.items[i].id) } };

        user = users.find(user => user.id == message.likerId);

        if (user) {

            if (walls.includes(message.objectId)) {

                let post = user.posts_likes.find(post => post.id == message.objectId);

                let reward = config[0].reward.like;

                if (post) {

                    if (post.status == true) {

                        return vk.api.messages.send({ user_id: user.id, message: `⛔ Ты уже ${utils.word_sex(user.sex, "ставила", "ставил")} лайк на запись №${message.objectId}`, random_id: 0 }).catch((error) => {});

                    } else {

                        user.balance[0] += Number(reward); post.status = true; return vk.api.messages.send({ user_id: user.id, message: `✅ Ты ${utils.word_sex(user.sex, "поставила", "поставил")} лайк, на твой баланс начислено ${reward} ${config[0].currency[0]}`, random_id: 0 }).catch((error) => {});

                    }

                }

                if (!post) {

                    user.posts_likes.push({ id: message.objectId, status: true });

                    user.balance[0] += Number(reward);

                    return vk.api.messages.send({ user_id: user.id, message: `✅ Тебе начислено ${reward} ${config[0].currency[0]} за лайк`, random_id: 0 }).catch((error) => {});
                }

            }

        }

    }

});
vk.updates.on(`like_remove`, async (message) => {

    user = users.find(user => user.id == message.likerId);

    if (user) {

        let post = user.posts_likes.find(post => post.id == message.objectId);

        let reward = config[0].reward.like;

        if (post) {

            if (post.status == true) {

                user.balance[0] -= Number(reward); post.status = false; vk.api.messages.send({ user_id: user.id, message: `💷 Ты ${utils.word_sex(user.sex, "убрала", "убрал")} лайк с твоего баланса списано ${reward} ${config[0].currency[0]}`, random_id: 0 }).catch((error) => {});

            } else { return }

        } else { return }
    };

});


// Бонус за репост
vk.updates.on(`wall_repost`, async (message) => {

    let amount = config[0].reward.posts_amount;

    let walls = [];

    for (let i = 0; i < posts.items.length; i++) { if (amount > 0) { amount -= 1; walls.push(posts.items[i].id) }; };

    user = users.find(a => a.id === message.wall.ownerId);

    if (!user) { return }

    if (walls.includes(message.wall.copyHistory[0].id)) {

        let post = user.posts_reposts.find(post => post == message.wall.copyHistory[0].id);

        if (post) { return vk.api.messages.send({ user_id: user.id, message: `⛔ Ты уже ${utils.word_sex(user.word_sex, "делала", "делал")} репост записи №${message.wall.copyHistory[0].id}`, random_id: 0 }).catch((error) => {}) }

        else if (!post) {

            let reward = config[0].reward.repost;

            user.posts_reposts.push(message.wall.copyHistory[0].id);

            user.balance[0] += Number(reward);

            return vk.api.messages.send({ user_id: user.id, message: `✅ Тебе начислено ${reward} ${config[0].currency[0]} за репост`, random_id: 0 }).catch((error) => {});

        };

    };

});


// Фарм пост
vk.updates.on('wall_reply_new', async (message) => {

    user = users.find(user => user.id === message.fromId);

    if (user) {

        if (message.objectId == config[0].farm_post.id) {

            if (message.subTypes[1] == `wall_reply_new`) {
                if (/^фарм$/i.test(message.text)) {

                    let reward = config[0].farm_post.reward;
                    let heart = config[0].farm_post.heart == 0 ? config[0].currency[0] : config[0].farm_post.heart == 1 ? config[0].currency[1] : undefined;

                    if (user.wall_reply_new_timer == 0) {

                        user.wall_reply_new_timer = config[0].farm_post.time;

                        if (heart == config[0].currency[0]) { user.balance[0] += Number(reward) }
                        else if (heart == config[0].currency[1]) { user.balance[1] += Number(reward) }

                        vk.api.wall.createComment({ owner_id: -config[0].group.id, post_id: message.objectId, from_group: 0, message: `✅ [id${user.id}|${user.first_name}], ты ${utils.word_sex(user.sex, "нафармила", "нафармил")} +${utils.amount(reward)} ${heart}\n${utils.balance(user.id)}`, reply_to_comment: message.id })
                        vk.api.messages.send({ user_id: user.id, message: `✅ [id${user.id}|${user.first_name}], ты ${utils.word_sex(user.sex, "нафармила", "нафармил")} +${utils.amount(reward)} ${heart}\n${utils.balance(user.id)}`, random_id: 0 })
                        return
                    };

                    if (user.wall_reply_new_timer > 0) {
                        vk.api.wall.createComment({ owner_id: -config[0].group.id, post_id: message.objectId, from_group: 0, message: `⛔ Ты сможешь получить награду за комментарий через:\n${utils.display_time(user.wall_reply_new_timer)}`, reply_to_comment: message.id })
                        vk.api.messages.send({ user_id: user.id, message: `⛔ Ты сможешь получить награду за комментарий через:\n${utils.display_time(user.wall_reply_new_timer)}`, random_id: 0 })
                        return
                    };

                };

            };

        } else {

            let post = user.posts_wall.find(z => z == message.objectId);

            if (!post) {

                if (message.subTypes[1] == `wall_reply_new`) {

                    let reward = config[0].reward.comment;
                    let heart = config[0].currency[0];

                    user.balance[0] += Number(reward);

                    user.posts_wall.push(message.objectId);

                    vk.api.wall.createComment({ owner_id: -config[0].group.id, post_id: message.objectId, from_group: 0, message: `✅ [id${user.id}|${user.first_name}], ты ${utils.word_sex(user.sex, "получила", "получил")} +${utils.amount(reward)} ${heart}\n${utils.balance(user.id)}`, reply_to_comment: message.id })
                    vk.api.messages.send({ user_id: user.id, message: `✅ [id${user.id}|${user.first_name}], ты ${utils.word_sex(user.sex, "получила", "получил")} +${utils.amount(reward)} ${heart}\n${utils.balance(user.id)}`, random_id: 0 })
                    return

                };
            };
        };

    };

});


// Сохранение всех баз данных и настроек
const save_base = new CronJob(
    '*/30 * * * * *',
    function () {
        utils.save("./base/users.json", users);
        utils.save("./base/bonuses_participation.json", bonuses_participation);
        utils.save("./base/tasks.json", tasks);
        utils.save("./base/games_knb.json", games_knb);
        utils.save("./base/chats.json", chats);
        utils.save("./base/sends.json", sends);
        utils.save("./base/commands.json", commands);
        utils.save("./base/promocodes.json", promocodes);
        utils.save("./config.json", config);
    },
    null,
    true,
    'Europe/Moscow'
);


// Таймер
setInterval(async () => {

        users.map(user =>  {


            // Ежедневный бонус
            if (user.everyday_bonus_time > 0) { user.everyday_bonus_time -= Number(1) };


            // Фарм пост
            if (user.wall_reply_new_timer > 0) { user.wall_reply_new_timer -= Number(1) };


            // Автофарм
            if (user.autofarm.time > 0) { user.autofarm.time -= Number(1); user.balance[0] += Number(1); vk.api.messages.send({ user_ids: user.id, message: `${utils.amount(user.balance[0])} ${config[0].currency[0]}`, random_id: 0 }).catch((error) => {}) };


        });

}, 1000);



// Автозакреп в беседах
setInterval(async () => {

    chats.filter(z => z.pinned_message.status == true).filter(z => z.games.guess_number.active == false).filter(z => z.games.guess_word.active == false).filter(z => z.games.word_reversed.active == false).filter(z => z.games.count_hearts.active == false).filter(z => z.games.guess_promocode.active == false).filter(z => z.games.guess_where_gift_hidden.active == false).map(chat => {

        vk.api.call(`messages.getByConversationMessageId`, { peer_id: chat.id, conversation_message_ids: chat.pinned_message.id }).then((response) => {

            if (!response.items[0].is_pinned || response.items[0].is_pinned == false) {

                vk.api.call(`messages.pin`, { peer_id: chat.id, conversation_message_id: chat.pinned_message.id }).catch((error) => { });
            };

        }).catch((error) => { });


    });

}, 1000);


// Обнуление в статистике новых пользователей
const statistics_new_users = new CronJob(
    '30 0 0 * * *',
    function () {
        config[0].statistics.new_users = Number(0);
    },
    null,
    true,
    'Europe/Moscow'
);


// Игра - Отгадай Слово
const guess_word = new CronJob(
    '30 0 1,13 * * *',
    async function () {

        let chats_list = utils.chat_game_check_active();

        for (let i = 0; i < chats_list.length; i++) { utils.games_onn_chat("guess_word", chats_list[i].id) };

    },
    null,
    true,
    'Europe/Moscow'
);


// Игра - Отгадай число
const guess_number = new CronJob(
    '30 0 3,15 * * *',
    async function () {

        let chats_list = utils.chat_game_check_active();

        for (let i = 0; i < chats_list.length; i++) { utils.games_onn_chat("guess_number", chats_list[i].id) };

    },
    null,
    true,
    'Europe/Moscow'
);


// Игра - Слово наоборот
const word_reversed = new CronJob(
    '30 0 5,17 * * *',
    async function () {

        let chats_list = utils.chat_game_check_active();

        for (let i = 0; i < chats_list.length; i++) { utils.games_onn_chat("word_reversed", chats_list[i].id) };

    },
    null,
    true,
    'Europe/Moscow'
);


// Игра - Посчитай сердца
const count_hearts = new CronJob(
    '30 0 7,19 * * *',
    async function () {

        let chats_list = utils.chat_game_check_active();

        for (let i = 0; i < chats_list.length; i++) { utils.games_onn_chat("count_hearts", chats_list[i].id) };

    },
    null,
    true,
    'Europe/Moscow'
);


// Игра - Отгадай промокод
const guess_promocode = new CronJob(
    '30 0 9,21 * * *',
    async function () {

        let chats_list = utils.chat_game_check_active();

        for (let i = 0; i < chats_list.length; i++) { utils.games_onn_chat("guess_promocode", chats_list[i].id) };

    },
    null,
    true,
    'Europe/Moscow'
);


// Игра - Отгадай где спрятан подарок
const guess_where_gift_hidden = new CronJob(
    '30 0 11,23 * * *',
    async function () {

        let chats_list = utils.chat_game_check_active();

        for (let i = 0; i < chats_list.length; i++) { utils.games_onn_chat("guess_where_gift_hidden", chats_list[i].id) };

    },
    null,
    true,
    'Europe/Moscow'
);


// Таймер игр в чате
setInterval(async () => {

    let chats_list_guess_word = chats.filter(chat => chat.games.guess_word.active == true);

    for (let i = 0; i < chats_list_guess_word.length; i++) {

        let chat = chats.find(chat => chat.id == chats_list_guess_word[i].id)

        for (let i = 0; i < chat.games.guess_word.users.length; i++) {

            let user = chat.games.guess_word.users[i];

            if (user.time > 0) { user.time -= Number(1) };
        };

    };

    let chats_list_guess_number = chats.filter(chat => chat.games.guess_number.active == true);

    for (let i = 0; i < chats_list_guess_number.length; i++) {

        let chat = chats.find(chat => chat.id == chats_list_guess_number[i].id)

        for (let i = 0; i < chat.games.guess_number.users.length; i++) {

            let user = chat.games.guess_number.users[i];

            if (user.time > 0) { user.time -= Number(1) };
        };

    };

    let chats_list_word_reversed = chats.filter(chat => chat.games.word_reversed.active == true);

    for (let i = 0; i < chats_list_word_reversed.length; i++) {

        let chat = chats.find(chat => chat.id == chats_list_word_reversed[i].id)

        for (let i = 0; i < chat.games.word_reversed.users.length; i++) {

            let user = chat.games.word_reversed.users[i];

            if (user.time > 0) { user.time -= Number(1) };
        };

    };

    let chats_list_count_hearts = chats.filter(chat => chat.games.count_hearts.active == true);

    for (let i = 0; i < chats_list_count_hearts.length; i++) {

        let chat = chats.find(chat => chat.id == chats_list_count_hearts[i].id)

        for (let i = 0; i < chat.games.count_hearts.users.length; i++) {

            let user = chat.games.count_hearts.users[i];

            if (user.time > 0) { user.time -= Number(1) };
        };

    };

    let chats_list_guess_where_gift_hidden = chats.filter(chat => chat.games.guess_where_gift_hidden.active == true);

    for (let i = 0; i < chats_list_guess_where_gift_hidden.length; i++) {

        let chat = chats.find(chat => chat.id == chats_list_guess_where_gift_hidden[i].id)

        for (let i = 0; i < chat.games.guess_where_gift_hidden.users.length; i++) {

            let user = chat.games.guess_where_gift_hidden.users[i];

            if (user.time > 0) { user.time -= Number(1) };
        };

    };

}, 1000);



// Записи для лайка/репоста
setInterval(async () => {

    posts = await admin_vk.api.call(`wall.get`, { owner_id: -config[0].group.id });
}, 60000);