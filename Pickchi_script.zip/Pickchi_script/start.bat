node pickchi.js
pause